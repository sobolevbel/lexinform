"""Grading-key extraction on Claude Sonnet 5 (Batch): every foreigner-relevant provision with a verbatim
quote, verified offline against the frozen text. Shares exp.py's ledger and budget."""

from __future__ import annotations

import json
import re
import sys
from typing import Any

import exp

GOLD_SYSTEM = """You build a grading key used to evaluate short Russian-language cards that summarise Polish bills for foreigners living in Poland. You are NOT writing the card. Read the entire supplied text (bill, justification, impact assessment) carefully.

Return JSON with:
- bill_purpose: one English sentence on what the bill does overall.
- foreigner_facts: EVERY provision that changes something for non-citizens: residence, visas, citizenship, protection, work, benefits, health, education, documents, registers, fees, procedures, control, detention, return — directly, or a general rule whose text expressly treats foreigners/non-citizens/citizens of particular states differently. For each: fact (precise English: who exactly, condition, exception, deadline and its starting point, amount, document, authority), importance ("critical" = a reader in that group would act or be harmed if they missed it; "important"; "minor"), quote (verbatim Polish copied character-for-character from the supplied text, 40-300 characters, prefer the normative bill text over the justification), part ("bill", "justification", "osr", "other").
- general_facts: up to 6 main provisions affecting everyone (context only), each with fact and verbatim quote.
- traps: up to 6 plausible misreadings a summariser could make (proposal vs existing law, direction of movement, who is excluded, deadline attached to the wrong event, budget funding mistaken for new rights, mention in justification mistaken for a rule), each with trap, correct_reading and verbatim quote.
- effective_date: the entry-into-force rule in English plus a verbatim quote, or null when the text has none.
- relevance: direct | indirect | marginal | none — whether the bill changes something for foreigners as such.
- suggested_score: 1-5 using this rubric: 5 legal stay/visas/citizenship/protection/UdSC decisions; 4 work permits/employment of foreigners/Ukraine special act/repatriation/Karta Polaka benefits; 3 benefits/health/education/PESEL/banking/housing/driving licences for foreigners; 2 indirect (immigration control specifically, tax residency, general law with a specific foreigner angle, bilateral ratifications); 1 marginal mention. Use 1 when nothing changes for foreigners.
- score_reason: one sentence.
Use only the supplied text. Quotes must be exact substrings of the supplied text (keep original spelling, hyphenation and spacing as far as possible)."""

GOLD_SCHEMA: dict[str, Any] = {
    'type': 'object', 'additionalProperties': False,
    'required': ['bill_purpose', 'foreigner_facts', 'general_facts', 'traps', 'effective_date',
                 'relevance', 'suggested_score', 'score_reason'],
    'properties': {
        'bill_purpose': {'type': 'string'},
        'foreigner_facts': {'type': 'array', 'items': {'type': 'object', 'additionalProperties': False,
            'required': ['fact', 'importance', 'quote', 'part'],
            'properties': {'fact': {'type': 'string'}, 'importance': {'type': 'string', 'enum': ['critical', 'important', 'minor']},
                           'quote': {'type': 'string'}, 'part': {'type': 'string', 'enum': ['bill', 'justification', 'osr', 'other']}}}},
        'general_facts': {'type': 'array', 'items': {'type': 'object', 'additionalProperties': False,
            'required': ['fact', 'quote'], 'properties': {'fact': {'type': 'string'}, 'quote': {'type': 'string'}}}},
        'traps': {'type': 'array', 'items': {'type': 'object', 'additionalProperties': False,
            'required': ['trap', 'correct_reading', 'quote'],
            'properties': {'trap': {'type': 'string'}, 'correct_reading': {'type': 'string'}, 'quote': {'type': 'string'}}}},
        'effective_date': {'anyOf': [{'type': 'null'}, {'type': 'object', 'additionalProperties': False,
            'required': ['rule', 'quote'], 'properties': {'rule': {'type': 'string'}, 'quote': {'type': 'string'}}}]},
        'relevance': {'type': 'string', 'enum': ['direct', 'indirect', 'marginal', 'none']},
        'suggested_score': {'type': 'integer'},
        'score_reason': {'type': 'string'},
    },
}

MODEL = 'claude-sonnet-5'


def gold_text(case: dict[str, Any]) -> str:
    ctx = case['context']
    return f"Tytuł: {ctx['title']}\nWnioskodawca: {ctx['applicant_type']}\n\n=== TEKST ===\n{ctx['text']}"


def prepare(phase: str, selector: str) -> None:
    cases = exp.select(exp.load('cases.json'), selector)
    client = exp.claude()
    reqs = []
    for c in cases:
        if not (c.get('context') or {}).get('text'):
            continue
        params = {'model': MODEL, 'max_tokens': 20000,
                  'system': [{'type': 'text', 'text': GOLD_SYSTEM}],
                  'messages': [{'role': 'user', 'content': gold_text(c)}],
                  'thinking': {'type': 'adaptive'},
                  'output_config': {'effort': 'high', 'format': {'type': 'json_schema', 'schema': GOLD_SCHEMA}}}
        n = client.messages.count_tokens(model=MODEL, system=params['system'], messages=params['messages']).input_tokens
        reqs.append({'custom_id': re.sub(r'[^a-zA-Z0-9_-]', '_', c['id'])[:64], '_case_id': c['id'], '_count': n,
                     '_reserve': (n * 1.0 + 20000 * 5.0) / 1e6, 'params': params})
        print(c['id'], n, flush=True)
    exp.dump(f'{phase}.requests.json', reqs)
    print('reserve', sum(r['_reserve'] for r in reqs), 'committed anthropic', exp.committed('anthropic'))


def submit(phase: str) -> None:
    led = exp.ledger()
    if phase in led['batches']:
        raise SystemExit('existing intent')
    reqs = exp.load(f'{phase}.requests.json')
    reserve = sum(r['_reserve'] for r in reqs)
    if exp.committed('anthropic') + reserve > exp.BUDGETS['anthropic']:
        raise SystemExit(f"anthropic budget reservation rejected {exp.committed('anthropic') + reserve}")
    led['batches'][phase] = {'reserved_usd': reserve, 'requests': len(reqs), 'provider': 'anthropic',
                             'ids': [r['_case_id'] for r in reqs], 'status': 'submitting_uncertain'}
    exp.dump('ledger.json', led)
    b = exp.claude().messages.batches.create(requests=[{'custom_id': r['custom_id'], 'params': r['params']} for r in reqs])
    led['batches'][phase].update(batch_id=b.id, status=b.processing_status)
    exp.dump('ledger.json', led)
    print(phase, b.id, b.processing_status, reserve)


def collect() -> None:
    led = exp.ledger()
    client = exp.claude()
    for key, rec in led['batches'].items():
        if rec.get('provider') != 'anthropic' or 'actual_usd' in rec:
            continue
        b = client.messages.batches.retrieve(rec['batch_id'])
        rec['status'] = b.processing_status
        rec['counts'] = b.request_counts.model_dump()
        if b.processing_status == 'ended':
            reqs = {r['custom_id']: r for r in exp.load(f'{key}.requests.json')}
            rows, usd = [], 0.0
            for item in client.messages.batches.results(rec['batch_id']):
                req = reqs[item.custom_id]
                row: dict[str, Any] = {'custom_id': item.custom_id, 'case_id': req['_case_id'],
                                       'answer_id': req.get('_answer'), 'type': item.result.type}
                if item.result.type == 'succeeded':
                    m = item.result.message
                    u = m.usage
                    model = req['params']['model']
                    cost = exp.price(model, u.input_tokens + (u.cache_read_input_tokens or 0) + (u.cache_creation_input_tokens or 0),
                                     u.cache_read_input_tokens or 0, u.cache_creation_input_tokens or 0, u.output_tokens)
                    usd += cost
                    text = ''.join(getattr(bl, 'text', '') for bl in m.content if bl.type == 'text')
                    row.update(input=u.input_tokens, output=u.output_tokens, usd=cost, stop=m.stop_reason, raw=text)
                    try:
                        row['answer'] = json.loads(text)
                    except ValueError as e:
                        row['error'] = str(e)[:200]
                rows.append(row)
            rec['actual_usd'] = usd
            exp.dump(f'{key}.parsed.json', rows)
        exp.dump('ledger.json', led)
        print(key, rec['status'], rec['counts'], rec.get('actual_usd'))
    print('committed openai', round(exp.committed(), 4), 'anthropic', round(exp.committed('anthropic'), 4))


def verify(phase: str) -> None:
    """Check every quote against the frozen text after whitespace/hyphen normalisation."""
    cases = {c['id']: c for c in exp.load('cases.json')}
    norm = lambda s: re.sub(r'[\s\-–­]+', '', s).lower()  # noqa: E731
    out = {}
    for row in exp.load(f'{phase}.parsed.json'):
        a = row.get('answer')
        if not a:
            continue
        text = norm(cases[row['case_id']]['context']['text'])
        for group in ('foreigner_facts', 'general_facts', 'traps'):
            for f in a[group]:
                q = norm(f['quote'])
                f['quote_found'] = q in text or (len(q) > 60 and (q[:50] in text or q[-50:] in text))
        if a.get('effective_date'):
            q = norm(a['effective_date']['quote'])
            a['effective_date']['quote_found'] = q in text or q[:40] in text
        out[row['case_id']] = a
        miss = sum(not f['quote_found'] for f in a['foreigner_facts'])
        print(row['case_id'], 'facts', len(a['foreigner_facts']), 'unverified', miss, 'score', a['suggested_score'], a['relevance'])
    exp.dump(f'{phase}.verified.json', out)


if __name__ == '__main__':
    action, *args = sys.argv[1:]
    {'prepare': lambda: prepare(*args), 'submit': lambda: submit(*args), 'collect': collect,
     'verify': lambda: verify(*args)}[action]()
