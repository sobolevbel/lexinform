"""Aggregate quality and cost per configuration from answers, keys and judge grades."""

from __future__ import annotations

import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean, median
from typing import Any

import os
HERE = Path(__file__).parent
POOL = os.environ.get('POOL') == '1'
EV = HERE / 'evidence'
W = {'critical': 3, 'important': 2, 'minor': 1}
G = {'full': 1.0, 'partial': 0.5, 'missing': 0.0, 'wrong': 0.0}
STAGE = re.compile(r'(принят\w* Сейм|одобрен\w* Сейм|передан\w* в Сенат|подписан\w* президент|уже вступил|находится на (стадии|этапе)|направлен\w* в Сейм|внесён в Сейм|внесен в Сейм)', re.I)
TRANSLIT = re.compile(r'\b(МВД|ЗУС|НФЗ|ПЕСЕЛЬ|ПЕСЭЛЬ|УдСК|УДСК|МСВиА|КРУС)\b')
POLISH = re.compile(r'[ąćęłńóśźż]', re.I)


def polish_leak(text: str) -> int:
    """Polish words outside parentheses/quotes, a rough proxy for language switching."""
    stripped = re.sub(r'\([^)]*\)|«[^»]*»|"[^"]*"|„[^”]*”', ' ', text)
    words = [w for w in re.findall(r'\b[\wąćęłńóśźż-]+\b', stripped) if POLISH.search(w)]
    return len(words)


def fmt(a: dict[str, Any]) -> dict[str, Any]:
    allt = ' '.join([a['summary'], *a['key_changes'], a['practical_impact'], *a['affected_groups']])
    return {'summary_len': len(a['summary']), 'summary_long': len(a['summary']) > 450,
            'kc_n': len(a['key_changes']), 'kc_long': sum(len(x) > 170 for x in a['key_changes']),
            'stage': bool(STAGE.search(allt)), 'translit': bool(TRANSLIT.search(allt)),
            'polish_words': polish_leak(allt), 'card_chars': len(allt),
            'mnemonic_words': len(a.get('mnemonic_candidate', '').split())}


def load_rows(name: str) -> list[dict[str, Any]]:
    p = EV / name
    return json.loads(p.read_text()) if p.exists() else []


def main(sets: list[str]) -> None:
    cases = {c['id']: c for c in json.loads((EV / 'cases.json').read_text())}
    keys = json.loads((HERE / 'gold' / 'keys.json').read_text())
    rows = list({r['custom_id']: r for r in load_rows('answers.json') if r.get('custom_id')}.values())
    grades = {}
    for pref in ('j2_', 'j2b_'):
        grades.update({r['answer_id']: r['answer'] for r in rows if r.get('cfg') == 'judge54' and r.get('answer') and r['custom_id'].startswith(pref)})
    adj = {}
    reqs = {}
    for p in EV.glob('adj*.requests.json'):
        reqs.update({r['custom_id']: r for r in json.loads(p.read_text())})
    for r in rows:
        if r.get('cfg') == 'adjudicate' and r.get('answer') and r['custom_id'] in reqs:
            req = reqs[r['custom_id']]
            verdict = {x['index']: x['verdict'] for x in r['answer']['items']}
            adj[req['_answer']] = [(it['kind'], it['ref'], verdict.get(i, 'unclear')) for i, it in enumerate(req['_items'])]
    by = defaultdict(list)
    for r in rows:
        if r.get('cfg') is None or r['cfg'].startswith(('judge', 'gold', 'adjud')) or r['case_id'] not in cases:
            continue
        if cases[r['case_id']]['set'] not in sets or r['case_id'].split('-')[0] not in ('analysis', 'reanalysis', 'holdout'):
            continue
        by[re.sub(r'-r[23]$', '', r['cfg']) if POOL else r['cfg']].append(r)
    out = {}
    for cfg, rs in sorted(by.items()):
        m = defaultdict(list)
        for r in rs:
            k = keys.get(r['case_id'])
            m['usd'].append(r['usd']); m['input'].append(r['input']); m['output'].append(r['output'])
            m['reasoning'].append(r['reasoning']); m['cache_write'].append(r['cache_write']); m['cached'].append(r['cached'])
            a = r['answer']
            m['invalid'].append(a is None)
            if a is None or k is None:
                continue
            pub = bool(a['relevant'] and a['score'] >= 3)
            m['score_in_range'].append(k['score'][0] <= a['score'] <= k['score'][1])
            m['score_abs_err'].append(0 if k['score'][0] <= a['score'] <= k['score'][1] else min(abs(a['score'] - k['score'][0]), abs(a['score'] - k['score'][1])))
            if k['publish'] is True:
                m['missed_card'].append(not pub)
            if k['publish'] is False:
                m['false_card'].append(pub)
            if 'names_changes' in k:
                m['revision_signal_ok'].append(bool(a['changes_since_previous']) == k['names_changes'])
            for f_, v in fmt(a).items():
                m['fmt_' + f_].append(v)
            g = grades.get(r['custom_id'])
            verdicts = adj.get(r['custom_id'])
            if g and verdicts is not None:
                m['wrong_verified'].append(sum(1 for kind, ref, v in verdicts if v == 'card_wrong'))
                m['flagged_overturned'].append(sum(1 for kind, ref, v in verdicts if v == 'card_correct'))
            elif g:
                m['wrong_verified'].append(0 if not (g['wrong_claims'] or any(x['grade'] == 'wrong' for x in g['facts'])) else None)
            if g and k.get('facts'):
                facts = {x['index']: x['grade'] for x in g['facts']}
                for kind, ref, v in verdicts or []:
                    if kind == 'fact' and v == 'card_correct':
                        facts[ref] = 'full'
                tot = sum(W[f['importance']] for f in k['facts'])
                got = sum(W[f['importance']] * G[facts.get(i, 'missing')] for i, f in enumerate(k['facts']))
                m['recall_w'].append(got / tot)
                crit = [i for i, f in enumerate(k['facts']) if f['importance'] == 'critical']
                if crit:
                    m['critical_full'].append(sum(facts.get(i) == 'full' for i in crit) / len(crit))
                    m['critical_missing'].append(sum(facts.get(i) in ('missing', None) for i in crit))
                m['wrong_facts'].append(sum(v == 'wrong' for v in facts.values()))
            if g:
                m['wrong_claims'].append(len(g['wrong_claims']))
                m['unsupported'].append(len(g['unsupported_claims']))
                m['trap_hits'].append(len(g['trap_hits']))
        summ = {'n': len(rs), 'usd_total': round(sum(m['usd']), 4), 'usd_mean': round(mean(m['usd']), 5)}
        for name, vals in m.items():
            vals = [v for v in vals if v is not None]
            m[name] = vals
            if name in ('usd',) or not vals:
                continue
            if isinstance(vals[0], bool):
                summ[name] = f"{sum(vals)}/{len(vals)}"
            else:
                summ[name] = round(mean(vals), 3)
        summ['reasoning_share'] = round(sum(m['reasoning']) / max(1, sum(m['output'])), 3)
        out[cfg] = summ
    for cfg, s in out.items():
        print(cfg, json.dumps(s, ensure_ascii=False))
    (EV / f"score-{'+'.join(sets)}{'-pooled' if POOL else ''}.json").write_text(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main(sys.argv[1].split(','))
