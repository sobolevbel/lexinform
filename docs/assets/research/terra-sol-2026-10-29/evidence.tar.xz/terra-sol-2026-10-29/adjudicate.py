"""Source-grounded adjudication of judge-flagged wrong statements: card vs key, decided on source windows."""

from __future__ import annotations

import hashlib
import json
import math
import re
import sys
from typing import Any

import exp

SYSTEM = """You settle disputes between a Russian card summarising a Polish bill and a grading key. A grader flagged card statements as wrong. You get the disputed statements, the grader's reason, and passages of the Polish source text. Decide each dispute ONLY from the source passages:
- "card_correct": the source supports the card statement (the key or the grader was too narrow or mistaken);
- "card_wrong": the source contradicts the card statement or the card changes scope, condition, number, date or direction;
- "unclear": the passages do not settle it.
Return JSON only."""

SCHEMA = {'type': 'object', 'additionalProperties': False, 'required': ['items'],
          'properties': {'items': {'type': 'array', 'items': {'type': 'object', 'additionalProperties': False,
                                   'required': ['index', 'verdict', 'reason'],
                                   'properties': {'index': {'type': 'integer'},
                                                  'verdict': {'type': 'string', 'enum': ['card_correct', 'card_wrong', 'unclear']},
                                                  'reason': {'type': 'string'}}}}}}


def norm(s: str) -> str:
    return re.sub(r'[\s\-–­]+', '', s).lower()


def windows(text: str, quotes: list[str], width: int = 1200, limit: int = 60000) -> str:
    """Source passages around each verified quote (located on the normalised text, mapped back)."""
    idx, mapping = [], []
    for i, ch in enumerate(text):
        if not re.match(r'[\s\-–­]', ch):
            mapping.append(i)
            idx.append(ch.lower())
    flat = ''.join(idx)
    spans = []
    for q in quotes:
        nq = norm(q)
        pos = flat.find(nq) if nq else -1
        if pos < 0 and len(nq) > 60:
            pos = flat.find(nq[:50])
        if pos >= 0:
            s = mapping[pos]
            spans.append([max(0, s - width), min(len(text), s + len(q) + width)])
    spans.sort()
    merged = []
    for s, e in spans:
        if merged and s <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    out = '\n[...]\n'.join(re.sub(r'\s+', ' ', text[s:e]) for s, e in merged)
    return out[:limit]


def prepare(phase: str, cfg_filter: str) -> None:
    cases = {c['id']: c for c in exp.load('cases.json')}
    keys = json.loads((exp.HERE / 'gold' / 'keys.json').read_text())
    quotes: dict[str, list[str]] = {}
    for name in ('gold1.verified.json', 'gold54.verified.json', 'gold54b.flex.verified.json'):
        p = exp.OUT / name
        if p.exists():
            for cid, e in json.loads(p.read_text()).items():
                quotes[cid] = [x['quote'] for g in ('foreigner_facts', 'traps') for x in e[g]] + \
                              ([e['effective_date']['quote']] if e.get('effective_date') else [])
    for cid in ('reanalysis-3141', 'reanalysis-3146'):
        quotes.setdefault(cid, quotes.get(cid.replace('reanalysis-', 'analysis-'), []))
    rows = list({r['custom_id']: r for r in exp.load('answers.json') if r.get('custom_id')}.values())
    answers = {r['custom_id']: r for r in rows}
    grades = {}
    for pref in ('j2_', 'j2b_'):
        grades.update({r['answer_id']: r for r in rows if r.get('cfg') == 'judge54' and r.get('answer') and r['custom_id'].startswith(pref)})
    client = exp.oai()
    reqs = []
    for aid, g in grades.items():
        src = answers.get(aid)
        if not src or not re.fullmatch(cfg_filter, src['cfg']):
            continue
        k = keys[g['case_id']]
        items = []
        for x in g['answer']['facts']:
            if x['grade'] == 'wrong' and x['index'] < len(k['facts']):
                items.append({'kind': 'fact', 'ref': x['index'], 'statement': f"Key fact: {k['facts'][x['index']]['fact']}", 'grader': x['note']})
        for i, w in enumerate(g['answer']['wrong_claims']):
            items.append({'kind': 'claim', 'ref': i, 'statement': f"Card: {w['card']}", 'grader': w['key']})
        if not items:
            continue
        text = cases[g['case_id']]['context']['text'] if (cases[g['case_id']].get('context') or {}).get('text') else cases[g['case_id']].get('user', '')
        src_text = text if len(text) < 30000 else windows(text, quotes.get(g['case_id'], []))
        if not src_text:
            continue
        listing = '\n'.join(f"[{i}] {it['statement']}\n    grader: {it['grader']}" for i, it in enumerate(items))
        body = {'model': 'gpt-5.4', 'reasoning': {'effort': 'medium'}, 'max_output_tokens': 4000,
                'input': [{'role': 'system', 'content': SYSTEM},
                          {'role': 'user', 'content': f"CARD\n{card(src['answer'])}\n\nDISPUTES\n{listing}\n\nSOURCE PASSAGES\n{src_text}"}],
                'text': {'format': {'type': 'json_schema', 'name': 'adjudication', 'strict': True, 'schema': SCHEMA}}}
        n = len(body['input'][1]['content']) // 3 + 600
        cid = 'adj_' + hashlib.sha256(aid.encode()).hexdigest()[:40]
        reqs.append({'custom_id': cid, '_case_id': g['case_id'], '_cfg': 'adjudicate', '_kind': 'adjudication',
                     '_answer': aid, '_items': items, '_count': n, '_reserve': exp.reserve_of(body, math.ceil(n * 1.1)),
                     'method': 'POST', 'url': '/v1/responses', 'body': body})
    exp.dump(f'{phase}.requests.json', reqs)
    print(phase, len(reqs), 'items', sum(len(r['_items']) for r in reqs), 'reserve', round(sum(r['_reserve'] for r in reqs), 3))


def card(a: dict[str, Any]) -> str:
    import judge
    return judge.card_text(a)


if __name__ == '__main__':
    prepare(*sys.argv[1:])
