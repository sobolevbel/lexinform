"""Monthly cost scenarios: production October call profile repriced with measured per-model output ratios."""

import json
import sqlite3
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).parent
EV = HERE / 'evidence'
STATE = HERE.parent / 'state' / 's.db'
BATCH = {  # (input, cached read, output) per 1M, Batch tier; long tier for >272k where it exists
    'gpt-5.1': (0.625, 0.0625, 5.0),
    'terra': (0.5, 0.025, 2.5), 'terra_long': (1.0, 0.05, 3.75),
    'sol': (1.0, 0.05, 5.0), 'sol_long': (2.0, 0.10, 7.5),
    'opus': (2.0, 0.2, 10.0),
}
CLAUDE_TOKEN_RATIO = 1.45  # Claude tokenizer / OpenAI tokenizer on the five long prints measured here
SYSTEM_PREFIX = 1456  # cacheable system+schema tokens per 6.x request (measured)


def october_profile() -> dict:
    db = sqlite3.connect(STATE)
    prof = defaultdict(lambda: defaultdict(float))
    for (st, rj) in db.execute("select started_at, report_json from runs where report_json is not null"):
        if not ('2026-09-30' <= st[:10] <= '2026-10-28'):
            continue
        for c in json.loads(rj).get('llm_calls') or []:
            if not c['model'].startswith('gpt-5.1'):
                continue
            p = prof[c['kind']]
            p['n'] += 1
            p['in'] += c.get('input_tokens', 0)
            p['cached'] += c.get('cache_read_input_tokens', 0)
            p['out'] += c.get('output_tokens', 0)
    return {k: dict(v) for k, v in prof.items()}


def paired_output_ratio(cfg: str, base: str = 'g51-med', kinds=('analysis', 'reanalysis', 'holdout')) -> float:
    rows = list({r['custom_id']: r for r in json.loads((EV / 'answers.json').read_text()) if r.get('custom_id')}.values())
    by = defaultdict(dict)
    for r in rows:
        if r.get('cfg') in (cfg, base) and r['case_id'].split('-')[0] in kinds and r.get('http') == 200:
            by[r['case_id']][r['cfg']] = r['output']
    pairs = [(v[cfg], v[base]) for v in by.values() if cfg in v and base in v]
    return sum(a for a, _ in pairs) / sum(b for _, b in pairs), len(pairs)


def price(model: str, n_in: float, cached: float, out: float) -> float:
    r = BATCH[model]
    return ((n_in) * r[0] + cached * r[1] + out * r[2]) / 1e6


def main() -> None:
    prof = october_profile()
    print(json.dumps(prof, indent=1))
    long_calls = [350877, 323535, 583712, 631651]  # >272k analyses of Sep 7 - Oct 29 (53 days), OpenAI tokens
    long_month = [n * 30 / 53 for n in long_calls]
    long_tokens = sum(long_month)
    long_n = len(long_calls) * 30 / 53
    configs = {'GPT-5.1 prod': ('gpt-5.1', 'g51-med'), 'GPT-5.1 calibrated': ('gpt-5.1', 'g51-med-v2g'),
               'Terra low v3t': ('terra', 't-low-v3t'), 'Terra low v1': ('terra', 't-low-v1'),
               'Sol medium v2': ('sol', 's-med-v2'), 'Sol medium prod': ('sol', 's-med')}
    out = {}
    for name, (fam, cfg) in configs.items():
        ratio, n = paired_output_ratio(cfg)
        main_in = sum(p['in'] for p in prof.values())
        main_cached = sum(p['cached'] for p in prof.values())
        main_out = sum(p['out'] for p in prof.values()) * ratio
        if fam == 'gpt-5.1':
            main_cost = price('gpt-5.1', main_in, main_cached, main_out)
        else:
            # 6.x: explicit mode, system prefix cached; GPT-5.1's document-level cache hits assumed lost (conservative)
            calls = sum(p['n'] for p in prof.values())
            cached = min(main_cached, calls * SYSTEM_PREFIX)
            main_cost = price(fam, main_in + main_cached - cached, cached, main_out)
        long_out = 800 * long_n * (ratio if fam != 'gpt-5.1' else 1)
        out[name] = {'output_ratio_vs_gpt51': round(ratio, 3), 'pairs': n, 'main_month_usd': round(main_cost, 3),
                     'long_on_same_model_usd': None if fam == 'gpt-5.1' else round(price(fam + '_long', long_tokens, 0, long_out), 3)}
    out['Opus overflow (current)'] = {'long_month_usd': round(price('opus', long_tokens * CLAUDE_TOKEN_RATIO, 0, 700 * long_n), 3),
                                      'long_calls_per_month': round(long_n, 2), 'long_tokens_openai': round(long_tokens)}
    print(json.dumps(out, indent=1))
    (EV / 'monthly.json').write_text(json.dumps({'profile': prof, 'scenarios': out}, indent=1))


if __name__ == '__main__':
    main()
