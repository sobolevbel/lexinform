"""Blind grading of analysis answers against the verified key (Claude Sonnet 5, Batch), plus
rule-based decision and format checks. Shares exp.py's ledger and budget."""

from __future__ import annotations

import hashlib
import json
import random
import re
import sys
from typing import Any

import exp

JUDGE_SYSTEM = """You grade one Russian-language card that summarises a Polish bill for foreigners living in Poland. You get a grading KEY (facts verified against the source, with importance, plus known misreadings) and the CARD. The key was written independently of the card. Grade strictly and literally; do not reward style.

For every key fact decide:
- "full": the card states it with the decisive specifics (who, condition, deadline/period with its starting point, amount, document, exception) correctly, in any wording or field;
- "partial": the card mentions the topic but drops or blurs a decisive specific;
- "missing": not in the card;
- "wrong": the card contradicts it (wrong group, number, direction, negation, proposal stated as adopted, etc.).
Minor facts may legitimately be left out of a short card; still grade them literally.

The card is written for foreigners living in Poland: describing how a general rule affects foreigners, or naming foreigners among those affected, is correct and is NOT a wrong claim, unless the card says the rule applies only to foreigners, targets them specifically, or gives them a scope, right or exemption the key contradicts. Card fields relevant/score/category/rationale are editorial judgements: do not list them as wrong claims unless they state a false fact.

Then list:
- trap_hits: indices of key misreadings the card commits;
- wrong_claims: card statements that contradict the key (quote the card, say what the key says);
- unsupported_claims: concrete card statements (groups, conditions, numbers, dates, documents, legal effects) that the key neither states nor contradicts; quote each exactly. Do not list generic paraphrases of key facts.
Return JSON only."""

JUDGE_SCHEMA: dict[str, Any] = {
    'type': 'object', 'additionalProperties': False,
    'required': ['facts', 'trap_hits', 'wrong_claims', 'unsupported_claims'],
    'properties': {
        'facts': {'type': 'array', 'items': {'type': 'object', 'additionalProperties': False,
                  'required': ['index', 'grade', 'note'],
                  'properties': {'index': {'type': 'integer'},
                                 'grade': {'type': 'string', 'enum': ['full', 'partial', 'missing', 'wrong']},
                                 'note': {'type': 'string'}}}},
        'trap_hits': {'type': 'array', 'items': {'type': 'integer'}},
        'wrong_claims': {'type': 'array', 'items': {'type': 'object', 'additionalProperties': False,
                         'required': ['card', 'key'], 'properties': {'card': {'type': 'string'}, 'key': {'type': 'string'}}}},
        'unsupported_claims': {'type': 'array', 'items': {'type': 'string'}},
    },
}

MODEL = 'gpt-5.4'


def card_text(a: dict[str, Any]) -> str:
    lines = [f"relevant: {a['relevant']}; score: {a['score']}; category: {a['category']}",
             f"Summary: {a['summary']}", 'Key changes:']
    lines += [f'- {x}' for x in a['key_changes']]
    lines.append('Affected groups: ' + '; '.join(a['affected_groups']))
    lines.append(f"Practical impact: {a['practical_impact']}")
    lines.append(f"Effective date: {a['effective_date']}")
    lines.append(f"Rationale: {a['rationale']}")
    if a.get('changes_since_previous'):
        lines.append('Changes since previous version:')
        lines += [f'- {x}' for x in a['changes_since_previous']]
    return '\n'.join(lines)


def key_text(key: dict[str, Any]) -> str:
    lines = [f"Bill: {key['title']}", f"Purpose: {key.get('purpose', '')}", '', 'FACTS:']
    for i, f in enumerate(key['facts']):
        lines.append(f"[{i}] ({f['importance']}) {f['fact']}")
    if key.get('traps'):
        lines += ['', 'KNOWN MISREADINGS:']
        for i, t in enumerate(key['traps']):
            lines.append(f"[{i}] {t['trap']} -> correct: {t['correct_reading']}")
    if key.get('effective_date'):
        lines += ['', f"Entry into force: {key['effective_date']}"]
    return '\n'.join(lines)


def keys() -> dict[str, Any]:
    return json.loads((exp.HERE / 'gold' / 'keys.json').read_text())


def prepare(phase: str, cfg_filter: str = '', prefix: str = 'j2_', case_filter: str = '') -> None:
    """One judge request per (answer with a key) not graded before."""
    ks = keys()
    graded = set()
    for p in exp.OUT.glob('j*.requests.json'):
        graded |= {r['custom_id'] for r in json.loads(p.read_text())}
    rows = list({r['custom_id']: r for r in exp.load('answers.json') if r.get('custom_id')}.values())
    reqs = []
    for r in rows:
        if r.get('cfg') is None or r['cfg'].startswith(('judge', 'gold', 'adjud')) or r.get('answer') is None or r['case_id'] not in ks or r['case_id'].split('-')[0] not in ('analysis', 'reanalysis', 'holdout'):
            continue
        if not (ks[r['case_id']].get('facts') or ks[r['case_id']].get('traps')):
            continue
        if cfg_filter and not re.fullmatch(cfg_filter, r['cfg']):
            continue
        if case_filter and not re.fullmatch(case_filter, r['case_id']):
            continue
        cid = prefix + hashlib.sha256(r['custom_id'].encode()).hexdigest()[:40]
        if cid in graded:
            continue
        body = {'model': MODEL, 'reasoning': {'effort': 'low'}, 'max_output_tokens': 3500,
                'input': [{'role': 'system', 'content': JUDGE_SYSTEM},
                          {'role': 'user', 'content': f"KEY\n{key_text(ks[r['case_id']])}\n\nCARD\n{card_text(r['answer'])}"}],
                'text': {'format': {'type': 'json_schema', 'name': 'grade', 'strict': True, 'schema': JUDGE_SCHEMA}}}
        n = len(body['input'][1]['content']) // 3 + 900
        reqs.append({'custom_id': cid, '_case_id': r['case_id'], '_cfg': 'judge54', '_kind': 'judge', '_answer': r['custom_id'],
                     '_count': n, '_reserve': exp.reserve_of(body, n), 'method': 'POST', 'url': '/v1/responses', 'body': body})
    random.Random(7).shuffle(reqs)
    exp.dump(f'{phase}.requests.json', reqs)
    print(phase, len(reqs), 'reserve', round(sum(r['_reserve'] for r in reqs), 3), 'committed', round(exp.committed(), 3))


if __name__ == '__main__':
    prepare(*sys.argv[1:])
