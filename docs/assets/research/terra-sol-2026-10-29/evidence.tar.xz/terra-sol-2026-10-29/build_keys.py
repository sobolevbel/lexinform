"""Merge verified extraction keys, manual long/synthetic keys and decision ranges into gold/keys.json."""

import json
from pathlib import Path

HERE = Path(__file__).parent
EV = HERE / 'evidence'
cases = {c['id']: c for c in json.loads((EV / 'cases.json').read_text())}


def f(text, imp='critical'):
    return {'fact': text, 'importance': imp}


def t(trap, correct):
    return {'trap': trap, 'correct_reading': correct}


# score range [lo, hi]; publish True/False/None(either)
DECISIONS = {
    'analysis-1039': ([3, 5], True), 'analysis-1040': ([3, 5], True), 'analysis-RCL_12408900': ([1, 3], None),
    'analysis-3143': ([2, 3], None), 'analysis-3141': ([3, 4], True), 'analysis-3146': ([2, 5], None),
    'reanalysis-RCL_12412454': ([3, 4], True), 'reanalysis-2110': ([2, 3], None), 'reanalysis-2271': ([1, 2], False),
    'reanalysis-2846': ([3, 5], True), 'reanalysis-3004': ([1, 2], False), 'reanalysis-3008': ([1, 2], False),
    'reanalysis-RCL_12410853': ([1, 2], False), 'reanalysis-3146': ([2, 5], None), 'reanalysis-3141': ([3, 4], True),
    'analysis-3160': ([2, 3], None), 'analysis-3157': ([1, 3], None), 'reanalysis-RCL_12402353': ([2, 4], None),
    'analysis-950': ([4, 5], True), 'analysis-1962': ([1, 2], False), 'analysis-2699': ([2, 3], None),
    'analysis-3039': ([3, 5], True), 'analysis-319': ([3, 4], True), 'analysis-276': ([1, 3], None),
    'analysis-1407': ([1, 2], False), 'analysis-825': ([1, 3], None), 'analysis-WPL_UD368': ([4, 5], True),
    'analysis-WPL_UD338': ([2, 4], None), 'analysis-fresh-3156': ([1, 2], False), 'analysis-fresh-3126': ([2, 4], None),
    'analysis-fresh-3135-corrected': ([1, 2], False), 'analysis-scan-RPW-2793-2025-corrected': ([3, 5], True),
    'analysis-edge-1894-corrected': ([1, 2], False), 'analysis-edge-2360-corrected': ([1, 1], False),
    'analysis-RCL_12398102': ([2, 4], None), 'analysis-RCL_12399355': ([4, 5], True), 'analysis-1630': ([4, 5], True),
    'analysis-342': ([3, 5], True), 'analysis-edge-878': ([1, 3], None),
    'analysis-3150': ([1, 2], False), 'reanalysis-3150': ([1, 2], False), 'analysis-3139': ([1, 3], None),
    'analysis-3140': ([1, 3], None), 'analysis-edge-2355': ([1, 3], None),
    # synthetic
    'analysis-control-deadline': ([5, 5], True), 'analysis-control-work': ([4, 4], True),
    'analysis-control-social': ([3, 3], True), 'analysis-control-agency': ([1, 1], False),
    'analysis-control-uncertain': ([3, 5], True), 'reanalysis-control-changed': ([4, 5], True),
    'reanalysis-control-unchanged': ([4, 5], True), 'analysis-new-return_origin': ([2, 5], None),
    'analysis-new-return_destination': ([3, 5], True), 'analysis-new-course_eligibility': ([3, 3], True),
    'reanalysis-new-omitted_detail': ([1, 3], None), 'reanalysis-new-actual_changed_amount': ([3, 5], True),
    'analysis-maxguard-budget_existing': ([1, 1], False), 'analysis-maxguard-funding_new_right': ([3, 3], True),
    'analysis-maxguard-bilateral_ratification': ([1, 2], False), 'analysis-maxguard-patient_without_pesel': ([3, 3], True),
    'analysis-maxguard-generic_hospital_budget': ([1, 1], False), 'analysis-v3guard-consent_and_refund': ([3, 3], True),
    'analysis-v3guard-lookback_five': ([2, 3], None), 'analysis-v3guard-foreign_relationship': ([1, 3], None),
    'analysis-v3guard-no_criminal_record': ([3, 3], True), 'analysis-stability-mixed': ([3, 5], True),
}

# expected changes_since_previous behaviour for reanalysis controls
NAMES_CHANGES = {'reanalysis-control-changed': True, 'reanalysis-control-unchanged': False,
                 'reanalysis-new-omitted_detail': False, 'reanalysis-new-actual_changed_amount': True}

MANUAL = {
    'analysis-3139': ([f('Kyrgyzstan readmits its own nationals who do not or no longer meet EU entry/stay conditions, at a member state request, without further formalities (and EU states readmit their nationals)'),
                       f('National law of the member states on entry, stay, work and visas continues to apply; the agreement gives no directly enforceable individual rights', 'important'),
                       f('The ratification act enters into force 14 days after publication; the agreement itself on the first day of the second month after the parties exchange notifications', 'important'),
                       f('Kyrgyz consulates may protect Kyrgyz citizens in EU states without own representation (consular cooperation)', 'minor')],
                      [t('Readmission described as Poland/EU returning people to Poland or as new rights of entry', 'Kyrgyzstan takes back its own irregular nationals from EU states'),
                       t('Agreement presented as easing visas, residence or work permits for Kyrgyz citizens', 'national rules unchanged; at most future dialogue on visa facilitation')]),
    'analysis-3140': ([f('Uzbekistan and EU states readmit their own nationals who do not meet entry/stay conditions'),
                       f('National law on entry, stay and work continues to apply; no directly enforceable individual rights', 'important'),
                       f('The ratification act enters into force 14 days after publication; the agreement on the first day of the second month after the last notification', 'important'),
                       f('Parties may start negotiations on visa facilitation / dialogue on legal migration', 'minor')],
                      [t('Readmission direction reversed', 'each party takes back its own irregular nationals'),
                       t('Agreement presented as immediate easing of visas or permits', 'only possible future negotiations')]),
    'analysis-3150': ([f('The 2027 budget only funds existing tasks and programmes (UdSC, aid to foreigners, Karta Polaka lines); it creates no new individual rights, conditions or procedures for foreigners'),
                       f('Expenditure lines for UdSC and assistance to foreigners are amounts of funding, not entitlements', 'important')],
                      [t('Funding lines for foreigners presented as new benefits or rights, or the budget rated as important news', 'funding of existing programmes; score 1')]),
    'reanalysis-3150': None,
    'analysis-edge-2355': ([f('Background checks of persons in critical entities: for a citizen of another EU state, the KRK information bureau asks the central authority of the state of citizenship for criminal-record information'),
                            f('Non-penetrating projectiles in collective disturbances need a warning shot except inside detention facilities including guarded centres and arrest for foreigners', 'important')],
                           [t('General crisis-management bill presented as a migration law', 'only narrow procedural provisions concern foreigners')]),
}
MANUAL['reanalysis-3150'] = MANUAL['analysis-3150']

SYNTH = {
    'analysis-control-deadline': [f('Citizens of Ukraine whose stay is considered legal keep that status until 30 September 2027'), f('Enters into force 14 days after publication', 'important')],
    'analysis-control-work': [f('A foreigner holding a permanent residence permit may work without a work permit'), f('Enters into force 30 days after publication', 'important')],
    'analysis-control-social': [f('Upbringing benefit of 800 zł per month for foreigners with a permanent residence permit'), f('Not available to holders of only a tourist visa')],
    'analysis-control-agency': [f('Border Guard tests quality of imported feed; nothing changes for foreigners')],
    'analysis-control-uncertain': [f('The bill amends the Act on foreigners but the rest of the text is missing (truncated); content unknown')],
    'reanalysis-control-changed': [f('Legal stay of Ukrainians extended to 30 September 2027 (previously described as 30 June 2027)'), f('Enters into force 14 days after publication', 'important')],
    'reanalysis-control-unchanged': [f('Legal stay of Ukrainians extended to 30 June 2027, same as before'), f('Enters into force 14 days after publication', 'important')],
    'analysis-new-return_origin': [f('Return operations organised in Poland send foreigners FROM Poland to third countries'), f('No right of entry into Poland is created', 'important')],
    'analysis-new-return_destination': [f('Foreigners with a valid permanent residence permit may return TO Poland after travelling abroad'), f('The provision does not concern expulsion', 'important')],
    'analysis-new-course_eligibility': [f('Foreigners attending Polish-language courses are covered by health insurance if not insured on another basis'), f('Medical graduates on practical training are covered on the same basis', 'important')],
    'reanalysis-new-omitted_detail': [f('Health insurance and reimbursement of treatment abroad'), f('Minister may grant an expert-centre status for 5 years', 'minor')],
    'reanalysis-new-actual_changed_amount': [f('Residence card fee is 200 zł (previous description said 100 zł)')],
    'analysis-maxguard-budget_existing': [f('Budget allocates 50 million zł to long-standing aid for foreigners; no change in eligibility, benefits or procedures')],
    'analysis-maxguard-funding_new_right': [f('A foreigner with permanent residence acquires a new benefit of 200 zł per month'), f('50 million zł is allocated to pay it', 'minor')],
    'analysis-maxguard-bilateral_ratification': [f('Ratification of a partnership agreement with state X; business visits up to 90 days subject to national law'), f('Polish rules on visas, residence and work permits do not change', 'important')],
    'analysis-maxguard-patient_without_pesel': [f('A person entitled to NFZ benefits without a PESEL may apply for reimbursement giving a valid passport number'), f('A copy of the passport must be attached', 'important'), f('Enters into force 30 days after publication', 'minor')],
    'analysis-maxguard-generic_hospital_budget': [f('10 million zł for hospital beds; foreigners only mentioned among patients in the justification; no rights change')],
    'analysis-v3guard-consent_and_refund': [f('Applies to persons insured by NFZ treated in another EU state'), f('For urgent life-saving treatment the consent application may be filed after treatment, within 18 days of the end of treatment'), f('A separate refund application must be filed within 40 days of paying the invoice'), f('Neither application gives an automatic right to payment', 'important')],
    'analysis-v3guard-lookback_five': [f('Non-EU volunteers admitted to work with children must provide criminal-record information'), f('From the state of citizenship and states of residence over the last 5 years'), f('No documents from Poland are required', 'important')],
    'analysis-v3guard-foreign_relationship': [f('Cohabitation agreement before a notary; excluded for persons in a marriage or a registered union concluded under foreign law even if not recognised as marriage in Poland'), f('The agreement gives no right of residence')],
    'analysis-v3guard-no_criminal_record': [f('A foreigner with permanent residence raising a child under 12 gets a benefit of 50 zł per month'), f('A copy of a valid passport must be attached', 'important'), f('A foreigner staying only on a tourist visa is not entitled')],
    'analysis-stability-mixed': [f('Visa-fee exemption subject to registration proof'), f('Non-EU volunteers working with children provide criminal records from citizenship and residence countries for the last seven years'), f('Preparatory-course participants are health-insured if not insured on another basis')],
}
SYNTH_TRAPS = {
    'reanalysis-new-omitted_detail': [t('changes_since_previous lists the expert-centre status as a new change', 'absence from the previous short summary is not evidence of a change; changes_since_previous should be empty')],
    'reanalysis-control-unchanged': [t('changes_since_previous names a change', 'nothing changed; leave empty')],
    'analysis-v3guard-lookback_five': [t('ten-year lookback', 'five years')],
    'analysis-v3guard-no_criminal_record': [t('criminal record or residence-history conditions added', 'only permanent residence, child under 12, passport copy')],
    'analysis-v3guard-consent_and_refund': [t('refund application within 18 days', '18 days is for the consent application; refund within 40 days of paying')],
    'analysis-stability-mixed': [t('five-year or ten-year lookback', 'seven years')],
    'analysis-new-return_origin': [t('returning foreigners to Poland', 'sending them from Poland')],
    'analysis-new-return_destination': [t('described as expulsion', 'return to Poland of permanent residents')],
    'analysis-maxguard-budget_existing': [t('funding presented as new right', 'existing aid, nothing changes')],
}


# Source-checked corrections of extracted key facts: (case, substring of the fact) -> replacement.
KEY_FIXES = {
    ('reanalysis-2846', 'For a volunteer who is an EU citizen, the organizer must obtain'):
        'For a volunteer who is an EU citizen, the organizer must obtain from the volunteer criminal-record information from the countries of residence in the last 10 years that are NOT EU member states (or general certificates where such countries issue none for this purpose).',
    ('analysis-319', 'Article 127'):
        'Foreigners holding a temporary residence permit under Article 127 of the Foreigners Act (EU Blue Card, highly qualified employment) are entitled to the benefits.',
}


def fix(cid: str, facts: list) -> list:
    out = []
    for x in facts:
        x = dict(x)
        for (case, needle), text in KEY_FIXES.items():
            if case == cid and needle in x['fact']:
                x['fact'] = text
        out.append(x)
    return out


def main() -> None:
    keys = {}
    extracted = {}
    for name in ('gold1.verified.json', 'gold54.verified.json', 'gold54b.flex.verified.json'):
        p = EV / name
        if p.exists():
            extracted.update(json.loads(p.read_text()))
    for cid in ('reanalysis-3141', 'reanalysis-3146'):
        extracted.setdefault(cid, extracted.get(cid.replace('reanalysis-', 'analysis-')))
    extracted = {k: v for k, v in extracted.items() if v}
    for cid, (rng, pub) in DECISIONS.items():
        c = cases[cid]
        title = (c.get('context') or {}).get('title') or 'Projekt kontrolny'
        k = {'title': title, 'score': rng, 'publish': pub}
        if cid in extracted:
            e = extracted[cid]
            k.update(purpose=e['bill_purpose'], facts=fix(cid, [{'fact': x['fact'], 'importance': x['importance']} for x in e['foreigner_facts'] if x['quote_found']]),
                     traps=[{'trap': x['trap'], 'correct_reading': x['correct_reading']} for x in e['traps']],
                     effective_date=(e['effective_date'] or {}).get('rule'), key_source='extraction')
        elif cid in MANUAL:
            k.update(purpose='', facts=MANUAL[cid][0], traps=MANUAL[cid][1], key_source='manual')
        elif cid in SYNTH:
            k.update(purpose='synthetic control', facts=SYNTH[cid], traps=SYNTH_TRAPS.get(cid, []), key_source='synthetic')
        else:
            k.update(purpose='', facts=[], traps=[], key_source='decision_only')
        if cid in NAMES_CHANGES:
            k['names_changes'] = NAMES_CHANGES[cid]
        keys[cid] = k
    hd = json.loads((HERE / 'gold' / 'holdout_decisions.json').read_text())
    for cid, d in hd.items():
        e = extracted.get(cid)
        k = {'title': cases[cid]['context']['title'], 'score': d['score'], 'publish': d['publish'], 'note': d['note']}
        if e:
            k.update(purpose=e['bill_purpose'], facts=fix(cid, [{'fact': x['fact'], 'importance': x['importance']} for x in e['foreigner_facts'] if x['quote_found']]),
                     traps=[{'trap': x['trap'], 'correct_reading': x['correct_reading']} for x in e['traps']],
                     effective_date=(e['effective_date'] or {}).get('rule'), key_source='extraction')
        else:
            k.update(purpose='', facts=[], traps=[], key_source='decision_only')
        keys[cid] = k
    (HERE / 'gold' / 'keys.json').write_text(json.dumps(keys, ensure_ascii=False, indent=1))
    from collections import Counter
    print(len(keys), Counter(k['key_source'] for k in keys.values()))


if __name__ == '__main__':
    main()
