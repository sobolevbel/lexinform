"""Grading-key extraction on gpt-5.4 (not a candidate), OpenAI Batch, through exp.py's guard."""

from __future__ import annotations

import copy
import json
import math
import sys
from typing import Any

import exp
import gold

MODEL = 'gpt-5.4'


def strict(schema: dict[str, Any]) -> dict[str, Any]:
    s = copy.deepcopy(schema)
    ed = s['properties']['effective_date']
    s['properties']['effective_date'] = {'type': ['object', 'null'], 'additionalProperties': False,
                                         'required': ['rule', 'quote'],
                                         'properties': {'rule': {'type': 'string'}, 'quote': {'type': 'string'}}}
    del ed
    return s


def prepare(phase: str, selector: str) -> None:
    cases = exp.select(exp.load('cases.json'), selector)
    client = exp.oai()
    reqs = []
    for c in cases:
        if not (c.get('context') or {}).get('text'):
            continue
        body = {'model': MODEL, 'reasoning': {'effort': 'medium'}, 'max_output_tokens': 32000,
                'input': [{'role': 'system', 'content': gold.GOLD_SYSTEM + ' List at most 25 foreigner_facts, most important first; keep each fact under 300 characters.'},
                          {'role': 'user', 'content': gold.gold_text(c)}],
                'text': {'format': {'type': 'json_schema', 'name': 'grading_key', 'strict': True,
                                    'schema': strict(gold.GOLD_SCHEMA)}}}
        n = client.responses.input_tokens.count(model=MODEL, input=body['input'], text=body['text'],
                                                reasoning=body['reasoning']).input_tokens
        bound = n + max(1024, math.ceil(n * 0.02))
        reqs.append({'custom_id': f"{c['id']}~gold54b", '_case_id': c['id'], '_cfg': 'gold54b', '_kind': 'gold',
                     '_count': n, '_reserve': exp.reserve_of(body, bound), 'method': 'POST',
                     'url': '/v1/responses', 'body': body})
        print(c['id'], n, flush=True)
    exp.dump(f'{phase}.requests.json', reqs)
    print(phase, len(reqs), 'reserve', round(sum(r['_reserve'] for r in reqs), 3), 'committed', round(exp.committed(), 3))


if __name__ == '__main__':
    prepare(*sys.argv[1:])
