"""Print merged keyword windows of a frozen case text for manual gold building."""
import json, re, sys
from pathlib import Path
from lexinform.keywords import KeywordPrefilter, WEAK_PATTERNS
cases = {c['id']: c for c in json.loads((Path(__file__).parent / 'evidence/cases.json').read_text())}
cid, width, limit = sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 500, int(sys.argv[3]) if len(sys.argv) > 3 else 12000
extra = sys.argv[4] if len(sys.argv) > 4 else None
text = cases[cid]['context']['text']
spans = KeywordPrefilter().spans(text)
if extra:
    spans = sorted(spans + [(m.start(), m.end()) for m in re.finditer(extra, text, re.I)])
merged = []
for s, e in spans:
    s, e = max(0, s - width), min(len(text), e + width)
    if merged and s <= merged[-1][1]:
        merged[-1][1] = max(merged[-1][1], e)
    else:
        merged.append([s, e])
print(cid, 'chars', len(text), 'windows', len(merged))
out = 0
for s, e in merged:
    chunk = re.sub(r'\s+', ' ', text[s:e])
    print(f'\n[{s}] {chunk}')
    out += len(chunk)
    if out > limit:
        print('\n...LIMIT'); break
