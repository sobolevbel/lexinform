# Lexinform GPT-6.1 Terra / Sol evaluation, 2026-10-29

Historical evidence, not a resubmission package. Production code, configuration, state and publications were not changed. Never run submit, flex, count or preparation commands automatically from this archive: historical authorization and budgets do not authorize a new charge.

Start with `evidence/score-*-pooled.json`, `evidence/monthly.json`, `evidence/ledger.json`, `gold/keys.json` and `gold/holdout_decisions.json`. `evidence/cases.json` holds the frozen inputs; `configs.json` and `prompts/` define each configuration; `exp.py:body_for` rebuilds every request body. `evidence/requests-index.json` lists every paid request with model, effort, cache mode, counted input and reservation; full request bodies are omitted (rebuildable). `*.parsed.json` hold every answer with usage and price. `judge54`/`adjudicate` rows are grading and source adjudication. The Sonnet 5 extraction (`gold1`) cost USD 6.04 on Anthropic, above the USD 3 cap the user named after submission.

Scripts refer to the original scratch workspace and the lexinform checkout, and read credentials from lexinform settings; no credentials are included.
