"""Terra/Sol evaluation harness, 2026-10-29. Builds production-shaped batch requests, guards a hard
budget with reservations, submits, collects and prices every answer from actual usage."""

from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import math
import random
import sys
import time
from pathlib import Path
from typing import Any

import anthropic
from openai import OpenAI

from lexinform.adapters import llm_openai as lo
from lexinform.adapters import llm_prompts as prompts
from lexinform.concurrency import fan_out
from lexinform.models import Amendments, Analysis, BillContext, DocumentDigest, JointComparison
from lexinform.models import BillName
from lexinform.models.sejm import applicant_from_title
from lexinform.sections import trim_print
from lexinform.settings import Settings

HERE = Path(__file__).parent
OUT = HERE / 'evidence'
PREV = HERE.parent / 'terra_prev/terra-2026-10-27/evidence'
CORPUS = Path('/Users/sobaleu/projects/lexinform-corpus')
BUDGETS = {'openai': 68.5, 'anthropic': 2.9}
LONG = 272_000

# Batch USD per 1M tokens: (input, cached read, 30m cache write, output), short and long (>272k) tier.
RATES = {
    'gpt-5.4': ((1.25, 0.125, 1.25, 7.5), (2.5, 0.25, 2.5, 11.25)),
    'gpt-5.1': ((0.625, 0.0625, 0.625, 5.0), None),
    'gpt-6.1-terra': ((0.5, 0.025, 0.625, 2.5), (1.0, 0.05, 1.25, 3.75)),
    'gpt-6.1-sol': ((1.0, 0.05, 1.25, 5.0), (2.0, 0.10, 2.5, 7.5)),
    'claude-opus-5-5': ((2.0, 0.2, 2.5, 10.0), None),
    'claude-sonnet-5': ((1.0, 0.1, 1.25, 5.0), None),
}
SCHEMAS = {'analysis': ('analysis', lo._ANALYSIS_SCHEMA, Analysis),
           'reanalysis': ('analysis', lo._ANALYSIS_SCHEMA, Analysis),
           'amendments': ('amendments', lo._AMENDMENTS_SCHEMA, Amendments),
           'supplement': ('document_digest', lo._DOCUMENT_DIGEST_SCHEMA, DocumentDigest),
           'joint': ('joint_comparison', lo._JOINT_COMPARISON_SCHEMA, JointComparison),
           'name': ('bill_name', lo._BILL_NAME_SCHEMA, BillName)}
PROD_SYSTEM = {'analysis': prompts.gpt51_system_prompt, 'reanalysis': prompts.gpt51_system_prompt,
               'amendments': prompts.gpt51_amendments_system_prompt,
               'supplement': prompts.gpt51_supplement_system_prompt,
               'joint': prompts.gpt51_joint_system_prompt, 'name': prompts.name_system_prompt}


def load(name: str) -> Any:
    return json.loads((OUT / name).read_text())


def dump(name: str, value: Any) -> None:
    OUT.mkdir(exist_ok=True)
    target = OUT / name
    tmp = target.with_suffix(target.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=1))
    tmp.replace(target)


def oai() -> OpenAI:
    return OpenAI(api_key=Settings().openai_api_key, max_retries=2, timeout=120)


def claude() -> anthropic.Anthropic:
    return anthropic.Anthropic(api_key=Settings().anthropic_api_key, max_retries=2)


def family(model: str) -> str:
    return next(k for k in RATES if model.startswith(k))


def price(model: str, n_input: int, cached: int, written: int, output: int) -> float:
    short, long = RATES[family(model)]
    r = long if (long and n_input > LONG) else short
    plain = n_input - cached - written
    return (plain * r[0] + cached * r[1] + written * r[2] + output * r[3]) / 1e6


# ---------------------------------------------------------------- cases

def holdout_context(number: str) -> BillContext:
    meta = json.loads((CORPUS / 'sejm/term10/prints' / f'{number}.json').read_text())
    with gzip.open(CORPUS / 'sejm/term10/text' / f'{number}.txt.gz', 'rt') as h:
        text = trim_print(h.read()).text
    return BillContext(number=number, title=meta['title'], description=meta.get('description'),
                       document_date=meta.get('documentDate'),
                       applicant_type=applicant_from_title(meta['title']), text=text,
                       truncated=False, text_source='pdf')


def prepare() -> None:
    if (OUT / 'cases.json').exists():
        raise SystemExit('cases.json exists; frozen')
    prev = json.loads((PREV / 'cases.json').read_text())
    superseded = {'analysis-fresh-3135', 'analysis-scan-RPW-2793-2025', 'analysis-edge-1894',
                  'analysis-edge-2360'}
    long_ids = {'analysis-3150', 'reanalysis-3150', 'analysis-3139', 'analysis-3140',
                'analysis-edge-2355'}
    large_ids = {'analysis-edge-878', 'analysis-RCL_12398102', 'analysis-1630',
                 'analysis-RCL_12399355', 'analysis-342'}
    cases = []
    for c in prev:
        if c['id'] in superseded or c['kind'] in ('change_review', 'triage'):
            continue
        c = copy.deepcopy(c)
        c.pop('system', None)
        if c['id'] in long_ids:
            c['set'] = 'long'
        elif c['id'] in large_ids:
            c['set'] = 'large'
        elif c['kind'] in ('analysis', 'reanalysis'):
            c['set'] = 'calib_real' if c.get('chars') or c.get('pdf') or c['source'].startswith('real') else 'calib_synth'
        else:
            c['set'] = 'secondary'
        if c['kind'] in ('analysis', 'reanalysis') and c.get('context') and not c.get('pdf'):
            c['user'] = prompts.build_user_prompt(BillContext.model_validate(c['context']))
        cases.append(c)
    for number in json.loads((HERE / 'holdout_draw.json').read_text()):
        ctx = holdout_context(number)
        cases.append({'id': f'holdout-{number}', 'number': number, 'kind': 'analysis',
                      'set': 'holdout', 'source': 'corpus_print_random_draw_seed_20261029',
                      'context': ctx.model_dump(mode='json'), 'chars': len(ctx.text or ''),
                      'user': prompts.build_user_prompt(ctx)})
    dump('cases.json', cases)
    print(len(cases), {s: sum(c['set'] == s for c in cases) for s in {c['set'] for c in cases}})


def add_cases(path: str) -> None:
    """Append extra frozen cases (names, probes) from a JSON list; ids must be new."""
    cases = load('cases.json')
    have = {c['id'] for c in cases}
    extra = json.loads(Path(path).read_text())
    for c in extra:
        if c['id'] in have:
            raise SystemExit(f"duplicate {c['id']}")
    dump('cases.json', cases + extra)
    print('added', len(extra))


# ---------------------------------------------------------------- requests

def system_for(case: dict[str, Any], variant: str) -> str:
    base = PROD_SYSTEM[case['kind']]('ru')
    if variant == 'prod':
        return base
    patches = json.loads((HERE / 'prompts' / f'{variant}.json').read_text())
    add = patches.get(case['kind']) or patches.get('analysis' if case['kind'] == 'reanalysis' else '', '')
    replace = patches.get('replace', {}) if case['kind'] in ('analysis', 'reanalysis') else {}
    for old, new in replace.items():
        if old not in base:
            raise SystemExit(f'patch anchor missing: {old[:60]}')
        base = base.replace(old, new)
    return base + add


def body_for(case: dict[str, Any], cfg: dict[str, Any]) -> dict[str, Any]:
    model = cfg['model']
    name, schema, _ = SCHEMAS[case['kind']]
    system = system_for(case, cfg.get('prompt', 'prod'))
    content: Any = case['user']
    if case.get('pdf'):
        content = [{'type': 'input_file', 'filename': 'document.pdf',
                    'file_data': 'data:application/pdf;base64,' + case['pdf']},
                   {'type': 'input_text', 'text': case['user']}]
    body: dict[str, Any] = {'model': model}
    cache = cfg.get('cache', 'none')
    if model.startswith('gpt-5.1'):
        body.update(lo._cache_options(model, system, name))
    elif cache == 'none':
        body['prompt_cache_options'] = {'mode': 'explicit'}
    elif cache == 'system':
        body['prompt_cache_options'] = {'mode': 'explicit'}
    elif cache == 'implicit':
        body['prompt_cache_options'] = {'mode': 'implicit'}
    # cache == 'default': send nothing, observe provider default
    if cfg['effort'] != 'none' or not model.startswith('gpt-5.1'):
        body['reasoning'] = {'effort': cfg['effort']}
    body['max_output_tokens'] = cfg.get('max_output') or (8000 if case['kind'] in ('analysis', 'reanalysis') else 4000)
    if cache == 'system':
        sys_msg = {'role': 'system', 'content': [{'type': 'input_text', 'text': system,
                                                  'prompt_cache_breakpoint': {'mode': 'explicit'}}]}
    else:
        sys_msg = {'role': 'system', 'content': system}
    body['input'] = [sys_msg, {'role': 'user', 'content': content}]
    body['text'] = {'format': {'type': 'json_schema', 'name': name, 'schema': schema, 'strict': True}}
    return body


def configs() -> dict[str, dict[str, Any]]:
    return json.loads((HERE / 'configs.json').read_text())


def count(phase: str, cfg_names: list[str], selector: str) -> None:
    """Build requests for configs x selected cases, count input tokens server-side, reserve cost."""
    cases = load('cases.json')
    chosen = select(cases, selector)
    cfgs = configs()
    counts = load('counts.json') if (OUT / 'counts.json').exists() else {}
    client = oai()
    reqs = []
    for cfg_name in cfg_names:
        cfg = cfgs[cfg_name]
        for c in chosen:
            reqs.append({'custom_id': f"{c['id']}~{cfg_name}", '_case_id': c['id'], '_cfg': cfg_name,
                         'method': 'POST', 'url': '/v1/responses', 'body': body_for(c, cfg)})

    def n_tokens(r: dict[str, Any]) -> int:
        b = r['body']
        key = hashlib.sha256(json.dumps([b['model'], b['input'], b['text'], b.get('reasoning')],
                                        ensure_ascii=False, sort_keys=True).encode()).hexdigest()
        if key in counts:
            return counts[key]
        for attempt in range(4):
            try:
                kw = dict(model=b['model'], input=b['input'], text=b['text'])
                if b.get('reasoning'):
                    kw['reasoning'] = b['reasoning']
                n = client.responses.input_tokens.count(**kw).input_tokens
                counts[key] = n
                return n
            except Exception as e:  # noqa: BLE001
                if attempt == 3:
                    raise
                print('count retry', r['custom_id'], str(e)[:200], flush=True)
                time.sleep(2 ** attempt)
        raise AssertionError

    done = []
    for outcome in fan_out(reqs, n_tokens, workers=6):
        r = outcome.item
        n = outcome.result()
        bound = n + max(1024, math.ceil(n * 0.02))
        r['_count'] = n
        r['_reserve'] = reserve_of(r['body'], bound)
        done.append(r)
    dump('counts.json', counts)
    dump(f'{phase}.requests.json', done)
    print(phase, len(done), 'reserve', round(sum(r['_reserve'] for r in done), 4),
          'committed', round(committed(), 4))


def reserve_of(body: dict[str, Any], bound: int) -> float:
    model = body['model']
    may_write = not model.startswith('gpt-5.1') and body.get('prompt_cache_options', {}).get('mode') != 'explicit'
    short, long = RATES[family(model)]
    out_rate = (long if (long and bound > LONG) else short)[3]
    return price(model, bound, 0, bound if may_write else 0, 0) + body['max_output_tokens'] * out_rate / 1e6


def select(cases: list[dict[str, Any]], selector: str) -> list[dict[str, Any]]:
    out = []
    for part in selector.split(','):
        if part.startswith('set:'):
            out += [c for c in cases if c['set'] == part[4:]]
        elif part.startswith('id:'):
            out += [c for c in cases if c['id'] == part[3:]]
        elif part.startswith('kind:'):
            out += [c for c in cases if c['kind'] == part[5:]]
    seen, uniq = set(), []
    for c in out:
        if c['id'] not in seen:
            seen.add(c['id'])
            uniq.append(c)
    if not uniq:
        raise SystemExit('empty selection')
    return uniq


def ledger() -> dict[str, Any]:
    return load('ledger.json') if (OUT / 'ledger.json').exists() else {'budgets_usd': BUDGETS, 'batches': {}}


def committed(provider: str = 'openai') -> float:
    return sum(b.get('actual_usd', b['reserved_usd']) for b in ledger()['batches'].values()
               if b.get('provider', 'openai') == provider)


def submit(phase: str, split: int = 0) -> None:
    led = ledger()
    if phase in led['batches'] or any(k.startswith(phase + '.') for k in led['batches']):
        raise SystemExit('existing submission intent: never retry automatically')
    reqs = load(f'{phase}.requests.json')
    reserve = sum(r['_reserve'] for r in reqs)
    if committed() + reserve > BUDGETS['openai']:
        raise SystemExit(f'budget reservation rejected: {committed() + reserve:.4f}')
    groups: dict[str, list[dict[str, Any]]] = {}
    for r in reqs:
        groups.setdefault(r['body']['model'], []).append(r)
    client = oai()
    for model, rs in groups.items():
        chunks = [rs] if not split else [rs[i:i + split] for i in range(0, len(rs), split)]
        for i, chunk in enumerate(chunks):
            key = f'{phase}.{model}.{i}'
            path = OUT / f'{key}.jsonl'
            path.write_text('\n'.join(json.dumps({k: v for k, v in r.items() if not k.startswith('_')}, ensure_ascii=False) for r in chunk) + '\n')
            led['batches'][key] = {'reserved_usd': sum(r['_reserve'] for r in chunk), 'requests': len(chunk),
                                   'ids': [r['custom_id'] for r in chunk], 'status': 'uploading', 'provider': 'openai'}
            dump('ledger.json', led)
            with path.open('rb') as h:
                f = client.files.create(file=h, purpose='batch')
            led['batches'][key].update(file_id=f.id, status='submitting_uncertain')
            dump('ledger.json', led)
            b = client.batches.create(input_file_id=f.id, endpoint='/v1/responses', completion_window='24h',
                                      metadata={'experiment': 'lexinform-terra-sol-20261029', 'phase': key[:500]})
            led['batches'][key].update(batch_id=b.id, status=b.status)
            dump('ledger.json', led)
            print(key, b.id, b.status, len(chunk), round(led['batches'][key]['reserved_usd'], 4), flush=True)
    print('committed now', round(committed(), 4))


def parse_openai(raw: dict[str, Any], req: dict[str, Any]) -> dict[str, Any]:
    response = raw.get('response') or {}
    body = response.get('body') or {}
    usage = body.get('usage') or {}
    n = usage.get('input_tokens', 0)
    det = usage.get('input_tokens_details') or {}
    read, written = det.get('cached_tokens', 0) or 0, det.get('cache_write_tokens', 0) or 0
    out = usage.get('output_tokens', 0)
    reasoning = (usage.get('output_tokens_details') or {}).get('reasoning_tokens', 0)
    model = req['body']['model']
    texts = [p.get('text', '') for m in body.get('output', []) if m.get('type') == 'message'
             and m.get('phase') in (None, 'final_answer') for p in m.get('content', []) if p.get('type') == 'output_text']
    kind = req.get('_kind') or req['_case_id'].split('-')[0]
    answer, error = None, None
    try:
        if kind in SCHEMAS:
            answer = SCHEMAS[kind][2].model_validate_json(''.join(texts)).model_dump(mode='json')
        else:
            answer = json.loads(''.join(texts))
    except (ValueError, KeyError) as e:
        error = str(e)[:300]
    return {'custom_id': raw['custom_id'], 'case_id': req['_case_id'], 'cfg': req['_cfg'], 'model': model, 'answer_id': req.get('_answer'),
            'status': body.get('status'), 'http': response.get('status_code'), 'answer': answer,
            'validation_error': error, 'input': n, 'cached': read, 'cache_write': written, 'output': out,
            'reasoning': reasoning, 'usd': price(model, n, read, written, out),
            'error': raw.get('error') or body.get('error'), 'incomplete': body.get('incomplete_details')}


def collect() -> None:
    led = ledger()
    client = oai()
    reqs: dict[str, dict[str, Any]] = {}
    for p in OUT.glob('*.requests.json'):
        for r in json.loads(p.read_text()):
            reqs[r['custom_id']] = r
    for key, rec in led['batches'].items():
        if 'actual_usd' in rec or rec.get('provider') == 'anthropic' or 'batch_id' not in rec:
            continue
        b = client.batches.retrieve(rec['batch_id'])
        rec['status'] = b.status
        rec['counts'] = b.request_counts.model_dump() if b.request_counts else None
        if b.status in ('completed', 'failed', 'expired', 'cancelled'):
            rows = []
            if b.output_file_id:
                text = client.files.content(b.output_file_id).text
                (OUT / f'{key}.results.jsonl').write_text(text)
                rows = [parse_openai(json.loads(line), reqs[json.loads(line)['custom_id']]) for line in text.splitlines()]
            if b.error_file_id:
                (OUT / f'{key}.errors.jsonl').write_text(client.files.content(b.error_file_id).text)
            if b.errors:
                rec['errors'] = [e.model_dump() for e in b.errors.data]
            rec['actual_usd'] = sum(r['usd'] for r in rows)
            dump(f'{key}.parsed.json', rows)
        dump('ledger.json', led)
        print(key, b.status, rec.get('counts'), rec.get('actual_usd'), rec.get('errors'), flush=True)
    rows = []
    for p in sorted(OUT.glob('*.parsed.json')):
        rows += json.loads(p.read_text())
    dump('answers.json', rows)
    pend = [k for k, v in led['batches'].items() if 'actual_usd' not in v]
    print('answers', len(rows), 'committed', round(committed(), 4), 'pending', pend)


def answered() -> set[str]:
    rows = []
    for p in OUT.glob('*.parsed.json'):
        rows += json.loads(p.read_text())
    return {r['custom_id'] for r in rows if r.get('custom_id') and r.get('http') == 200}


def flex(phase: str, workers: int = 8) -> None:
    """Run a prepared request file synchronously on the flex tier (Batch prices), crash-safe and resumable."""
    reqs = [r for r in load(f'{phase}.requests.json') if r['custom_id'] not in answered()]
    raw_path = OUT / f'{phase}.flex.results.jsonl'
    done_ids = {x['custom_id'] for x in map(json.loads, raw_path.read_text().splitlines()) if x['response']['status_code'] == 200} if raw_path.exists() else set()
    reqs = [r for r in reqs if r['custom_id'] not in done_ids]
    key = f'{phase}.flex'
    import fcntl
    lk = open(OUT / 'ledger.lock', 'w')
    fcntl.flock(lk, fcntl.LOCK_EX)
    led = ledger()
    prev = led['batches'].get(key, {})
    reserve = sum(r['_reserve'] for r in reqs)
    if committed() - prev.get('actual_usd', prev.get('reserved_usd', 0)) + prev.get('actual_usd', 0) + reserve > BUDGETS['openai']:
        raise SystemExit(f'budget reservation rejected: {committed() + reserve:.4f}')
    led['batches'][key] = {'reserved_usd': prev.get('actual_usd', 0) + reserve, 'requests': len(reqs) + len(done_ids),
                           'provider': 'openai', 'status': 'running', 'tier': 'flex'}
    dump('ledger.json', led)
    lk.close()
    client = oai().with_options(timeout=1800, max_retries=0)

    def call(r: dict[str, Any]) -> dict[str, Any]:
        body = dict(r['body'])
        body['service_tier'] = 'flex'
        for attempt in range(12):
            try:
                resp = client.responses.create(**body)
                return {'custom_id': r['custom_id'], 'response': {'status_code': 200, 'body': resp.model_dump(mode='json')}}
            except Exception as e:  # noqa: BLE001
                status = getattr(e, 'status_code', None)
                if status in (400, 401, 403, 404):
                    return {'custom_id': r['custom_id'], 'response': {'status_code': status, 'body': {}}, 'error': str(e)[:400]}
                time.sleep(min(120, 5 * 2 ** attempt))
        return {'custom_id': r['custom_id'], 'response': {'status_code': 0, 'body': {}}, 'error': 'retries exhausted'}

    import threading
    lock = threading.Lock()

    def run(r: dict[str, Any]) -> None:
        out = call(r)
        with lock, raw_path.open('a') as h:
            h.write(json.dumps(out, ensure_ascii=False) + '\n')

    for outcome in fan_out(reqs, run, workers=workers):
        outcome.result()
    by_id = {r['custom_id']: r for r in load(f'{phase}.requests.json')}
    latest: dict[str, dict[str, Any]] = {}
    for x in map(json.loads, raw_path.read_text().splitlines()):
        if x['custom_id'] not in latest or x['response']['status_code'] == 200:
            latest[x['custom_id']] = x
    rows = [parse_openai(x, by_id[x['custom_id']]) for x in latest.values()]
    import fcntl
    with open(OUT / 'ledger.lock', 'w') as lk:
        fcntl.flock(lk, fcntl.LOCK_EX)
        led = ledger()
        led['batches'][key].update(status='completed', actual_usd=sum(r['usd'] for r in rows),
                                   errors=sum(1 for r in rows if r['answer'] is None))
        dump('ledger.json', led)
    dump(f'{key}.parsed.json', rows)
    print(key, len(rows), 'usd', round(sum(r['usd'] for r in rows), 4), 'invalid', sum(r['answer'] is None for r in rows),
          'committed', round(committed(), 4), flush=True)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('action')
    ap.add_argument('args', nargs='*')
    a = ap.parse_args()
    if a.action == 'prepare':
        prepare()
    elif a.action == 'add':
        add_cases(a.args[0])
    elif a.action == 'count':
        count(a.args[0], a.args[1].split(','), a.args[2])
    elif a.action == 'submit':
        submit(a.args[0], int(a.args[1]) if len(a.args) > 1 else 0)
    elif a.action == 'collect':
        collect()
    elif a.action == 'flex':
        flex(a.args[0], int(a.args[1]) if len(a.args) > 1 else 8)
    else:
        raise SystemExit('unknown action')
