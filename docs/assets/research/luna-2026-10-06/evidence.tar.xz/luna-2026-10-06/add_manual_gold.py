import json
from pathlib import Path

OUT = Path(__file__).parent
path = OUT / 'manual_gold.json'
gold = json.loads(path.read_text())
gold.update({
    'analysis-1040': {
        'publication_required': True,
        'score_range': [4, 4],
        'facts': [
            'The conditions are cumulative: living with the child in Poland; school attendance with age/deferral exceptions; employment OR business in Poland; tax compliance with legal relief exceptions.',
            'Payments can be suspended for failure of employment/business and tax conditions, then restored from the qualifying month.',
            'The new employment and tax rules first apply to applications filed from 1 February to 30 April 2025.',
            'The entry-into-force rule is 14 days after publication, not 1 February 2025.',
        ],
        'basis': 'Original supplied normative text, articles 1-3, inspected before model answers.',
    },
    'analysis-3039': {
        'publication_required': True,
        'score_range': [4, 5],
        'facts': [
            'Expands collective-accommodation eligibility under the temporary-protection framework.',
            'For students up to age 26, the new condition requires prior collective accommodation before 1 July 2026 and immediate continuation of full-time education.',
            'Includes single mothers or mothers whose spouse is outside Poland, and qualifying older people with Polish pension no greater than the minimum.',
            'Extends healthcare entitlement to qualifying vulnerable people outside collective accommodation, supported by a declaration under criminal liability.',
            'The entry-into-force rule is 14 days after publication.',
        ],
        'basis': 'Original supplied normative text, articles 1-2 plus explanation, inspected before model answers.',
    },
    'analysis-950': {
        'publication_required': True,
        'score_range': [5, 5],
        'facts': ['Implements EU directive 2021/1883 for highly qualified third-country workers and EU Blue Card rules.'],
        'basis': 'Original supplied normative opening and EU directive footnote, inspected before model answers.',
    },
    'triage-3039': {'affects_foreigners': True, 'basis': 'Supplied normative text directly changes temporary-protection benefits.'},
    'triage-950': {'affects_foreigners': True, 'basis': 'Supplied normative text directly changes third-country residence/Blue Card rules.'},
    'analysis-3160': {
        'relevant_required': True,
        'facts': ['Article 2 repeals art. 3a of the act on acquisition of property by foreigners.'],
        'basis': 'Supplied normative article 2 explicitly changes property-acquisition rules for foreigners. Other investment provisions alone would not establish relevance.',
    },
})
path.write_text(json.dumps(gold, ensure_ascii=False, indent=2))
protocol = {
    'quality_acceptance': {
        'full_replacement': 'No confirmed material errors or lost relevant bills across the covered roles, including large contexts and scans; secondary and revision coverage must be stated, not assumed.',
        'triage': 'No confirmed high-confidence false negatives at production confidence threshold 0.8; uncertain fragments must pass to full analysis.',
        'analysis': 'Preserve material dates, amounts, negation, eligibility, exceptions, and proposal-versus-decision distinction. JSON validity and agreement alone are insufficient.',
        'calibration': 'Use only the preregistered calibration split, then evaluate the fixed prompt on the heldout split. Report before/after results.',
    },
    'baseline_limits': [
        'Saved full-analysis references cover 19 Opus 5.5 and 5 GPT-5.1 outputs; no fresh paid baseline inference.',
        'Text triage references are historical Haiku 4.5, not current Sonnet 5. They are comparison aids, not independent ground truth.',
        'Eight saved reanalysis texts have no reconstructable previous analysis; they test current-text analysis only. Three saved revisions and two controlled revisions include prior descriptions.',
        'Author metadata is reconstructed in some corpus cases; the saved supplied text is exact, but some metadata and prompt versions differ from historical baseline requests.',
        'Baseline outputs are not treated as infallible; disagreements require supplied-text audit.',
        'A finite selected sample cannot certify unchanged quality on every future bill.',
    ],
    'money': 'Every new generation is a Batch request. Reserve all unsent planned batches as well as active ones; add no calibration work beyond the $2 total ceiling.',
}
(OUT / 'protocol.json').write_text(json.dumps(protocol, ensure_ascii=False, indent=2))
print(json.dumps({'manual_gold_cases': len(gold), 'protocol_saved': True}))
