import importlib.util
import json
from pathlib import Path

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import ApplicantType, BillContext

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
selected = [c for c in cases if c['id'] in ['reanalysis-3146', 'reanalysis-3141', 'reanalysis-RCL_12412454']]
tail = '''

Precision checks before the final JSON: preserve the direction of movement and distinguish operations conducted IN Poland from returns TO Poland. Read definitions and operative provisions, not just the title. Prioritize explicitly affected foreigner groups and their conditions over generic institutional changes. For changes_since_previous, omission from a short prior summary is not proof of a new provision. Name a change only when the supplied prior description or bullets establish a concrete difference; otherwise leave it empty. Never describe newly noticed details as newly added rules. Return only the final schema JSON without commentary.
'''
new = []
controls = [
    ('return_origin', 'Operacje powrotowe organizowane na terytorium Polski obejmują odsyłanie cudzoziemców z Polski do państw trzecich. Nie ustanawia się prawa do wjazdu do Polski.'),
    ('return_destination', 'Cudzoziemcy posiadający ważne zezwolenie na pobyt stały mogą powrócić do Polski po podróży zagranicznej. Przepis nie dotyczy wydalania cudzoziemców.'),
    ('course_eligibility', 'Ubezpieczeniu zdrowotnemu podlegają cudzoziemcy uczestniczący w kursach języka polskiego, jeżeli nie są ubezpieczeni z innego tytułu. Dotyczy to również absolwentów kierunków medycznych na praktycznym szkoleniu, na tej samej zasadzie.'),
]
for name, text in controls:
    ctx = BillContext(number='NEW-' + name, title='Projekt kontrolny', description=None,
                      document_date=None, applicant_type=ApplicantType.GOVERNMENT,
                      text=text, truncated=False, text_source='pdf')
    new.append({'id': 'analysis-new-' + name, 'number': ctx.number, 'kind': 'analysis',
                'split': 'heldout', 'source': 'new_repair_holdout', 'system': prompts.gpt51_system_prompt('ru'),
                'user': prompts.build_user_prompt(ctx), 'context': ctx.model_dump(mode='json')})
for name, previous, text, changed in [
    ('omitted_detail', 'Проект регулирует медицинское страхование и оплату лечения за границей.',
     'Projekt reguluje ubezpieczenie zdrowotne oraz zwrot kosztów leczenia za granicą. Art. 2. Minister może nadać ośrodkowi status centrum eksperckiego na 5 lat.', False),
    ('actual_changed_amount', 'Плата за карту пребывания составляет 100 злотых.',
     'Art. 1. Opłata za wydanie karty pobytu wynosi 200 zł.', True),
]:
    ctx = BillContext(number='NEW-' + name, title='Projekt kontrolny', description=None,
                      document_date=None, applicant_type=ApplicantType.GOVERNMENT,
                      text=text, truncated=False, text_source='pdf', previous_summary=previous)
    new.append({'id': 'reanalysis-new-' + name, 'number': ctx.number, 'kind': 'reanalysis',
                'split': 'heldout', 'source': 'new_repair_holdout', 'system': prompts.gpt51_system_prompt('ru'),
                'user': prompts.build_user_prompt(ctx), 'context': ctx.model_dump(mode='json'),
                'previous_reconstructed': True, 'gold': {'names_changes': changed}})
requests = []
for c in selected + new:
    for effort in ['medium', 'high']:
        if effort == 'high' or c in new:
            requests.append(module.request(c, effort, suffix='repair_base'))
        requests.append(module.request(c, effort, suffix='precision_v1', extra=tail))
for r in requests:
    r['_input_tokens_preflight'] = min(1050000, len(json.dumps(r['body'], ensure_ascii=False).encode()) + 4096)
    r['_input_count_exact'] = False
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2
assert 'analysis_repair' not in {x['phase'] for x in plan}
module.dump('analysis_repair.requests.json', requests)
module.dump('cases.json', cases + new)
module.dump('analysis_precision_v1.json', {'tail': tail, 'evaluation_type': 'exploratory targeted repair, not an unbiased original heldout result',
                                        'new_holdout_cases': [c['id'] for c in new]})
plan.insert(0, {'phase': 'analysis_repair', 'requests': len(requests),
                'input_tokens': sum(r['_input_tokens_preflight'] for r in requests), 'reserved_usd': reserve})
module.dump('chunk_plan.json', plan)
print(json.dumps({'requests': len(requests), 'reserved_usd': reserve,
                  'all_committed_and_planned_usd': committed + reserve}, indent=2))
