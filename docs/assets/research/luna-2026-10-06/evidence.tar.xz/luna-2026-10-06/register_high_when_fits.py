import json
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).parent
while not (OUT / 'high_v2_plan.json').exists():
    result = subprocess.run([sys.executable, str(OUT / 'prepare_high_v2.py')],
                            text=True, capture_output=True, check=True)
    state = json.loads(result.stdout)
    if state['registered']:
        print(result.stdout, flush=True)
        break
    time.sleep(30)
