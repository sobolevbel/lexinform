import copy
from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
from pathlib import Path

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import BillContext, TriageContext
from lexinform.models.sejm import applicant_from_title

OUT = Path(__file__).parent
assert not (OUT / 'metadata_check_plan.json').exists()
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
frozen = {}
for item in plan:
    for request in json.loads((OUT / (item['phase'] + '.requests.json')).read_text()):
        if item['phase'].startswith('triagev2_'):
            frozen[(request['_case_id'], 'triage_v2')] = request
        elif item['phase'].startswith('highv2_'):
            frozen[(request['_case_id'], 'high_v2')] = request
        elif item['phase'].startswith('conditionsv3_'):
            frozen[(request['_case_id'], 'conditions_v3')] = request

new_cases = []
requests = []
changes = []
for original in cases:
    if original.get('source') not in ('corpus_excerpts', 'corpus_full_text', 'saved_batch_text'):
        continue
    context = original['context']
    derived = applicant_from_title(context['title']).value
    if derived == 'unknown' or derived == context['applicant_type']:
        continue
    corrected = copy.deepcopy(original)
    corrected['id'] += '-metadata'
    corrected['context']['applicant_type'] = derived
    corrected['original_case_id'] = original['id']
    corrected['source'] = 'metadata_corrected_' + original['source']
    if corrected['kind'] == 'triage':
        corrected['user'] = prompts.build_triage_prompt(TriageContext.model_validate(corrected['context']))
        variants = ['triage_v2']
        requests.append(module.request(corrected, 'medium', suffix='metadata_original'))
    else:
        corrected['user'] = prompts.build_user_prompt(BillContext.model_validate(corrected['context']))
        variants = ['high_v2']
        if original['id'] in ('analysis-3039', 'analysis-1040'):
            variants.append('conditions_v3')
    assert corrected['user'] != original['user']
    for variant in variants:
        request = copy.deepcopy(frozen[(original['id'], variant)])
        effort = request['body']['reasoning']['effort']
        request['custom_id'] = corrected['id'] + '-' + effort + '-metadata_' + variant
        request['_case_id'] = corrected['id']
        assert request['body']['input'][1]['role'] == 'user'
        request['body']['input'][1]['content'] = corrected['user']
        requests.append(request)
    new_cases.append(corrected)
    changes.append({'original_case_id': original['id'], 'corrected_case_id': corrected['id'],
                    'number': original['number'], 'title': context['title'],
                    'previous_applicant': context['applicant_type'], 'corrected_applicant': derived,
                    'variants': variants + (['original'] if corrected['kind'] == 'triage' else [])})

assert len(new_cases) == 30
assert len(requests) == 57
api = module.client()

def count(request):
    body = request['body']
    response = api.responses.input_tokens.count(model=body['model'], input=body['input'], text=body['text'])
    return request['custom_id'], response.input_tokens

with ThreadPoolExecutor(max_workers=4) as pool:
    counts = dict(pool.map(count, requests))
for request in requests:
    bound = counts[request['custom_id']] + 1024
    request['_input_tokens_preflight'] = bound
    request['_input_count_exact'] = False
    request['_input_count_with_safety_margin'] = True
    long = bound > 272000
    request['_reserve'] = (bound * (.1 if long else .05)
                           + request['body']['max_output_tokens'] * (.375 if long else .25)) / 1e6
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2, (committed, reserve)
groups = []
group = []
size = 0
for request in sorted(requests, key=lambda r: (r['_input_tokens_preflight'], r['custom_id'])):
    if group and size + request['_input_tokens_preflight'] > 70000:
        groups.append(group)
        group = []
        size = 0
    group.append(request)
    size += request['_input_tokens_preflight']
if group:
    groups.append(group)
added = []
for index, group in enumerate(groups):
    phase = f'metadatav1_{index + 1}'
    assert phase not in ledger['batches']
    module.dump(phase + '.requests.json', group)
    added.append({'phase': phase, 'requests': len(group),
                  'input_tokens': sum(r['_input_tokens_preflight'] for r in group),
                  'reserved_usd': sum(r['_reserve'] for r in group)})
module.dump('metadata_check_protocol.json', {
    'reason': 'Corpus construction assigned government to non-government Sejm titles. Two reconstructed saved inputs also differ from production applicant_from_title. Correct only the applicant field with the production helper, preserving source text, excerpts, scores, schema and frozen prompt tails.',
    'changes': changes,
    'evaluation_type': 'Post-discovery input-fidelity diagnostic, not a new blind sample or 30 new bills. Original and v2 triage are both replayed on corrected identical inputs; source-audited high-v2 main analysis and two v3 completeness repairs are checked with corrected inputs.',
    'requests': len(requests), 'new_contexts': len(new_cases),
    'reserve_usd': reserve, 'max_total_usd_at_registration': committed + reserve,
    'historical_comparison_limit': 'Old results remain archived and cannot be relabelled as having corrected metadata. A prior-law/source baseline is not made authoritative by fixing applicant metadata.'
})
module.dump('metadata_check_token_counts.json', counts)
module.dump('metadata_check_plan.json', added)
module.dump('cases.json', cases + new_cases)
module.dump('chunk_plan.json', plan + added)
print(json.dumps({'requests': len(requests), 'new_contexts': len(new_cases),
                  'reserve_usd': reserve, 'max_total_usd': committed + reserve, 'batches': len(added)}))
