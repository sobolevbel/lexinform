import importlib.util
import json
from pathlib import Path
import sqlite3
import subprocess

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import AmendmentsContext, ApplicantType, JointBillDescription, JointContext

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
db = sqlite3.connect(':memory:')
db.row_factory = sqlite3.Row
db.executescript(subprocess.run(['git', 'show', 'origin/state:lexinform.sql'], cwd=module.ROOT,
                              capture_output=True, text=True, check=True).stdout)

descriptions = {}
joint_baselines = {}
for number, applicant in [('316', ApplicantType.PRESIDENT), ('1929', ApplicantType.GOVERNMENT),
                          ('1933', ApplicantType.DEPUTIES)]:
    row = db.execute('select title,analysis_json,joint_json from bills where number=?', (number,)).fetchone()
    analysis = json.loads(row['analysis_json'])['analysis']
    descriptions[number] = JointBillDescription(number=number, title=row['title'], applicant_type=applicant,
                                              summary=analysis['summary'], key_changes=analysis['key_changes'],
                                              affected_groups=analysis['affected_groups'], practical_impact=analysis['practical_impact'])
    if row['joint_json']:
        joint_baselines[number] = json.loads(row['joint_json'])

row = db.execute("select amendments_json from status_changes where number='1929' and amendments_json is not null limit 1").fetchone()
amendment_baseline = json.loads(row['amendments_json'])
ctx = AmendmentsContext(number='1929', title=descriptions['1929'].title,
                        source_kind='committee_amendments', text=(OUT / '2792-A.txt').read_text(),
                        truncated=False, previous_summary=descriptions['1929'].summary,
                        previous_key_changes=descriptions['1929'].key_changes)
added = [{'id': 'amendments-real-1929', 'number': '1929', 'kind': 'amendments',
          'split': module.split('1929'), 'source': 'real_committee_amendments',
          'system': prompts.gpt51_amendments_system_prompt('ru'), 'user': prompts.build_amendments_prompt(ctx),
          'context': ctx.model_dump(mode='json'), 'baseline': amendment_baseline,
          'gold': {'affects_foreigners': True, 'not_adopted': True},
          'manual_facts': ['Proposal 1 narrows/redrafts foreigner eligibility; the committee recommends rejection.',
                           'Proposal 2 requires residence in Poland throughout assistance; the committee recommends acceptance.',
                           'This is a committee recommendation, not a Sejm adoption decision.']}]
for number in ['316', '1933']:
    ctx2 = JointContext(subject=descriptions[number], others=[d for n,d in descriptions.items() if n!=number])
    added.append({'id': 'joint-real-' + number, 'number': number, 'kind': 'joint',
                  'split': module.split(number), 'source': 'real_joint_descriptions',
                  'system': prompts.gpt51_joint_system_prompt('ru'), 'user': prompts.build_joint_prompt(ctx2),
                  'context': ctx2.model_dump(mode='json'), 'baseline': joint_baselines[number],
                  'gold': {'same_substance': False}})

assert all(c['id'] not in {x['id'] for x in cases} for c in added)
requests = []
for c in added:
    r = module.request(c, 'medium')
    if c['kind']=='amendments':
        r['body']['max_output_tokens'] = 8000
        r['_reserve'] += .001
    requests.append(r)
high = module.request(added[0], 'high')
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
existing = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
existing += sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches'])
if existing + sum(r['_reserve'] for r in requests) + high['_reserve'] <= 2:
    requests.append(high)
assert existing + sum(r['_reserve'] for r in requests) <= 2
for r in requests:
    r['_input_tokens_preflight'] = min(1050000, len(json.dumps(r['body'],ensure_ascii=False).encode())+4096)
    r['_input_count_exact'] = False
module.dump('secondary_real.requests.json', requests)
module.dump('cases.json', cases+added)
new = {'phase':'secondary_real', 'requests':len(requests),
       'input_tokens':sum(r['_input_tokens_preflight'] for r in requests),
       'reserved_usd':sum(r['_reserve'] for r in requests)}
plan.insert(2, new)
module.dump('chunk_plan.json',plan)
manifest = json.loads((OUT / 'manifest.json').read_text())
manifest.update(case_count=len(cases+added), request_count=250+len(requests),
                all_planned_max_usd=existing+new['reserved_usd'])
module.dump('manifest.json',manifest)
print(json.dumps({'added_cases':len(added),'added_requests':len(requests),
                  'added_reserve':new['reserved_usd'],'all_planned_max_usd':existing+new['reserved_usd'],
                  'input_token_upper':new['input_tokens']},indent=2))
