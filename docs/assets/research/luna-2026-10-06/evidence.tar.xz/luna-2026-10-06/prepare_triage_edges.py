import gzip
import importlib.util
import json
from pathlib import Path

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import ApplicantType, BillContext

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
new = []
requests = []
for number in ['2355', '1894', '2360', '878']:
    triage = next(c for c in cases if c['id'] == 'triage-' + number)
    with gzip.open(module.CORPUS / f'sejm/term10/text/{number}.txt.gz', 'rt') as h:
        text = h.read()
    tc = triage['context']
    ctx = BillContext(number=number, title=tc['title'], description=tc['description'],
                      document_date=None, applicant_type=ApplicantType(tc['applicant_type']),
                      text=text, truncated=False, text_source='pdf')
    c = {'id': 'analysis-edge-' + number, 'number': number, 'kind': 'analysis',
         'split': 'heldout', 'source': 'exploratory_triage_disagreement_full_text',
         'system': prompts.gpt51_system_prompt('ru'), 'user': prompts.build_user_prompt(ctx),
         'context': ctx.model_dump(mode='json'),
         'audit_reason': 'Full-source adjudication of historical-triage disagreement; not original blind heldout.'}
    assert c['id'] not in {c['id'] for c in cases}
    new.append(c)
    for effort in ['medium', 'high']:
        r = module.request(c, effort, suffix='edge')
        r['_input_tokens_preflight'] = min(1050000, len(json.dumps(r['body'], ensure_ascii=False).encode()) + 4096)
        r['_input_count_exact'] = False
        requests.append(r)
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2
assert 'triage_edges' not in {x['phase'] for x in plan}
module.dump('triage_edges.requests.json', requests)
module.dump('cases.json', cases + new)
plan.insert(0, {'phase': 'triage_edges', 'requests': len(requests),
                'input_tokens': sum(r['_input_tokens_preflight'] for r in requests), 'reserved_usd': reserve})
module.dump('chunk_plan.json', plan)
print(json.dumps({'requests': len(requests), 'reserve': reserve, 'max_committed': committed + reserve}))
