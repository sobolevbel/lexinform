import copy
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert not (OUT / 'high_v2_plan.json').exists()
plan = json.loads((OUT / 'chunk_plan.json').read_text())
ledger = json.loads((OUT / 'ledger.json').read_text())
requests = []
for item in json.loads((OUT / 'max_v2_plan.json').read_text()):
    for original in json.loads((OUT / (item['phase'] + '.requests.json')).read_text()):
        request = copy.deepcopy(original)
        request['custom_id'] = request['custom_id'].replace('-max-max_v2', '-high-high_v2')
        request['body']['reasoning']['effort'] = 'high'
        request['body']['max_output_tokens'] = 16000
        bound = request['_input_tokens_preflight']
        long = bound > 272000
        request['_reserve'] = (bound * (.1 if long else .05) + 16000 * (.375 if long else .25)) / 1000000
        requests.append(request)
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert len(requests) == 46
if committed + reserve > 2:
    print(json.dumps({'registered': False, 'reason': 'budget reservation still occupied',
                      'committed': committed, 'reserve': reserve, 'total': committed + reserve}))
    raise SystemExit(0)
groups = []
group = []
size = 0
for request in sorted(requests, key=lambda r: (r['_input_tokens_preflight'], r['custom_id'])):
    amount = request['_input_tokens_preflight']
    if group and size + amount > 300000:
        groups.append(group)
        group = []
        size = 0
    group.append(request)
    size += amount
if group:
    groups.append(group)
added = []
for index, group in enumerate(groups):
    phase = f'highv2_{index + 1}'
    assert phase not in ledger['batches']
    module.dump(phase + '.requests.json', group)
    added.append({'phase': phase, 'requests': len(group),
                  'input_tokens': sum(r['_input_tokens_preflight'] for r in group),
                  'reserved_usd': sum(r['_reserve'] for r in group)})
module.dump('high_v2_plan.json', added)
module.dump('high_v2_protocol.json', {
    'reason': 'Max-v2 consumed the 32k cap without a final answer in multiple real contexts; test the same frozen prompt with high on every real analysis/reanalysis context and the same five guards to choose a usable configuration.',
    'effort': 'high', 'max_output_tokens': 16000,
    'input_bound': 'Reuses model input counts plus the existing 1024-token safety margin from otherwise identical max-v2 requests.',
    'evaluation_type': 'Exploratory configuration comparison; not a new blind holdout.',
    'requests': len(requests), 'reserve_usd': reserve, 'max_total_usd_at_registration': committed + reserve,
})
module.dump('chunk_plan.json', plan + added)
print(json.dumps({'registered': True, 'requests': len(requests), 'reserve': reserve,
                  'max_total': committed + reserve, 'batches': len(added)}))
