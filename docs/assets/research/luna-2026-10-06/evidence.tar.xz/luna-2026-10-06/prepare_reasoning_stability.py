import importlib.util
import json
from pathlib import Path

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import ApplicantType, BillContext

OUT = Path(__file__).parent
assert not (OUT / 'reasoning_stability_protocol.json').exists()
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
by_id = {c['id']: c for c in cases}
tail = json.loads((OUT / 'conditions_v3_protocol.json').read_text())['tail']
ctx = BillContext(number='STABILITY-mixed', title='Projekt kontrolny', description=None,
                  document_date=None, applicant_type=ApplicantType.GOVERNMENT,
                  text='Art. 1. Uczestnik wydarzenia jest zwolniony z opłaty za wizę po przedstawieniu potwierdzenia rejestracji. Art. 2. Wolontariusz niebędący obywatelem UE pracujący z dziećmi przedstawia informacje z rejestrów karnych państwa obywatelstwa i państw zamieszkania w ostatnich 7 latach. Art. 3. Uczestnik kursu przygotowawczego do studiów w języku polskim podlega ubezpieczeniu zdrowotnemu, jeżeli nie jest ubezpieczony z innego tytułu. Art. 4. Organizator prowadzi rejestr sal. Art. 5. Instytucje mogą wymieniać informacje statystyczne. Ustawa wchodzi w życie po 14 dniach od ogłoszenia.',
                  truncated=False, text_source='pdf')
control = {'id': 'analysis-stability-mixed', 'number': ctx.number, 'kind': 'analysis',
           'split': 'heldout', 'source': 'new_reasoning_stability_guard',
           'system': prompts.gpt51_system_prompt('ru'), 'user': prompts.build_user_prompt(ctx),
           'context': ctx.model_dump(mode='json'),
           'gold': {'score': 5, 'publish': True,
                    'required_conditions': ['visa-fee exemption with registration proof',
                                            'non-EU volunteers working with children',
                                            'citizenship and residence countries, last seven years',
                                            'preparatory-course participants without other insurance'],
                    'forbidden_inference': ['five-year or ten-year lookback']}}
selections = [('reanalysis-2846', 'high', 16000), ('reanalysis-2846', 'xhigh', 64000),
              ('reanalysis-RCL_12412454', 'xhigh', 64000),
              (control['id'], 'high', 16000), (control['id'], 'xhigh', 64000)]
by_id[control['id']] = control
bounds = {}
for item in json.loads((OUT / 'chunk_plan.json').read_text()):
    if item['phase'].startswith('conditionsv3_'):
        for request in json.loads((OUT / (item['phase'] + '.requests.json')).read_text()):
            bounds[request['_case_id']] = request['_input_tokens_preflight']
requests = []
for case_id, effort, cap in selections:
    request = module.request(by_id[case_id], effort, suffix='stability_v3', extra=tail)
    request['body']['max_output_tokens'] = cap
    bound = bounds.get(case_id, len(json.dumps(request['body'], ensure_ascii=False).encode()) + 4096)
    request['_input_tokens_preflight'] = bound
    request['_input_count_exact'] = False
    long = bound > 272000
    request['_reserve'] = (bound * (.1 if long else .05) + cap * (.375 if long else .25)) / 1e6
    requests.append(request)
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2
added = []
for index, request in enumerate(requests):
    phase = f'stabilityv3_{index + 1}'
    assert phase not in ledger['batches']
    module.dump(phase + '.requests.json', [request])
    added.append({'phase': phase, 'requests': 1,
                  'input_tokens': request['_input_tokens_preflight'], 'reserved_usd': request['_reserve']})
module.dump('reasoning_stability_protocol.json', {
    'reason': 'The v3 high answer on full real Jamboree input omits volunteers entirely while its small lookback control passes. Recheck identical high input and xhigh with a generous 64k output cap; distinguish stochastic variability, insufficient reasoning and rich-input coverage.',
    'prompt': 'The unchanged frozen conditions-v3 tail is reused.',
    'selections': selections, 'new_guard_id': control['id'],
    'evaluation_type': 'Exploratory robustness check on known defects and one fresh focused multi-domain guard, not blind full-corpus validation of xhigh.',
    'reserved_usd': reserve, 'max_total_usd': committed + reserve,
})
module.dump('cases.json', cases + [control])
module.dump('chunk_plan.json', plan + added)
print(json.dumps({'requests': len(requests), 'reserved_usd': reserve, 'max_total_usd': committed + reserve}))
