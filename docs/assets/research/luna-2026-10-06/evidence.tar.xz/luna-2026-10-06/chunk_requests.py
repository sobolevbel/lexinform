from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
api = module.client()
requests = json.loads((OUT / 'phase1.requests.json').read_text())
cache_path = OUT / 'input_counts.json'
cache = json.loads(cache_path.read_text()) if cache_path.exists() else {}


def key(request):
    body = request['body']
    value = {k: body[k] for k in ('model', 'input', 'text')}
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def count(request):
    digest = key(request)
    if digest in cache:
        return digest, cache[digest]
    body = request['body']
    try:
        result = api.responses.input_tokens.count(model=body['model'], input=body['input'], text=body['text'])
        return digest, {'input_tokens': result.input_tokens, 'exact': True}
    except Exception as exc:
        return digest, {'input_tokens': min(1050000, len(json.dumps(body, ensure_ascii=False).encode()) + 4096),
                        'exact': False, 'error_type': type(exc).__name__, 'status': getattr(exc, 'status_code', None)}


unique = {key(r): r for r in requests}
with ThreadPoolExecutor(max_workers=4) as executor:
    for i, (digest, result) in enumerate(executor.map(count, unique.values()), 1):
        cache[digest] = result
        module.dump('input_counts.json', cache)
        if i % 20 == 0:
            print(json.dumps({'counted': i, 'total': len(unique)}), flush=True)

chunks = []
group = []
total = 0
for request in requests:
    amount = cache[key(request)]['input_tokens']
    request['_input_tokens_preflight'] = amount
    if total + amount > 1800000 and group:
        chunks.append(group)
        group = []
        total = 0
    group.append(request)
    total += amount
if group:
    chunks.append(group)
plan = []
for i, group in enumerate(chunks, 1):
    phase = 'part' + str(i)
    module.dump(phase + '.requests.json', group)
    plan.append({'phase': phase, 'requests': len(group),
                 'input_tokens': sum(x['_input_tokens_preflight'] for x in group),
                 'reserved_usd': sum(x['_reserve'] for x in group)})
assert len({r['custom_id'] for group in chunks for r in group}) == len(requests)
module.dump('chunk_plan.json', plan)
print(json.dumps({'plan': plan, 'counts_without_generation': len(unique),
                  'inexact_counts': sum(not x['exact'] for x in cache.values())}, indent=2))
