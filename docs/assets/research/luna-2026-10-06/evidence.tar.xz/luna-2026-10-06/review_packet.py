import json
from pathlib import Path
import re

OUT = Path(__file__).parent
cases = {c['id']: c for c in json.loads((OUT / 'cases.json').read_text())}
rows = json.loads((OUT / 'all_answers.json').read_text())
focus = {
    'analysis-3141': r'kursy języka polskiego|kursy przygotowawcze',
    'reanalysis-3141': r'kursy języka polskiego|kursy przygotowawcze',
    'reanalysis-RCL_12412454': r'kursy języka polskiego|kursy przygotowawcze',
    'analysis-RCL_12398102': r'nie posiada numeru PESEL|paszportu|przepis.*koordynacji',
    'reanalysis-2110': r'innym.*związku|prawem obcym|prawo.*obc',
    'reanalysis-3146': r'osoby powracające|odsyłane',
    'analysis-3150': r'cudzoziem|Fundusz Pomocy',
    'reanalysis-3150': r'cudzoziem|Fundusz Pomocy',
    'analysis-3139': r'ratyfik|3 lata|trzech lat|jednego roku',
    'analysis-RCL_12399355': r'Funduszu Gwarantowanych|20 000 000',
    'reanalysis-2846': r'ostatnich 10 lat|niebędącego obywatelem',
    'analysis-3039': r'26|1 lipca|oświadczen|samotn',
    'analysis-RCL_12408900': r'niemożliwe lub utrudnione|uwierzytelnionym tłumaczeniem',
}
packet = []
for case_id, pattern in focus.items():
    case = cases[case_id]
    text = case.get('context', {}).get('text', '')
    normalized = re.sub(r'\s+', ' ', text)
    excerpts = [normalized[max(0, m.start() - 200):m.end() + 500]
                for m in list(re.finditer(pattern, normalized, re.I))[:5]]
    answers = [{'id': r['custom_id'], 'effort': r['effort'], 'phase': r['phase'],
                'usd': r['usd'], 'answer': r['answer']} for r in rows if r['case_id'] == case_id]
    packet.append({'case_id': case_id, 'source_excerpts': excerpts,
                   'previous_reconstructed': case.get('previous_reconstructed'),
                   'historical_reference': case.get('baseline', {}).get('answer'),
                   'answers': answers})
data = {'purpose': 'Manual review packet for source-based comparison of original and calibrated answers. Excerpts and text matching are navigation aids, not legal-quality pass/fail tests.', 'cases': packet}
temporary = OUT / 'review_packet.tmp'
temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2))
temporary.replace(OUT / 'review_packet.json')
print(json.dumps({'focus_contexts': len(packet), 'available_answers': sum(len(c['answers']) for c in packet)}))
