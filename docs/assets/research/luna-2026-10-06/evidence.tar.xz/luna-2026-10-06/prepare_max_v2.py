from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
from pathlib import Path

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import ApplicantType, BillContext

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
assert not (OUT / 'max_v2_plan.json').exists()
selected = [c for c in cases if c['kind'] in ['analysis', 'reanalysis']
            and c['source'] not in ['synthetic_control', 'new_repair_holdout']]
tail = json.loads((OUT / 'analysis_precision_v1.json').read_text())['tail'] + '''

Audience and score consistency checks: identify the operative provisions that change a non-citizen's eligibility, documents, fees, obligations, deadlines or access to a service. Prioritize these over generic institutional or sector-wide administration in the summary, bullets and affected_groups. Check all distinct relevant groups, including foreign students, language-course participants, patients without PESEL and people using EU healthcare coordination, when actually present in the supplied text. Preserve their limiting conditions and exceptions; do not infer rights absent from the text. A normal annual budget allocation for existing agencies or existing aid, with unchanged individual rights and conditions, is marginal (score 1) rather than a new social entitlement. Explicitly created or changed individual benefits are still social (score 3) or higher under the rubric, even in a funding bill. Follow the rubric's score 2 for a bilateral-agreement ratification rather than upgrading it because the agreement mentions temporary business travel; a separate operative change to Polish visa/residence/work entitlement uses the corresponding higher category. Preserve Polish statutory titles and Latin-script Polish/EU institutional abbreviations. Do not add narration outside the final JSON.
'''
new = []
controls = [
    ('budget_existing', 'Ustawa budżetowa przeznacza 50 mln zł na działającą od lat pomoc cudzoziemcom. Nie zmienia kręgu uprawnionych, wysokości indywidualnych świadczeń ani procedur.', False, 1),
    ('funding_new_right', 'Art. 1. Cudzoziemiec posiadający pobyt stały nabywa prawo do nowego świadczenia w wysokości 200 zł miesięcznie. Art. 2. Na wypłatę świadczenia przeznacza się 50 mln zł.', True, 3),
    ('bilateral_ratification', 'Wyraża się zgodę na ratyfikację umowy o partnerstwie z państwem X. Umowa przewiduje do 90 dni wizyt biznesowych z zachowaniem prawa krajowego. Nie zmienia polskich zasad uzyskiwania wiz ani zezwoleń na pobyt i pracę.', False, 2),
    ('patient_without_pesel', 'Art. 1. Osoba uprawniona do świadczeń NFZ, która nie posiada numeru PESEL, może złożyć wniosek o refundację, podając numer ważnego paszportu. Wymaga się załączenia kopii paszportu. Ustawa wchodzi w życie po upływie 30 dni od ogłoszenia.', True, 3),
    ('generic_hospital_budget', 'Na zakup łóżek w szpitalach przeznacza się 10 mln zł. W uzasadnieniu wymieniono cudzoziemców wśród pacjentów. Nie zmieniają się żadne prawa pacjenta, opłaty, kryteria ani procedury.', False, 1),
]
for name, text, publish, score in controls:
    ctx = BillContext(number='MAX-' + name, title='Projekt kontrolny', description=None,
                      document_date=None, applicant_type=ApplicantType.GOVERNMENT,
                      text=text, truncated=False, text_source='pdf')
    c = {'id': 'analysis-maxguard-' + name, 'number': ctx.number, 'kind': 'analysis',
         'split': 'heldout', 'source': 'new_max_v2_guard', 'system': prompts.gpt51_system_prompt('ru'),
         'user': prompts.build_user_prompt(ctx), 'context': ctx.model_dump(mode='json'),
         'gold': {'publish': publish, 'score': score}}
    assert c['id'] not in {x['id'] for x in cases}
    new.append(c)
requests = [module.request(c, 'max', suffix='max_v2', extra=tail) for c in selected + new]
for r in requests:
    r['body']['max_output_tokens'] = 32000
api = module.client()


def count(r):
    b = r['body']
    result = api.responses.input_tokens.count(model=b['model'], input=b['input'], text=b['text'])
    return r['custom_id'], result.input_tokens


with ThreadPoolExecutor(max_workers=4) as pool:
    counts = dict(pool.map(count, requests))
for r in requests:
    count_bound = counts[r['custom_id']] + 1024
    r['_input_tokens_preflight'] = count_bound
    r['_input_count_exact'] = False
    r['_input_count_with_safety_margin'] = True
    long = count_bound > 272000
    r['_reserve'] = (count_bound * (.1 if long else .05) + 32000 * (.375 if long else .25)) / 1000000
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
module.dump('max_v2_token_counts.json', counts)
module.dump('max_v2_prompt.json', {'tail': tail, 'effort': 'max', 'max_output_tokens': 32000,
                                'evaluation_type': 'exploratory best-configuration rerun on all real analysis contexts; known failures informed the prompt, five new guard contexts fixed before answers',
                                'selected_case_ids': [c['id'] for c in selected],
                                'new_guard_ids': [c['id'] for c in new]})
if committed + reserve > 2:
    module.dump('max_v2_waiting.json', {'reserved_usd': reserve, 'committed_usd': committed,
                                     'reason': 'Wait for completed tests to release unused reserves; no inference submitted.'})
    raise SystemExit('Maximum reserve does not yet fit; no submissions or plan changes.')
module.dump('cases.json', cases + new)
requests.sort(key=lambda r: (r['_input_tokens_preflight'], r['custom_id']))
groups = []
group = []
size = 0
for r in requests:
    amount = r['_input_tokens_preflight']
    if group and size + amount > 300000:
        groups.append(group)
        group = []
        size = 0
    group.append(r)
    size += amount
if group:
    groups.append(group)
added = []
for index, group in enumerate(groups):
    phase = f'maxv2_{index + 1}'
    assert phase not in ledger['batches']
    module.dump(phase + '.requests.json', group)
    added.append({'phase': phase, 'requests': len(group),
                  'input_tokens': sum(r['_input_tokens_preflight'] for r in group),
                  'reserved_usd': sum(r['_reserve'] for r in group)})
module.dump('max_v2_plan.json', added)
module.dump('chunk_plan.json', plan + added)
print(json.dumps({'real_contexts': len(selected), 'new_controls': len(new), 'requests': len(requests),
                  'reserved_usd': reserve, 'max_total_usd': committed + reserve, 'batch_count': len(added)}, indent=2))
