import collections
import contextlib
import importlib.util
import io
import json
from pathlib import Path

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('inspection', OUT / 'inspect_results.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = {c['id']: c for c in json.loads((OUT / 'cases.json').read_text())}
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
metrics = collections.defaultdict(collections.Counter)
all_rows = []
all_issues = []
phase_metrics = {}
baselines = collections.defaultdict(lambda: {'count': 0, 'baseline_usd': 0., 'luna_usd': 0., 'baseline_input': 0, 'luna_input': 0})
completed_batch_timings = []
for phase, batch in ledger['batches'].items():
    if batch['status'] != 'completed' or phase == 'canary':
        continue
    state = json.loads((OUT / (phase + '.batch.json')).read_text())
    created = state.get('created_at')
    completed = state.get('completed_at')
    if created and completed:
        completed_batch_timings.append({'phase': phase, 'requests': batch['request_count'],
                                        'turnaround_seconds': completed - created})
    with contextlib.redirect_stdout(io.StringIO()) as output:
        module.inspect(phase, 'all')
    report = json.loads(output.getvalue())
    phase_metrics[phase] = report['metrics']
    for key, values in report['metrics'].items():
        metrics[key].update(values)
    all_issues.extend(report['issues'])
    requests = {r['custom_id']: r for r in json.loads((OUT / (phase + '.requests.json')).read_text())}
    rows = json.loads((OUT / (phase + '.parsed.json')).read_text())
    for row in rows:
        request = requests[row['custom_id']]
        case = cases[request['_case_id']]
        enriched = {'phase': phase, 'case_id': case['id'], 'kind': case['kind'], 'source': case['source'],
                    'split': case['split'], 'effort': request['body']['reasoning']['effort'], **row}
        all_rows.append(enriched)
        if request['custom_id'].endswith('-medium-base') and case['kind'] in ['analysis', 'reanalysis'] and case.get('baseline'):
            b = case['baseline']
            rates = (2., 10.) if b['model'] == 'claude-opus-5-5' else (.625, 5.)
            value = baselines[b['model']]
            value['count'] += 1
            value['baseline_usd'] += (b['input_tokens'] * rates[0] + b['output_tokens'] * rates[1]) / 1000000
            value['luna_usd'] += row['usd']
            value['baseline_input'] += b['input_tokens']
            value['luna_input'] += row['usage'].get('input_tokens', 0)
summary = {
    'case_count': len(cases),
    'all_planned_requests_excluding_validation_failure': sum(x['requests'] for x in plan) + ledger['batches']['canary']['request_count'],
    'completed_paid_requests': sum(b['request_count'] for b in ledger['batches'].values() if b['status'] == 'completed'),
    'actual_usd': sum(b.get('actual_usd', 0) for b in ledger['batches'].values()),
    'actual_usd_scope': 'Accounted cost of fully completed batches only. Partially processed active batches may already be billed; their worst-case cost remains reserved.',
    'max_committed_usd': sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values()) + sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches']),
    'unfinished': [x['phase'] for x in plan if ledger['batches'].get(x['phase'], {}).get('status') != 'completed'],
    'metrics': dict(metrics),
    'phase_metrics': phase_metrics,
    'saved_reference_cold_batch_cost_comparison': dict(baselines),
    'baseline_comparison_limit': 'Historical token usage repriced at current cold Batch rates; not fresh inference with identical metadata and prompt versions.',
    'completed_batch_timings': completed_batch_timings,
    'timing_scope': 'Observed submission-to-completion time for completed jobs only; pending jobs are excluded, so this is not an unbiased latency estimate or a production SLA.',
    'invalid_final_answers': sum(r['answer'] is None for r in all_rows),
    'non_completed_responses': sum(r['status'] != 'completed' for r in all_rows),
    'cache_reads': sum((r['usage'].get('input_tokens_details') or {}).get('cached_tokens', 0) for r in all_rows),
    'cache_writes': sum((r['usage'].get('input_tokens_details') or {}).get('cache_write_tokens', 0) for r in all_rows),
    'reasoning_tokens': sum((r['usage'].get('output_tokens_details') or {}).get('reasoning_tokens', 0) for r in all_rows),
    'issues': all_issues,
}
for name, data in [('aggregate.json', summary), ('all_answers.json', all_rows)]:
    target = OUT / name
    tmp = target.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2))
    tmp.replace(target)
print(json.dumps({k: summary[k] for k in ['case_count', 'all_planned_requests_excluding_validation_failure', 'completed_paid_requests', 'actual_usd', 'max_committed_usd', 'unfinished', 'invalid_final_answers']}))
