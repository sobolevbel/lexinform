from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
from pathlib import Path

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import ApplicantType, TriageContext

OUT = Path(__file__).parent
assert not (OUT / 'rcl_triage_protocol.json').exists()
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
selected = [c for c in cases if c.get('context', {}).get('source_kind') == 'rcl']
assert len(selected) == 6
v1 = json.loads((OUT / 'triage_v1_prompt.json').read_text())['tail']
v2 = json.loads((OUT / 'triage_v2_protocol.json').read_text())['tail']
prefilter = module.KeywordPrefilter()
new = []
requests = []
for original in selected:
    full = original['context']
    text = full['text']
    assert len(text) >= 20000
    context = TriageContext(
        number=full['number'], title=full['title'], description=full.get('description'),
        applicant_type=ApplicantType.GOVERNMENT,
        excerpts=module.excerpts(text, prefilter.spans(text)), text_chars=len(text),
    )
    case = {
        'id': 'triage-rcl-' + full['number'].replace('/', '_'),
        'number': full['number'], 'kind': 'triage', 'split': 'heldout',
        'source': 'real_rcl_triage_excerpts',
        'system': prompts.triage_system_prompt('ru'),
        'user': prompts.build_triage_prompt(context),
        'context': context.model_dump(mode='json'),
        'source_analysis_case_id': original['id'],
    }
    new.append(case)
    for suffix, tail in [('rcl_base', ''), ('rcl_triage_v1', v1), ('rcl_triage_v2', v2)]:
        requests.append(module.request(case, 'medium', suffix=suffix, extra=tail))
api = module.client()

def count(request):
    body = request['body']
    response = api.responses.input_tokens.count(model=body['model'], input=body['input'], text=body['text'])
    return request['custom_id'], response.input_tokens

with ThreadPoolExecutor(max_workers=4) as pool:
    counts = dict(pool.map(count, requests))
for request in requests:
    bound = counts[request['custom_id']] + 1024
    assert bound < 272000
    request['_input_tokens_preflight'] = bound
    request['_input_count_exact'] = False
    request['_input_count_with_safety_margin'] = True
    request['_reserve'] = (bound * .05 + 4000 * .25) / 1e6
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(p['reserved_usd'] for p in plan if p['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2, (committed, reserve)
added = []
for index, case in enumerate(new):
    group = [r for r in requests if r['_case_id'] == case['id']]
    phase = f'triage_rcl_{index + 1}'
    assert phase not in ledger['batches']
    module.dump(phase + '.requests.json', group)
    added.append({'phase': phase, 'requests': len(group),
                  'input_tokens': sum(r['_input_tokens_preflight'] for r in group),
                  'reserved_usd': sum(r['_reserve'] for r in group)})
module.dump('rcl_triage_protocol.json', {
    'reason': 'The existing real triage corpus contains 79 Sejm excerpts and two scans, but no RCL excerpts. Exercise the same production excerpt builder on all six already-sourced long RCL contexts to cover this source type before a full-replacement conclusion.',
    'case_ids': [c['id'] for c in new],
    'configs': ['original/medium', 'triage_v1/medium', 'triage_v2/medium'],
    'scope': 'Existing saved RCL texts with production keyword windows, no new fetch/extraction change. No historical triage oracle or invented gold label is assigned; audit the visible excerpts against the source and avoid pretending unseen full-text clauses are visible.',
    'reserve_usd': reserve, 'max_total_usd': committed + reserve,
})
module.dump('rcl_triage_token_counts.json', counts)
module.dump('cases.json', cases + new)
module.dump('chunk_plan.json', plan + added)
print(json.dumps({'requests': len(requests), 'reserve_usd': reserve,
                  'max_total_usd': committed + reserve, 'batches': len(added)}))
