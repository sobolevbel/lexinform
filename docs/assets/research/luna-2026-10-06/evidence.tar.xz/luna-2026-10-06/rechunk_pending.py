import json
import os
from pathlib import Path

OUT = Path(__file__).parent
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
pending = ['part2', 'part3']
assert all(p not in ledger['batches'] for p in pending)
requests = [r for p in pending for r in json.loads((OUT / (p + '.requests.json')).read_text())]
requests.sort(key=lambda r: (r['_input_tokens_preflight'], r['custom_id']))
groups = []
group = []
size = 0
for r in requests:
    amount = r['_input_tokens_preflight']
    if group and size + amount > 250000:
        groups.append(group)
        group = []
        size = 0
    group.append(r)
    size += amount
if group:
    groups.append(group)
added = []
for i, group in enumerate(groups):
    phase = f'pending{i + 1}'
    assert phase not in ledger['batches']
    (OUT / (phase + '.requests.json')).write_text(json.dumps(group, ensure_ascii=False, indent=2))
    added.append({'phase': phase, 'requests': len(group),
                  'input_tokens': sum(r['_input_tokens_preflight'] for r in group),
                  'reserved_usd': sum(r['_reserve'] for r in group)})
old_reserve = sum(x['reserved_usd'] for x in plan if x['phase'] in pending)
assert abs(sum(x['reserved_usd'] for x in added) - old_reserve) < 1e-9
new_plan = [x for x in plan if x['phase'] not in pending] + added
temporary = OUT / 'chunk_plan.new.json'
temporary.write_text(json.dumps(new_plan, indent=2))
os.replace(temporary, OUT / 'chunk_plan.json')
print(json.dumps(added, indent=2))
