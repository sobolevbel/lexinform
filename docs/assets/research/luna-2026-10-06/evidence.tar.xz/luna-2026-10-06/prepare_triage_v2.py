from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).parent
assert not (OUT / 'triage_v2_plan.json').exists()
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
selected = [c for c in cases if c['kind'] == 'triage']
assert len(selected) == 91
old_tail = json.loads((OUT / 'triage_v1_prompt.json').read_text())['tail']
old_sentence = 'General applicability to everyone or an agency keyword alone is insufficient to assert a specific change for foreigners; name the actual operative effect when visible.'
assert old_sentence in old_tail
new_sentence = ('Do not require a separate rule for foreigners rather than Polish citizens: '
                'an operative change to personal rights, obligations, benefits, documents, '
                'tax or business procedures can affect a covered non-citizen even when the '
                'same rule applies to citizens. Preserve the original directly-or-clearly-'
                'indirectly gate; do not turn it into a foreigners-only test. Distinguish '
                'such a concrete change from a mere authority keyword, an unchanged annual '
                'funding allocation or internal institutional organization. Name the '
                'actual effect when visible; uncertainty about an individual effect passes '
                'with lower confidence. An explicit Polish-citizenship eligibility condition '
                'still excludes non-citizens unless another supplied provision affects them.')
tail = old_tail.replace(old_sentence, new_sentence)
template = next(c for c in selected if c['source'] == 'synthetic_control')
guards = [
    ('universal_invoicing', 'Art. 1. Każdy podatnik prowadzący działalność gospodarczą w Polsce, bez względu na obywatelstwo, wystawia faktury elektroniczne od 1 maja 2027 r. Projekt zmienia termin obowiązku i zasady doręczania faktur nabywcom bez NIP. Nie ma odrębnego terminu dla cudzoziemców.', True),
    ('universal_tenant_right', 'Art. 1. Właściciel lokalu zwraca kaucję najemcy w ciągu 10 dni zamiast 30 dni. Przepis stosuje się do wszystkich najemców, niezależnie od obywatelstwa. Nie zmieniają się pozwolenia na pobyt.', True),
    ('universal_worker_right', 'Art. 1. Pracodawca wypłaca dodatek za pracę w niedzielę w wysokości 80 zł zamiast 40 zł. Prawo przysługuje każdemu pracownikowi zatrudnionemu w Polsce; projekt nie ustanawia kryterium obywatelstwa.', True),
    ('citizens_only_payment', 'Art. 1. Nowe świadczenie w wysokości 100 zł przysługuje wyłącznie obywatelom polskim. Osoby nieposiadające obywatelstwa polskiego nie są uprawnione; projekt nie zmienia ich praw ani obowiązków.', False),
    ('unchanged_agency_funding', 'Art. 1. Ustala się roczny plan wydatków Straży Granicznej i urzędu obsługującego cudzoziemców. Zwiększenie kwot finansuje wyposażenie biur. Prawa osób prywatnych, opłaty, terminy, świadczenia i procedury pozostają bez zmian.', False),
    ('inconclusive_personal_fee', 'Widoczny fragment zapowiada zmianę opłaty za dokument wydawany osobom mieszkającym w Polsce. Fragment urywa się przed określeniem kręgu wnioskodawców; nie wiadomo, czy obejmuje cudzoziemców.', True),
]
new = [
    {'id': 'triage-v2guard-' + name, 'number': 'T2-' + name,
     'kind': 'triage', 'system': template['system'], 'user': text,
     'split': 'heldout', 'source': 'new_triage_v2_guard',
     'gold': {'affects_foreigners': affects}}
    for name, text, affects in guards
]
requests = [module.request(c, 'medium', suffix='triage_v2', extra=tail) for c in selected + new]
api = module.client()

def count(request):
    body = request['body']
    response = api.responses.input_tokens.count(model=body['model'], input=body['input'], text=body['text'])
    return request['custom_id'], response.input_tokens

with ThreadPoolExecutor(max_workers=4) as pool:
    counts = dict(pool.map(count, requests))
for request in requests:
    bound = counts[request['custom_id']] + 1024
    assert bound < 272000
    request['_input_tokens_preflight'] = bound
    request['_input_count_exact'] = False
    request['_input_count_with_safety_margin'] = True
    request['_reserve'] = (bound * .05 + request['body']['max_output_tokens'] * .25) / 1e6
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(p['reserved_usd'] for p in plan if p['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2, (committed, reserve)
groups = []
group = []
size = 0
for request in sorted(requests, key=lambda r: (r['_input_tokens_preflight'], r['custom_id'])):
    if group and size + request['_input_tokens_preflight'] > 70000:
        groups.append(group)
        group = []
        size = 0
    group.append(request)
    size += request['_input_tokens_preflight']
if group:
    groups.append(group)
added = []
for index, group in enumerate(groups):
    phase = f'triagev2_{index + 1}'
    assert phase not in ledger['batches']
    module.dump(phase + '.requests.json', group)
    added.append({'phase': phase, 'requests': len(group),
                  'input_tokens': sum(r['_input_tokens_preflight'] for r in group),
                  'reserved_usd': sum(r['_reserve'] for r in group)})
module.dump('triage_v2_protocol.json', {
    'reason': 'V1 rejects real KSeF at confidence .91 because it lacks a foreigners-only rule, whereas the original gate explicitly includes clearly indirect changes to non-citizen obligations. Original none/medium pass and full-text medium finds real business/foreign-buyer procedures at score2. Fix the narrowing instruction without changing the original gate or publication rubric.',
    'tail': tail, 'replaced_sentence': old_sentence, 'replacement': new_sentence,
    'effort': 'medium', 'max_output_tokens': 4000,
    'evaluation_type': 'Exploratory full triage rerun on all 91 existing contexts and six fresh focused guards, frozen before their answers; not independent random gold. No claim of a lost score>=3 KSeF card or fresh Sonnet equivalence.',
    'requests': len(requests), 'new_guards': [c['id'] for c in new],
    'reserve_usd': reserve, 'max_total_usd': committed + reserve,
})
module.dump('triage_v2_token_counts.json', counts)
module.dump('triage_v2_plan.json', added)
module.dump('cases.json', cases + new)
module.dump('chunk_plan.json', plan + added)
print(json.dumps({'requests': len(requests), 'reserve_usd': reserve,
                  'max_total_usd': committed + reserve, 'batches': len(added)}))
