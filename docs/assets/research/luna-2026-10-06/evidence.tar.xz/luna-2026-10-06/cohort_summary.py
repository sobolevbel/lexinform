from collections import Counter, defaultdict
import json
from pathlib import Path
import re
import statistics

OUT = Path(__file__).parent
cases = {c['id']: c for c in json.loads((OUT / 'cases.json').read_text())}
rows = json.loads((OUT / 'all_answers.json').read_text())

def variant(row):
    phase = row['phase']
    if phase.startswith('metadatav1_'):
        suffix = row['custom_id'].rsplit('-metadata_', 1)[1]
        return 'corrected_metadata_' + suffix + '/' + row['effort']
    if phase.startswith('triage_rcl_'):
        if row['custom_id'].endswith('rcl_triage_v2'):
            return 'triage_v2/' + row['effort']
        if row['custom_id'].endswith('rcl_triage_v1'):
            return 'triage_v1/' + row['effort']
        return 'original/' + row['effort']
    if phase.startswith('triagev2_'):
        return 'triage_v2/' + row['effort']
    if phase.startswith('changev1_'):
        return 'change_review_v1/' + row['effort']
    if phase == 'production_review':
        prefix = 'prepared_change_review_v1/' if row['custom_id'].endswith('production_change_review_v1') else 'prepared_original/'
        return prefix + row['effort']
    if phase.startswith('maxv2_') or phase == 'return_guard':
        return 'max_v2/' + row['effort']
    if phase.startswith('highv2_'):
        return 'high_v2/' + row['effort']
    if phase.startswith('conditionsv3_'):
        return 'conditions_v3/' + row['effort']
    if phase.startswith('stabilityv3_'):
        return 'stability_v3/' + row['effort']
    if phase.startswith('triagev1_'):
        return 'triage_v1/' + row['effort']
    if phase == 'joint_calibration':
        return ('joint_v1/' if row['custom_id'].endswith('joint_v1') else 'joint_guard_base/') + row['effort']
    if phase == 'analysis_repair':
        return ('precision_v1/' if row['custom_id'].endswith('precision_v1') else 'repair_base/') + row['effort']
    return 'original/' + row['effort']

groups = defaultdict(list)
for row in rows:
    groups[(row['kind'], variant(row))].append(row)
summary = []
for (kind, config), group in sorted(groups.items()):
    valid = [r for r in group if r['answer'] and r['status'] == 'completed']
    input_tokens = sum(r['usage'].get('input_tokens', 0) for r in group)
    output_tokens = sum(r['usage'].get('output_tokens', 0) for r in group)
    reasoning = sum((r['usage'].get('output_tokens_details') or {}).get('reasoning_tokens', 0) for r in group)
    value = {
        'kind': kind, 'configuration': config, 'requests': len(group),
        'unique_contexts': len({r['case_id'] for r in group}),
        'source_counts': dict(Counter(r['source'] for r in group)),
        'valid': len(valid), 'usd': sum(r['usd'] for r in group),
        'median_usd': statistics.median(r['usd'] for r in group),
        'input_tokens': input_tokens, 'output_tokens_including_reasoning': output_tokens,
        'reasoning_tokens': reasoning,
        'reasoning_fraction_of_output': reasoning / output_tokens if output_tokens else 0,
    }
    if kind == 'triage':
        refs = [r for r in valid if cases[r['case_id']].get('reference')]
        value['rationale_without_cyrillic'] = sum(not re.search('[А-Яа-яЁё]', r['answer']['rationale']) for r in valid)
        value['historical_reference_count'] = len(refs)
        value['rejects_confidence_at_least_08'] = sum(not r['answer']['affects_foreigners'] and r['answer']['confidence'] >= .8 for r in valid)
        value['historical_reference_gate_agreement'] = sum(
            (not r['answer']['affects_foreigners'] and r['answer']['confidence'] >= .8) == cases[r['case_id']]['reference']['rejects'] for r in refs)
        value['historical_reference_is_not_independent_gold'] = True
    if kind in ('analysis', 'reanalysis'):
        refs = [r for r in valid if cases[r['case_id']].get('baseline')]
        value['historical_baseline_count'] = len(refs)
        value['historical_publication_agreement'] = sum(
            (r['answer']['relevant'] and r['answer']['score'] >= 3) ==
            (cases[r['case_id']]['baseline']['answer']['relevant'] and
             cases[r['case_id']]['baseline']['answer']['score'] >= 3) for r in refs)
        value['historical_score_agreement'] = sum(
            r['answer']['score'] == cases[r['case_id']]['baseline']['answer']['score'] for r in refs)
        value['baseline_agreement_is_not_legal_accuracy'] = True
    summary.append(value)

pairs = []
for case in cases.values():
    if case['kind'] not in ('analysis', 'reanalysis'):
        continue
    matching = [r for r in rows if r['case_id'] == case['id'] and r['answer']]
    if not matching:
        continue
    record = {'case_id': case['id'], 'source': case['source'], 'kind': case['kind'], 'answers': []}
    for row in matching:
        answer = row['answer']
        record['answers'].append({'configuration': variant(row), 'id': row['custom_id'],
            'score': answer['score'], 'category': answer['category'],
            'publish': answer['relevant'] and answer['score'] >= 3,
            'usd': row['usd'], 'changes_count': len(answer['changes_since_previous'])})
    pairs.append(record)
data = {'cohorts': summary, 'analysis_pairs': pairs,
        'warning': 'Requests and repeated configurations are not independent laws or an overall accuracy sample. Historical triage labels are Haiku, not the current Sonnet model.'}
temp = OUT / 'cohort_summary.tmp'
temp.write_text(json.dumps(data, ensure_ascii=False, indent=2))
temp.replace(OUT / 'cohort_summary.json')
print(json.dumps({'cohorts': len(summary), 'analysis_contexts': len(pairs)}))
