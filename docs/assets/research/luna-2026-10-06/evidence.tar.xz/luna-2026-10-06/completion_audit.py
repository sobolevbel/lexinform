import ast
from collections import Counter
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).parent
ROOT = Path('/Users/sobaleu/projects/lexinform')
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
cases = json.loads((OUT / 'cases.json').read_text())
manifest = json.loads((OUT / 'manifest.json').read_text())
expected_roles = {'analysis', 'reanalysis', 'triage', 'change_review', 'amendments', 'supplement', 'joint'}
requests = []
completed_rows = []
uncollected = []
errors = []
for item in plan:
    phase = item['phase']
    batch_requests = json.loads((OUT / (phase + '.requests.json')).read_text())
    requests.extend(batch_requests)
    if len(batch_requests) != item['requests']:
        errors.append('Plan count differs from request file: ' + phase)
    batch = ledger['batches'].get(phase)
    if not batch or batch['status'] != 'completed':
        uncollected.append(phase)
        continue
    parsed = json.loads((OUT / (phase + '.parsed.json')).read_text())
    completed_rows.extend(parsed)
    if len(parsed) != len(batch_requests):
        errors.append('Completed output coverage differs: ' + phase)
    if abs(sum(r['usd'] for r in parsed) - batch['actual_usd']) > 1e-9:
        errors.append('Output usage accounting differs: ' + phase)
canary_requests = json.loads((OUT / 'canary.requests.json').read_text())
models = Counter(r['body']['model'] for r in requests + canary_requests)
endpoints = Counter(r['url'] for r in requests + canary_requests)
all_reserved = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
all_reserved += sum(p['reserved_usd'] for p in plan if p['phase'] not in ledger['batches'])

def dotted_name(node):
    if isinstance(node, ast.Attribute):
        prefix = dotted_name(node.value)
        return prefix + '.' + node.attr if prefix else node.attr
    return node.id if isinstance(node, ast.Name) else ''

sync_generation_calls = []
batch_creation_calls = []
for path in OUT.glob('*.py'):
    tree = ast.parse(path.read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = dotted_name(node.func)
            if name.endswith(('.responses.create', '.chat.completions.create', '.messages.create')):
                sync_generation_calls.append({'file': path.name, 'line': node.lineno})
            if name.endswith('.batches.create'):
                batch_creation_calls.append({'file': path.name, 'line': node.lineno})
head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, capture_output=True, text=True, check=True).stdout.strip()
status = subprocess.run(['git', 'status', '--porcelain'], cwd=ROOT, capture_output=True, text=True, check=True).stdout
checks = {
    'all_roles_represented': expected_roles <= {c['kind'] for c in cases},
    'only_luna_in_planned_paid_requests': set(models) == {'gpt-6-luna'},
    'only_responses_batch_request_endpoint': set(endpoints) == {'/v1/responses'},
    'no_direct_generation_calls_in_experiment_scripts': not sync_generation_calls and bool(batch_creation_calls),
    'all_planned_outputs_collected': not uncollected,
    'budget_worst_case_at_most_2_usd': all_reserved <= 2,
    'output_accounting_consistent_for_completed_jobs': not errors,
    'repository_head_unchanged': head == manifest['git_head'],
    'repository_worktree_clean': not status,
}
requirements = json.loads((OUT / 'final_requirement_matrix.json').read_text())
decision_path = OUT / 'final_research_decision.json'
decision = json.loads(decision_path.read_text()) if decision_path.exists() else {}
assessment_recorded = (
    requirements.get('completion_proven') is True
    and decision.get('all_planned_collected') is True
    and decision.get('quality_equivalence_proven', False) is False
    and abs(decision.get('paid_api_usd', -1) - all_reserved) < 1e-9
    and bool(decision.get('role_recommendations'))
)
data = {'checks': checks, 'planned_paid_requests_including_canary': len(requests) + len(canary_requests),
    'case_count': len(cases), 'roles': dict(Counter(c['kind'] for c in cases)),
    'request_models': dict(models), 'request_endpoints': dict(endpoints),
    'accounted_completed_batch_cost_usd': sum(b.get('actual_usd', 0) for b in ledger['batches'].values()),
    'max_committed_usd': all_reserved, 'unfinished_phases': uncollected, 'errors': errors,
    'direct_generation_calls': sync_generation_calls, 'batch_creation_calls': batch_creation_calls,
    'legal_quality_review': 'quality_audit.json',
    'scope': 'This audits execution, accounting and coverage. Semantic suitability requires manual source review and an explicit final recommendation; green mechanical checks alone do not complete the research.',
    'manual_source_assessment_recorded': assessment_recorded,
    'research_decision': 'final_research_decision.json',
    'production_quality_equivalence_proven': False,
    'completion_proven': all(checks.values()) and assessment_recorded}
temporary = OUT / 'completion_audit.tmp'
temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2))
temporary.replace(OUT / 'completion_audit.json')
print(json.dumps({'checks': checks, 'planned_requests': data['planned_paid_requests_including_canary'],
                  'max_committed': all_reserved, 'unfinished_count': len(uncollected)}))
