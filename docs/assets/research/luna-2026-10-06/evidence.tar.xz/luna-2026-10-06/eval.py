from __future__ import annotations

import argparse
import base64
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import random
import sqlite3
import subprocess
from typing import Any

from dotenv import dotenv_values
import openai
from openai.lib._pydantic import to_strict_json_schema
import pypdf

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import (
    Analysis, ApplicantType, Amendments, AmendmentsContext, BillContext,
    ChangedPassage, ChangeContext, ChangeReview, DocumentDigest,
    JointBillDescription, JointComparison, JointContext, ScannedDocument,
    SupplementContext, Triage, TriageContext,
)
from lexinform.keywords import KeywordPrefilter
from lexinform.sections import excerpts, trim_print

ROOT = Path('/Users/sobaleu/projects/lexinform')
CORPUS = ROOT.parent / 'lexinform-corpus'
OUT = Path(__file__).parent
MODEL = 'gpt-6-luna'
BUDGET = 2.0
MODELS = {'analysis': Analysis, 'reanalysis': Analysis, 'triage': Triage,
          'change_review': ChangeReview, 'amendments': Amendments,
          'supplement': DocumentDigest, 'joint': JointComparison}


def dump(name: str, value: Any) -> None:
    path = OUT / name
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2))
    temporary.replace(path)


def split(number: str) -> str:
    return 'calibration' if int(hashlib.sha256(number.encode()).hexdigest()[:8], 16) % 4 == 0 else 'heldout'


def request(case: dict[str, Any], effort: str, *, suffix: str = 'base', extra: str = '') -> dict[str, Any]:
    cap = 16000 if case['kind'] in ('analysis', 'reanalysis') else 4000
    if effort == 'none':
        cap = 2000 if case['kind'] == 'triage' else 4000
    if effort == 'high':
        cap = 25000
    user_content: Any = case['user']
    if case.get('pdf'):
        user_content = [
            {'type': 'input_file', 'filename': 'document.pdf',
             'file_data': 'data:application/pdf;base64,' + case['pdf']},
            {'type': 'input_text', 'text': case['user']},
        ]
    body = {
        'model': MODEL, 'reasoning': {'effort': effort}, 'max_output_tokens': cap,
        'prompt_cache_options': {'mode': 'explicit'},
        'input': [{'role': 'system', 'content': case['system'] + extra},
                  {'role': 'user', 'content': user_content}],
        'text': {'format': {'type': 'json_schema', 'name': case['kind'],
                           'strict': True, 'schema': to_strict_json_schema(MODELS[case['kind']])}},
    }
    token_bound = min(1050000, len(json.dumps(body, ensure_ascii=False).encode('utf8')) + 4096)
    if case.get('pdf'):
        token_bound = 1050000
    long = token_bound > 272000
    reserve = (token_bound * (0.1 if long else 0.05) + cap * (0.375 if long else 0.25)) / 1000000
    return {'custom_id': case['id'] + '-' + effort + '-' + suffix,
            'method': 'POST', 'url': '/v1/responses', 'body': body,
            '_reserve': reserve, '_case_id': case['id']}


def prepare() -> None:
    db = sqlite3.connect(':memory:')
    db.row_factory = sqlite3.Row
    db.executescript(subprocess.run(['git', 'show', 'origin/state:lexinform.sql'],
                                  cwd=ROOT, check=True, capture_output=True, text=True).stdout)
    snapshot = subprocess.run(['git', 'rev-parse', 'origin/state'], cwd=ROOT,
                              check=True, capture_output=True, text=True).stdout.strip()
    cases: list[dict[str, Any]] = []
    memos: dict[str, list[dict[str, Any]]] = {}
    for row in db.execute('select number,record_json from analysis_memo'):
        record = json.loads(row['record_json'])
        if 'analysis' in record:
            memos.setdefault(row['number'], []).append(record)

    def add(kind: str, number: str, system: str, user: str, **extras: Any) -> None:
        case_id = kind + '-' + number.replace('/', '_')
        if any(c['id'] == case_id for c in cases):
            case_id += '-' + str(sum(c['number'] == number and c['kind'] == kind for c in cases))
        cases.append({'id': case_id, 'number': number, 'kind': kind, 'system': system,
                      'user': user, 'split': split(number), **extras})

    for row in db.execute('select * from llm_batch_items where result_json is not null order by rowid'):
        kind = row['call_kind']
        if kind not in ('analysis', 'reanalysis'):
            continue
        meta = json.loads(row['meta_json'])
        result = json.loads(row['result_json'])
        if not result.get('answer') or not meta.get('text'):
            continue
        bill_row = db.execute('select title,summary_json from bills where term=? and number=?',
                              (row['term'], row['number'])).fetchone()
        summary = json.loads(bill_row['summary_json']) if bill_row['summary_json'] else {}
        previous = None
        if kind == 'reanalysis':
            prior = sorted(memos.get(row['number'], []), key=lambda x: x.get('created_at', ''))
            previous = next((m['analysis'] for m in prior if m['analysis'] != result['answer']), None)
        ctx = BillContext(number=row['number'], title=bill_row['title'],
                          description=summary.get('description'), document_date=summary.get('document_date'),
                          applicant_type=summary.get('applicant', 'government'),
                          text=meta['text'], truncated=meta['truncated'], text_source=meta['text_source'],
                          source_kind=meta['source_kind'],
                          previous_summary=previous['summary'] if previous else None,
                          previous_key_changes=previous['key_changes'] if previous else [])
        add(kind, row['number'], prompts.gpt51_system_prompt('ru'), prompts.build_user_prompt(ctx),
            source='saved_batch_text', baseline=result, chars=len(meta['text']),
            previous_reconstructed=previous is not None, meta=meta,
            context=ctx.model_dump(mode='json'))

    full_numbers = ['950', '1962', '2699', '3039', '1630', '342', '319', '276', '1407', '825']
    for number in full_numbers:
        record = json.loads((CORPUS / 'sejm/term10/prints' / (number + '.json')).read_text())
        with gzip.open(CORPUS / 'sejm/term10/text' / (number + '.txt.gz'), 'rt', errors='replace') as handle:
            text = handle.read()
        trimmed = trim_print(text)
        ctx = BillContext(number=number, title=record['title'], description=record.get('description'),
                          document_date=record.get('documentDate'), applicant_type=ApplicantType.GOVERNMENT,
                          text=trimmed.text, truncated=False, text_source='pdf')
        add('analysis', number, prompts.gpt51_system_prompt('ru'), prompts.build_user_prompt(ctx),
            source='corpus_full_text', chars=len(ctx.text), context=ctx.model_dump(mode='json'))

    oracle = json.loads((CORPUS / 'checks/out/oracle_triage.json').read_text())
    positives = sorted(k for k,v in oracle.items() if not v['old'] and v['affects'])
    negatives = sorted(k for k,v in oracle.items() if not v['old'] and not v['affects'])
    random.Random(61005).shuffle(positives)
    random.Random(61006).shuffle(negatives)
    numbers = list(dict.fromkeys(full_numbers + positives[:35] + negatives[:35]))
    prefilter = KeywordPrefilter()
    for number in numbers:
        record = json.loads((CORPUS / 'sejm/term10/prints' / (number + '.json')).read_text())
        with gzip.open(CORPUS / 'sejm/term10/text' / (number + '.txt.gz'), 'rt', errors='replace') as handle:
            text = trim_print(handle.read()).text
        ctx = TriageContext(number=number, title=record['title'], description=record.get('description'),
                            applicant_type=ApplicantType.GOVERNMENT,
                            excerpts=excerpts(text, prefilter.spans(text)), text_chars=len(text))
        add('triage', number, prompts.triage_system_prompt('ru'), prompts.build_triage_prompt(ctx),
            source='corpus_excerpts', reference=oracle.get(number), context=ctx.model_dump(mode='json'))

    mutations = [
        ('deadline', 'Zezwolenie na pobyt czasowy jest ważne do dnia 30 czerwca 2027 r.',
         'Zezwolenie na pobyt czasowy jest ważne do dnia 30 września 2027 r.'),
        ('amount', 'Opłata za wydanie karty pobytu wynosi 100 zł.', 'Opłata za wydanie karty pobytu wynosi 200 zł.'),
        ('negation', 'Cudzoziemiec ma prawo do świadczenia wychowawczego.',
         'Cudzoziemiec nie ma prawa do świadczenia wychowawczego.'),
        ('scope', 'Przepis stosuje się do wszystkich cudzoziemców.',
         'Przepis stosuje się wyłącznie do obywateli Ukrainy.'),
        ('reference', 'Przepis stosuje się do osób określonych w art. 2 ust. 1 (obywatele Ukrainy).',
         'Przepis stosuje się do osób określonych w art. 2 ust. 2 (małżonkowie obywateli Ukrainy).'),
        ('format', 'Cudzoziemiec ma prawo do pracy.', 'Cudzoziemiec  ma prawo do pracy.'),
        ('unrelated', 'Mandat posła wygasa z chwilą śmierci.', 'Mandat posła wygasa z dniem śmierci.'),
    ]
    for name, old, new in mutations:
        ctx = ChangeContext(number='CONTROL-' + name, title='Kontrolowana zmiana przepisu',
                            summary='Условия пребывания, работы и выплат для иностранцев.', key_changes=[],
                            passages=[ChangedPassage(old=old, new=new, before='', after='')],
                            changed_words=5, total_words=100, old_law=old, new_law=new)
        add('change_review', name, prompts.change_review_system_prompt('ru'), prompts.build_change_review_prompt(ctx),
            source='synthetic_control', gold={'material': name not in ('format', 'unrelated')})

    synthetic = [
        ('deadline', 'Obywatele Ukrainy, których pobyt uznaje się za legalny, zachowują to uprawnienie do dnia 30 września 2027 r. Ustawa wchodzi w życie po upływie 14 dni od dnia ogłoszenia.', 5),
        ('work', 'Cudzoziemiec może wykonywać pracę bez zezwolenia na pracę, jeśli posiada zezwolenie na pobyt stały. Ustawa wchodzi w życie po upływie 30 dni od dnia ogłoszenia.', 4),
        ('social', 'Świadczenie wychowawcze w wysokości 800 zł miesięcznie przysługuje cudzoziemcom posiadającym zezwolenie na pobyt stały. Nie przysługuje osobom posiadającym wyłącznie wizę turystyczną.', 3),
        ('agency', 'Straż Graniczna prowadzi badania jakości pasz przywożonych z zagranicy. Ustawa nie zmienia warunków pobytu ani pracy cudzoziemców.', 1),
        ('uncertain', 'Projekt zmienia ustawę o cudzoziemcach. [Brak dalszej części dokumentu.]', 5),
    ]
    for name, text, score in synthetic:
        ctx = BillContext(number='CONTROL-' + name, title='Projekt kontrolny', description=None,
                          document_date=None, applicant_type=ApplicantType.GOVERNMENT,
                          text=text, truncated=name == 'uncertain', text_source='pdf')
        add('analysis', 'control-' + name, prompts.gpt51_system_prompt('ru'), prompts.build_user_prompt(ctx),
            source='synthetic_control', gold={'publish': score >= 3, 'score': score, 'uncertain': name == 'uncertain'},
            context=ctx.model_dump(mode='json'))
        triage = TriageContext(number=ctx.number, title=ctx.title, description=None,
                               applicant_type=ctx.applicant_type, excerpts=text, text_chars=len(text))
        add('triage', 'control-' + name, prompts.triage_system_prompt('ru'), prompts.build_triage_prompt(triage),
            source='synthetic_control', gold={'affects_foreigners': name != 'agency'})

    amendment = AmendmentsContext(number='CONTROL-amendment', title='Pomoc obywatelom Ukrainy',
                                 source_kind='committee_amendments', truncated=False,
                                 previous_summary='Срок легального пребывания украинцев продлевается до 30 июня 2027 г.',
                                 text='Poprawka nr 1: wyrazy "30 czerwca 2027 r." zastępuje się wyrazami "30 września 2027 r.". Komisja wnosi o odrzucenie poprawki.',
                                 proposal='Komisja wnosi o odrzucenie poprawki.')
    add('amendments', 'control-proposal', prompts.gpt51_amendments_system_prompt('ru'),
        prompts.build_amendments_prompt(amendment), source='synthetic_control',
        gold={'affects_foreigners': True, 'not_adopted': True, 'new_date': '30 сентября 2027'})
    for support, text in [(False, 'Rada Ministrów negatywnie ocenia projekt i nie popiera jego przyjęcia. Projekt znosi wymóg zezwolenia na pracę dla wszystkich cudzoziemców.'),
                          (True, 'Rada Ministrów popiera projekt. Zwraca uwagę, że przepis dotyczący pracy bez zezwolenia obejmuje tylko posiadaczy zezwolenia na pobyt stały.')]:
        ctx = SupplementContext(number='CONTROL-position', title='Praca cudzoziemców',
                                document_title='Stanowisko Rządu', source_kind='government_position',
                                text=text, truncated=False, previous_summary='Проект меняет условия работы иностранцев.')
        add('supplement', 'control-position-' + str(support), prompts.gpt51_supplement_system_prompt('ru'),
            prompts.build_supplement_prompt(ctx), source='synthetic_control',
            gold={'supports': support, 'affects_foreigners': True})
    for same in (True, False):
        a = JointBillDescription(number='A', title='Pobyt', applicant_type=ApplicantType.GOVERNMENT,
                                 summary='Продление легального пребывания украинцев до 30 сентября 2027 г.')
        b = a.model_copy(update={'number': 'B', 'summary': a.summary if same else 'Продление легального пребывания украинцев до 30 июня 2027 г.'})
        ctx = JointContext(subject=a, others=[b])
        add('joint', 'control-' + str(same), prompts.gpt51_joint_system_prompt('ru'),
            prompts.build_joint_prompt(ctx), source='synthetic_control', gold={'same_substance': same})

    scan_oracle = json.loads((CORPUS / 'checks/out/oracle_scan_triage.json').read_text())
    for key in ['RPW-2793-2025', 'RPW-6471-2025']:
        item = scan_oracle[key]
        reader = pypdf.PdfReader(item['path'])
        def pdf_data(limit: int) -> str:
            writer = pypdf.PdfWriter()
            for page in reader.pages[:limit]:
                writer.add_page(page)
            stream = io.BytesIO()
            writer.write(stream)
            return base64.b64encode(stream.getvalue()).decode('ascii')
        window = pdf_data(8)
        scan = ScannedDocument(data=window, pages=min(8, len(reader.pages)), of_pages=len(reader.pages), sha256='')
        ctx = TriageContext(number=item['number'], title=item['title'], description=None,
                            applicant_type=ApplicantType.GOVERNMENT, excerpts='', text_chars=0, scan=scan)
        add('triage', 'scan-' + key, prompts.triage_system_prompt('ru'), prompts.build_triage_prompt(ctx),
            pdf=window, source='real_scan_window', reference=item, pages=scan.pages)
        if key == 'RPW-2793-2025':
            full = pdf_data(len(reader.pages))
            scan = ScannedDocument(data=full, pages=len(reader.pages), of_pages=len(reader.pages), sha256='')
            ctx2 = BillContext(number=item['number'], title=item['title'], description=None, document_date=None,
                               applicant_type=ApplicantType.GOVERNMENT, text='', truncated=False, text_source='scan', scan=scan)
            add('analysis', 'scan-' + key, prompts.gpt51_system_prompt('ru'), prompts.build_user_prompt(ctx2),
                pdf=full, source='real_full_scan', pages=scan.pages)

    requests = []
    for case in cases:
        efforts = ['none', 'medium'] if case['kind'] == 'triage' else ['medium']
        if case['source'] == 'synthetic_control' and case['kind'] != 'triage':
            efforts.append('high')
        if case['kind'] == 'analysis' and case['number'] in ('1039', '1040', '3141', '3150', '1962', 'RCL/12399355'):
            efforts.append('high')
        if case.get('pdf'):
            efforts = ['medium']
        for effort in efforts:
            requests.append(request(case, effort))
    reserve = sum(r['_reserve'] for r in requests)
    dump('cases.json', cases)
    dump('phase1.requests.json', requests)
    dump('manifest.json', {'model': MODEL, 'budget': BUDGET, 'state_snapshot': snapshot,
                          'git_head': subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT,
                                                    check=True, capture_output=True, text=True).stdout.strip(),
                          'prompt_version': prompts.PROMPT_VERSION,
                          'pricing': {'short_input': .05, 'short_output': .25, 'long_input': .1, 'long_output': .375},
                          'cache': 'explicit without breakpoints; no writes or reads',
                          'split': 'sha256(number) % 4, fixed before answers',
                          'phase1_reserved': reserve, 'case_count': len(cases), 'request_count': len(requests)})
    print(json.dumps({'cases': len(cases), 'requests': len(requests), 'max_reserved_usd': reserve,
                      'roles': {k: sum(c['kind'] == k for c in cases) for k in MODELS}}, indent=2))
    if reserve > BUDGET:
        raise SystemExit('Reservation exceeds budget; no submission permitted')


def client() -> openai.OpenAI:
    key = os.environ.get('OPENAI_API_KEY')
    if not key:
        with (ROOT / '.env').open() as handle:
            for line in handle:
                if line.lstrip().startswith(('OPENAI_API_KEY=', 'OPENAI_API_KEY =', 'export OPENAI_API_KEY=')):
                    key = dotenv_values(stream=io.StringIO(line)).get('OPENAI_API_KEY')
                    break
    if not key:
        raise SystemExit('API credential unavailable')
    return openai.OpenAI(api_key=key, max_retries=0, timeout=90)


def submit(phase: str) -> None:
    path = OUT / 'ledger.json'
    ledger = json.loads(path.read_text()) if path.exists() else {'budget_usd': BUDGET, 'batches': {}}
    if phase in ledger['batches']:
        raise SystemExit('Already submitted or uncertain intent exists; no automatic resubmission')
    requests = json.loads((OUT / (phase + '.requests.json')).read_text())
    reserve = sum(r['_reserve'] for r in requests)
    committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
    plan_path = OUT / 'chunk_plan.json'
    if plan_path.exists():
        plan = json.loads(plan_path.read_text())
        committed += sum(p['reserved_usd'] for p in plan
                         if p['phase'] not in ledger['batches'] and p['phase'] != phase)
    if committed + reserve > BUDGET:
        raise SystemExit(f'Budget exceeded: {committed + reserve:.6f}')
    payload = OUT / (phase + '.jsonl')
    payload.write_text('\n'.join(json.dumps({k:v for k,v in r.items() if not k.startswith('_')}, ensure_ascii=False)
                                 for r in requests) + '\n')
    api = client()
    ledger['batches'][phase] = {'reserved_usd': reserve, 'status': 'uploading', 'request_count': len(requests)}
    dump('ledger.json', ledger)
    with payload.open('rb') as handle:
        uploaded = api.files.create(file=handle, purpose='batch')
    ledger['batches'][phase].update({'file_id': uploaded.id, 'status': 'submitting_uncertain'})
    dump('ledger.json', ledger)
    batch = api.batches.create(input_file_id=uploaded.id, endpoint='/v1/responses', completion_window='24h',
                               metadata={'experiment': 'lexinform-luna-20261005', 'phase': phase, 'budget_usd': '2'})
    ledger['batches'][phase].update({'batch_id': batch.id, 'status': batch.status})
    dump('ledger.json', ledger)
    dump(phase + '.batch.json', batch.model_dump(mode='json'))
    print(json.dumps({'batch_id': batch.id, 'status': batch.status, 'requests': len(requests),
                      'reserved_usd': reserve, 'total_committed_usd': committed + reserve}))


def collect(phase: str) -> None:
    ledger = json.loads((OUT / 'ledger.json').read_text())
    record = ledger['batches'][phase]
    api = client()
    batch = api.batches.retrieve(record['batch_id'])
    record['status'] = batch.status
    dump(phase + '.batch.json', batch.model_dump(mode='json'))
    if batch.output_file_id:
        data = api.files.content(batch.output_file_id).text
        (OUT / (phase + '.results.jsonl')).write_text(data)
    if batch.error_file_id:
        (OUT / (phase + '.errors.jsonl')).write_text(api.files.content(batch.error_file_id).text)
    terminal = batch.status in ('completed', 'failed', 'expired', 'cancelled')
    if terminal:
        results = OUT / (phase + '.results.jsonl')
        cost = 0.0
        rows = []
        if results.exists():
            for line in results.read_text().splitlines():
                raw = json.loads(line)
                response = raw.get('response') or {}
                body = response.get('body') or {}
                usage = body.get('usage') or {}
                input_count = usage.get('input_tokens', 0)
                details = usage.get('input_tokens_details') or {}
                read = details.get('cached_tokens', 0)
                write = details.get('cache_write_tokens', 0)
                rates = (.1, .01, .125, .375) if input_count > 272000 else (.05, .005, .0625, .25)
                usd = ((input_count-read-write)*rates[0]+read*rates[1]+write*rates[2]+usage.get('output_tokens',0)*rates[3])/1000000
                cost += usd
                messages = [item for item in body.get('output', []) if item.get('type') == 'message'
                            and item.get('phase') in (None, 'final_answer')]
                text = ''.join(part.get('text', '') for item in messages
                               for part in item.get('content', []) if part.get('type') == 'output_text')
                answer = None
                validation = None
                try:
                    kind = raw['custom_id'].split('-')[0]
                    if raw['custom_id'].startswith('change_review-'):
                        kind = 'change_review'
                    answer = MODELS[kind].model_validate_json(text).model_dump(mode='json')
                except (ValueError, KeyError) as exc:
                    validation = str(exc)[:500]
                rows.append({'custom_id': raw['custom_id'], 'status': body.get('status'),
                             'http_status': response.get('status_code'), 'usage': usage, 'usd': usd,
                             'answer': answer, 'validation_error': validation,
                             'error': raw.get('error') or body.get('error'),
                             'incomplete_details': body.get('incomplete_details')})
        record['actual_usd'] = cost
        dump(phase + '.parsed.json', rows)
    dump('ledger.json', ledger)
    print(json.dumps({'batch_id': batch.id, 'status': batch.status,
                      'counts': batch.request_counts.model_dump() if batch.request_counts else None,
                      'actual_usd': record.get('actual_usd'), 'errors': batch.errors.model_dump() if batch.errors else None}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'submit', 'collect'])
    parser.add_argument('phase', nargs='?', default='phase1')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    elif args.action == 'submit':
        submit(args.phase)
    else:
        collect(args.phase)
