from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert not (OUT / 'triage_v1_plan.json').exists()
cases = json.loads((OUT / 'cases.json').read_text())
selected = [c for c in cases if c['kind'] == 'triage']
tail = '''
Precision and recall checks: distinguish an operative change from the description of an already existing rule in the justification. Do not say the bill creates a visa, residence or foreigner-list measure merely because it describes the existing system. Ethnic origin, a national-minority label and foreign citizenship are different: do not assume a person is a non-citizen because of their ethnicity. Preserve any explicit Polish-citizenship restriction in the supplied fragments. If citizenship eligibility is not established by the visible fragments, do not invent it: use the existing inconclusive-case rule and explain the uncertainty. A short provision that changes a specific non-citizen's eligibility, document or employment-check procedure is relevant even inside a large institutional bill. General applicability to everyone or an agency keyword alone is insufficient to assert a specific change for foreigners; name the actual operative effect when visible. When a potentially material effect is uncertain, pass with lower confidence instead of rejecting. Return only the final schema JSON, in Russian.
'''
template = next(c for c in selected if c['source'] == 'synthetic_control')
guards = [
    ('eu_check', 'Pracodawca infrastruktury krytycznej występuje o informację z rejestru karnego państwa obywatelstwa pracownika będącego obywatelem innego państwa UE niż Polska. Jest to nowa procedura sprawdzenia pracownika.', True),
    ('minority_citizens', 'Projekt uznaje nową mniejszość narodową. Uprawnienia przysługują wyłącznie obywatelom polskim należącym do tej mniejszości; nie zmieniają się prawa osób nieposiadających obywatelstwa polskiego.', False),
    ('existing_foreigner_list', 'Projekt zmienia wyłącznie techniczne formularze kontroli jakości żywności. Uzasadnienie opisuje istniejącą możliwość wpisania cudzoziemca na listę osób niepożądanych, której projekt nie zmienia. Nie zmieniają się prawa, obowiązki ani procedury cudzoziemców.', False),
    ('new_foreigner_document', 'Projekt o organizacji urzędu zawiera jeden nowy przepis: cudzoziemiec bez numeru PESEL może złożyć wniosek o świadczenie, przedstawiając ważny paszport zamiast numeru PESEL.', True),
    ('inconclusive_stay', 'Widoczny fragment zapowiada zmianę terminu legalnego pobytu cudzoziemców, ale urywa się przed podaniem nowych warunków i terminu.', True),
]
new = []
for name, text, affects in guards:
    case = {'id': 'triage-v1guard-' + name, 'number': 'T1-' + name,
            'kind': 'triage', 'system': template['system'], 'user': text,
            'split': 'heldout', 'source': 'new_triage_v1_guard',
            'gold': {'affects_foreigners': affects}}
    new.append(case)
requests = [module.request(c, 'medium', suffix='triage_v1', extra=tail) for c in selected + new]
api = module.client()

def count(request):
    body = request['body']
    result = api.responses.input_tokens.count(model=body['model'], input=body['input'], text=body['text'])
    return request['custom_id'], result.input_tokens

with ThreadPoolExecutor(max_workers=4) as pool:
    counts = dict(pool.map(count, requests))
for request in requests:
    bound = counts[request['custom_id']] + 1024
    assert bound < 272000
    request['_input_tokens_preflight'] = bound
    request['_input_count_exact'] = False
    request['_input_count_with_safety_margin'] = True
    request['_reserve'] = (bound * .05 + request['body']['max_output_tokens'] * .25) / 1000000
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(p['reserved_usd'] for p in plan if p['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2, (committed, reserve)
requests.sort(key=lambda r: (r['_input_tokens_preflight'], r['custom_id']))
groups = [[]]
size = 0
for request in requests:
    bound = request['_input_tokens_preflight']
    if groups[-1] and size + bound > 250000:
        groups.append([])
        size = 0
    groups[-1].append(request)
    size += bound
added = []
for index, group in enumerate(groups):
    phase = 'triagev1_' + str(index + 1)
    module.dump(phase + '.requests.json', group)
    added.append({'phase': phase, 'requests': len(group),
                  'input_tokens': sum(r['_input_tokens_preflight'] for r in group),
                  'reserved_usd': sum(r['_reserve'] for r in group)})
module.dump('triage_v1_prompt.json', {'tail': tail, 'effort': 'medium',
    'evaluation_type': 'Exploratory calibration after source-based review of original triage failures; all original cases rerun and five new guard cases frozen before answers.'})
module.dump('triage_v1_token_counts.json', counts)
module.dump('triage_v1_plan.json', added)
module.dump('cases.json', cases + new)
module.dump('chunk_plan.json', plan + added)
module.dump('triage_edge_source_review.json', {'findings': [
    {'number': '2355', 'fact': 'Proposed art. 6zzc includes citizenship-state criminal-record requests for workers who are citizens of another EU member state.', 'triage_expectation': 'pass', 'qualification': 'Historical Haiku rejection is not reliable independent ground truth.'},
    {'number': '2360', 'fact': 'The bill adds Greek minority to art. 2(2), without changing art. 2(1) citizenship requirement.', 'external_primary_source': 'https://eli.gov.pl/api/acts/DU/2005/141/text.html', 'qualification': 'Underlying act defines national minorities as groups of Polish citizens. That definition is not quoted in the supplied extract; evaluate unsupported non-citizen claims separately from conservative inconclusive passing.'},
    {'number': '878', 'fact': 'The foreigner undesirable-stay list is described as existing legislation in the justification; operative amendments concern customs, sanctions, confiscation and tax administration.', 'qualification': 'Do not describe the foreigner-list mechanism as a new bill provision. General business effects may still justify conservative triage passing.'},
    {'number': '1894', 'fact': 'The operative identity-control provisions expressly permit foreigner-law documents and alternative identity data without PESEL.', 'qualification': 'A genuine narrow access procedure, even if the publication significance is below 3; triage passing is not a legal error.'},
]})
print(json.dumps({'requests': len(requests), 'reserved_usd': reserve, 'max_total': committed + reserve, 'groups': len(added)}))
