from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
from pathlib import Path

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import ChangedPassage, ChangeContext

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
lookup = {c['id']: c for c in cases}
controls = [
    ('vacatio', 'analysis-1040', '14 dni od dnia ogłoszenia', '30 dni od dnia ogłoszenia', True),
    ('employment_or_and', 'analysis-1040', 'jest zatrudniony lub prowadzi', 'jest zatrudniony i prowadzi', True),
    ('course_insurance_negation', 'analysis-3141', 'niepodlegające obowiązkowi ubezpieczenia', 'podlegające obowiązkowi ubezpieczenia', True),
    ('format_only', 'analysis-3141', 'kursy języka polskiego', 'kursy  języka polskiego', False),
]
new = []
requests = []
for name, original_id, old, replacement, material in controls:
    original = lookup[original_id]
    old_law = original['context']['text']
    assert old in old_law
    at = old_law.index(old)
    new_law = old_law[:at] + replacement + old_law[at + len(old):]
    baseline = original.get('baseline', {}).get('answer', {})
    ctx = ChangeContext(number=original['number'], title=original['context']['title'],
                        summary=baseline.get('summary', original['context']['title']),
                        key_changes=baseline.get('key_changes', []),
                        passages=[ChangedPassage(old=old, new=replacement,
                                                 before=old_law[max(0, at - 160):at],
                                                 after=old_law[at + len(old):at + len(old) + 160])],
                        changed_words=1, total_words=len(old_law.split()),
                        old_law=old_law, new_law=new_law)
    c = {'id': 'change_review-corpus-' + name, 'number': original['number'],
         'kind': 'change_review', 'split': 'heldout', 'source': 'controlled_corpus_mutation',
         'system': prompts.change_review_system_prompt('ru'), 'user': prompts.build_change_review_prompt(ctx),
         'context': ctx.model_dump(mode='json'), 'gold': {'material': material},
         'source_case_id': original_id, 'mutation': {'old': old, 'new': replacement},
         'qualification': 'One controlled change inside the supplied real corpus text; not an actual historical legislative event.'}
    assert c['id'] not in lookup
    new.append(c)
    for effort in ['medium', 'high']:
        requests.append(module.request(c, effort, suffix='corpus'))
api = module.client()


def count(r):
    b = r['body']
    return r['custom_id'], api.responses.input_tokens.count(model=b['model'], input=b['input'], text=b['text']).input_tokens


with ThreadPoolExecutor(max_workers=4) as pool:
    counts = dict(pool.map(count, requests))
for r in requests:
    amount = counts[r['custom_id']] + 1024
    r['_input_tokens_preflight'] = amount
    r['_input_count_with_safety_margin'] = True
    cap = r['body']['max_output_tokens']
    long = amount > 272000
    r['_reserve'] = (amount * (.1 if long else .05) + cap * (.375 if long else .25)) / 1000000
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2
assert 'corpus_review' not in {x['phase'] for x in plan}
module.dump('corpus_review.requests.json', requests)
module.dump('cases.json', cases + new)
plan.insert(0, {'phase': 'corpus_review', 'requests': len(requests),
                'input_tokens': sum(r['_input_tokens_preflight'] for r in requests), 'reserved_usd': reserve})
module.dump('chunk_plan.json', plan)
print(json.dumps({'requests': len(requests), 'reserved_usd': reserve, 'max_total_usd': committed + reserve}))
