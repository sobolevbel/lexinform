from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
from pathlib import Path
import re

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert not (OUT / 'change_review_v1_plan.json').exists()
cases = json.loads((OUT / 'cases.json').read_text())
selected = [c for c in cases if c['kind'] == 'change_review']
tail = '''
Version comparison check: establish a real semantic difference between the supplied OLD and NEW versions before deciding material=true. Start with BYŁO/JEST and use the full texts to resolve context and any other actual differences; do not assume the displayed passage list is exhaustive. Provisions present in both versions are not newly added. The justification can describe a reform relative to an underlying statute, but that does not establish a difference between these two supplied versions of the bill. Do not infer a change merely from a detail not named in the prior short channel description. Extra ordinary spacing within unchanged words is not material when the words and legal meaning are unchanged. Preserve genuine changes to dates, amounts, negations, logical AND/OR conditions, scope and references, even a one-word or one-character edit. Base the rationale on the actual OLD-to-NEW difference, not on a general summary of the bill. Return only the final schema JSON.
'''
requests = [module.request(c, effort, suffix='change_review_v1', extra=tail)
            for c in selected for effort in ('medium', 'high')]
api = module.client()

def count(request):
    body = request['body']
    result = api.responses.input_tokens.count(model=body['model'], input=body['input'], text=body['text'])
    return request['custom_id'], result.input_tokens

with ThreadPoolExecutor(max_workers=4) as pool:
    counts = dict(pool.map(count, requests))
for request in requests:
    bound = counts[request['custom_id']] + 1024
    long = bound > 272000
    request['_input_tokens_preflight'] = bound
    request['_input_count_exact'] = False
    request['_input_count_with_safety_margin'] = True
    request['_reserve'] = (bound * (.1 if long else .05) + request['body']['max_output_tokens'] * (.375 if long else .25)) / 1000000
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(p['reserved_usd'] for p in plan if p['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2, (committed, reserve)
requests.sort(key=lambda r: (r['_input_tokens_preflight'], r['custom_id']))
groups = [[]]
size = 0
for request in requests:
    bound = request['_input_tokens_preflight']
    if groups[-1] and size + bound > 70000:
        groups.append([])
        size = 0
    groups[-1].append(request)
    size += bound
added = []
for index, group in enumerate(groups):
    phase = 'changev1_' + str(index + 1)
    module.dump(phase + '.requests.json', group)
    added.append({'phase': phase, 'requests': len(group),
                  'input_tokens': sum(r['_input_tokens_preflight'] for r in group),
                  'reserved_usd': sum(r['_reserve'] for r in group)})
case = next(c for c in cases if c['id'] == 'change_review-corpus-format_only')
old, new = case['context']['old_law'], case['context']['new_law']
assert re.sub(r'\s+', ' ', old) == re.sub(r'\s+', ' ', new)
assert len(new) == len(old) + 1
module.dump('change_review_v1_prompt.json', {'tail': tail,
    'evaluation_type': 'Exploratory calibration after a confirmed whitespace-only false positive inside the full 3141 corpus text. Rerun all eleven original synthetic and full-corpus mutation controls at medium/high; original cases are not fresh blind validation.',
    'selected_case_ids': [c['id'] for c in selected], 'reserved_usd': reserve})
module.dump('change_review_v1_token_counts.json', counts)
module.dump('change_review_v1_plan.json', added)
module.dump('chunk_plan.json', plan + added)
audit = json.loads((OUT / 'quality_audit.json').read_text())
audit['findings'].append({'case': 'change_review-corpus-format_only-medium-corpus',
    'severity': 'materiality_false_positive',
    'source_fact': 'The only edit adds one ordinary space in kursy języka polskiego; full old and new texts are identical after whitespace collapse. Both already include preparatory courses. Luna nevertheless says courses were added, material=true and confidence=.98.',
    'qualification': 'An isolated full-context stress test, not an actual historical legislative change. New change_review_v1 checks real OLD-to-NEW differences while retaining dates, amounts, negation and logical scope checks.'})
module.dump('quality_audit.json', audit)
print(json.dumps({'requests': len(requests), 'reserved_usd': reserve, 'max_total': committed + reserve, 'groups': len(added)}))
