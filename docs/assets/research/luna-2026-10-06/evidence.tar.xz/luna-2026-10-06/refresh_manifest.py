from collections import Counter
import json
from pathlib import Path

OUT = Path(__file__).parent
manifest = json.loads((OUT / 'manifest.json').read_text())
cases = json.loads((OUT / 'cases.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
ledger = json.loads((OUT / 'ledger.json').read_text())
manifest['case_count'] = len(cases)
manifest['case_kind_counts'] = dict(Counter(c['kind'] for c in cases))
manifest['case_source_counts'] = dict(Counter(c['source'] for c in cases))
manifest['initial_phase1_requests'] = 250
manifest['initial_phase1_status'] = 'Provider validation failure; zero executed requests and zero charge. Repartitioned requests are represented in the actual plan.'
manifest['initial_phase1_reserved_usd'] = manifest.pop('phase1_reserved', 1.9763118)
manifest.pop('request_count', None)
manifest.pop('all_planned_max_usd', None)
manifest['planned_request_count_including_canary'] = sum(p['requests'] for p in plan) + ledger['batches']['canary']['request_count']
manifest['accounted_cost_completed_batches_usd'] = sum(b.get('actual_usd', 0) for b in ledger['batches'].values())
manifest['current_all_committed_max_usd'] = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values()) + sum(p['reserved_usd'] for p in plan if p['phase'] not in ledger['batches'])
manifest['accounting_scope'] = 'Completed-batch cost is final for those jobs only; active and unsubmitted requests remain fully reserved. The ledger is authoritative.'
manifest['split_limits'] = 'Original split fixed before initial answers. Calibration uses known failures; new guards were fixed before their answers but are focused regression checks, not an independent random evaluation sample.'
manifest['research_extensions'] = [
    'joint_v1 calibrated on legal-date ambiguity and new unseen guards',
    'precision_v1 primary/revision exploratory repairs with new focused controls',
    'none on scans',
    'full-text analysis of four triage disagreements',
    'max plus frozen v2 planned across 41 real contexts and five guards; five unsent large max requests retired after repeated output exhaustion, with every context preserved in the high rerun',
    'controlled full-corpus mutations: vacatio, OR/AND, insurance negation, whitespace',
    'frozen v2 return-to-Poland scoring-stability check at medium/high/max; score 2 is defensible under the entry/exit rubric',
    'triage_v1 medium on all 86 original triage contexts and five new guards',
    'change_review_v1 on eleven original controls at medium/high after a raw full-context spacing false positive',
    'exact production-prepared date and OR/AND controls at medium/high with original and calibrated prompts',
    'high plus the identical frozen v2 prompt on all 41 real contexts and the same five guards, with 16k output cap',
    'conditions_v3 high targeted repair of two condition omissions and one consent-versus-refund deadline error, five prior passing/score checks and four fresh focused guards; draft extended before any submission',
    'unchanged v3 prompt high repeat and xhigh/64k on real Jamboree and medical procedures, plus a fresh mixed-domain guard after a whole group disappeared in a rich real input',
    'triage_v2 medium on all 91 prior triage contexts and six fresh guards, correcting an overly narrow foreigners-only interpretation after a real KSeF regression',
    'original/v1/v2 medium triage on six actual RCL contexts using production excerpts, covering a source type absent from the original real triage sample',
    '57 input-fidelity checks on30 repeated contexts after finding wrong government applicant metadata: original/v2 medium triage on25 corrected Sejm contexts, high-v2 on5 main contexts and v3 on2 of those; corrected only through production applicant_from_title, no new bills or source-text changes',
]
assert manifest['current_all_committed_max_usd'] <= manifest['budget']
temporary = OUT / 'manifest.tmp'
temporary.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
temporary.replace(OUT / 'manifest.json')
print(json.dumps({'cases': manifest['case_count'], 'planned_requests': manifest['planned_request_count_including_canary'], 'max_committed': manifest['current_all_committed_max_usd']}))
