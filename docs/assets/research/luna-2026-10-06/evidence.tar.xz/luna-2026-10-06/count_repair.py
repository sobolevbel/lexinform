from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
ledger = json.loads((OUT / 'ledger.json').read_text())
phase = sys.argv[1] if len(sys.argv) > 1 else 'analysis_repair'
assert phase not in ledger['batches']
requests = json.loads((OUT / (phase + '.requests.json')).read_text())
api = module.client()


def key(r):
    b = r['body']
    return hashlib.sha256(json.dumps({k: b[k] for k in ['model', 'input', 'text']}, sort_keys=True).encode()).hexdigest()


def count(r):
    b = r['body']
    result = api.responses.input_tokens.count(model=b['model'], input=b['input'], text=b['text'])
    return key(r), result.input_tokens


unique = {key(r): r for r in requests}
with ThreadPoolExecutor(max_workers=4) as executor:
    counts = dict(executor.map(count, unique.values()))
assert phase not in json.loads((OUT / 'ledger.json').read_text())['batches']
for r in requests:
    r['_input_tokens_preflight'] = counts[key(r)]
    r['_input_count_exact'] = True
module.dump(phase + '.requests.json', requests)
plan = json.loads((OUT / 'chunk_plan.json').read_text())
for x in plan:
    if x['phase'] == phase:
        x['input_tokens'] = sum(r['_input_tokens_preflight'] for r in requests)
module.dump('chunk_plan.json', plan)
module.dump(phase + '_input_counts.json', counts)
print(json.dumps({'counted_without_inference': len(unique), 'queued_input': sum(r['_input_tokens_preflight'] for r in requests)}))
