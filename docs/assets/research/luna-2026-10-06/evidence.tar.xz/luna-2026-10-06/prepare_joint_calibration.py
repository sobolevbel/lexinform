import importlib.util
import json
from pathlib import Path

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import ApplicantType, JointBillDescription, JointContext

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
selected = [c for c in cases if c['kind']=='joint']
new = []
controls = [
    ('filing_deadline', 'Заявление на ВНЖ нужно подать в течение 15 дней.', 'Заявление на ВНЖ нужно подать в течение 30 дней.', False),
    ('fee', 'Плата за карту пребывания составляет 100 злотых.', 'Плата за карту пребывания составляет 200 злотых.', False),
    ('eligibility', 'Право на пособие получают все иностранцы.', 'Право на пособие получают только владельцы постоянного ВНЖ.', False),
    ('negation', 'Иностранцы имеют право на пособие.', 'Иностранцы не имеют права на пособие.', False),
    ('editorial_date', 'Документ от 1 сентября 2026 г. Легальное пребывание украинцев продлевается до 30 июня 2027 г.',
     'Документ от 2 сентября 2026 г. Легальное пребывание украинцев продлевается до 30 июня 2027 г.', True),
]
for name, first, second, same in controls:
    a = JointBillDescription(number='A',title='Projekt kontrolny',applicant_type=ApplicantType.GOVERNMENT,summary=first)
    b = a.model_copy(update={'number':'B','summary':second})
    ctx = JointContext(subject=a,others=[b])
    c = {'id':'joint-heldout-'+name,'number':'heldout-'+name,'kind':'joint','split':'heldout',
         'source':'new_synthetic_holdout','system':prompts.gpt51_joint_system_prompt('ru'),
         'user':prompts.build_joint_prompt(ctx),'context':ctx.model_dump(mode='json'),
         'gold':{'same_substance':same}}
    assert c['id'] not in {x['id'] for x in cases}
    new.append(c)
selected += new
tail = '\n\nMateriality clarification: A difference is substantive when it changes a reader\'s legal entitlement, legal-stay end date, application deadline, applicable fee, benefit amount, negation, or eligibility. Set same_substance=false for those differences even if the general topic is identical. A different document issue/publication date with identical legal rules is editorial and may still be same_substance=true. Keep each actual difference in the summary or bullets. Return only the final schema JSON; do not add commentary or narrate your reasoning.'
requests = []
for case in selected:
    calibrated = dict(case)
    calibrated['system'] = case['system'].replace('wording, numbering, dates or detail',
                                                 'wording, numbering, purely editorial dates or other non-material detail')
    for effort in ['medium','high']:
        if case in new:
            requests.append(module.request(case,effort,suffix='newholdout_base'))
        requests.append(module.request(calibrated,effort,suffix='joint_v1',extra=tail))
for r in requests:
    r['_input_tokens_preflight'] = min(1050000,len(json.dumps(r['body'],ensure_ascii=False).encode())+4096)
    r['_input_count_exact'] = False
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd',b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed+reserve <= 2
assert 'joint_calibration' not in {x['phase'] for x in plan}
module.dump('joint_calibration.requests.json',requests)
module.dump('cases.json',cases+new)
module.dump('joint_v1_prompt.json',{'fixed_before_holdout_inspection':True,'training_source':'Only two preregistered calibration joint controls; original prompt explicitly called dates non-substantive.',
                                 'replacement':'wording, numbering, purely editorial dates or other non-material detail','tail':tail})
plan.insert(3,{'phase':'joint_calibration','requests':len(requests),
               'input_tokens':sum(r['_input_tokens_preflight'] for r in requests),'reserved_usd':reserve})
module.dump('chunk_plan.json',plan)
print(json.dumps({'requests':len(requests),'cases':len(selected),'new_unseen_controls':len(new),
                  'reserved_usd':reserve,'all_committed_and_planned_usd':committed+reserve},indent=2))
