import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert not (OUT / 'repartition_small_checks.json').exists()
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
original_count = sum(p['requests'] for p in plan)
original_reserve = sum(p['reserved_usd'] for p in plan)
replacement = {}
for phase in ('corpus_review', 'triage_edges'):
    assert phase not in ledger['batches'], 'Do not repartition a submitted or uncertain intent.'
    requests = json.loads((OUT / (phase + '.requests.json')).read_text())
    requests.sort(key=lambda r: (r['_input_tokens_preflight'], r['custom_id']))
    groups = [[]]
    size = 0
    for request in requests:
        bound = request['_input_tokens_preflight']
        if groups[-1] and size + bound > 70000:
            groups.append([])
            size = 0
        groups[-1].append(request)
        size += bound
    additions = []
    for index, group in enumerate(groups):
        new_phase = phase + '_' + str(index + 1)
        assert new_phase not in ledger['batches']
        module.dump(new_phase + '.requests.json', group)
        additions.append({'phase': new_phase, 'requests': len(group),
                          'input_tokens': sum(r['_input_tokens_preflight'] for r in group),
                          'reserved_usd': sum(r['_reserve'] for r in group)})
    replacement[phase] = additions
updated = []
for item in plan:
    updated.extend(replacement.get(item['phase'], [item]))
assert sum(p['requests'] for p in updated) == original_count
assert abs(sum(p['reserved_usd'] for p in updated) - original_reserve) < 1e-9
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(p['reserved_usd'] for p in updated if p['phase'] not in ledger['batches'])
assert committed <= 2
module.dump('chunk_plan.json', updated)
module.dump('repartition_small_checks.json', {'replaced_unsent_phases': replacement,
    'requests_unchanged': True, 'financial_reserve_unchanged': True,
    'reason': 'Release short corpus mutations and triage disagreement checks into queue slots without waiting for a 1.4-million-input-token phase to fit. No provider jobs cancelled or resubmitted.'})
print(json.dumps({'new_groups': {p: len(v) for p, v in replacement.items()},
                  'planned_requests_excluding_canary': original_count, 'max_committed': committed}))
