import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
requests = []
answers = {r['custom_id']: r for r in json.loads((OUT / 'part4.parsed.json').read_text())}
for c in cases:
    if c['kind'] == 'triage' and c.get('pdf'):
        r = module.request(c, 'none', suffix='scan_none')
        tokens = answers[c['id'] + '-medium-base']['usage']['input_tokens'] + 1024
        r['_input_tokens_preflight'] = tokens
        r['_input_count_exact'] = False
        r['_reserve'] = (tokens * .05 + r['body']['max_output_tokens'] * .25) / 1000000
        requests.append(r)
assert len(requests) == 2
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2
assert 'scan_none' not in {x['phase'] for x in plan}
module.dump('scan_none.requests.json', requests)
plan.insert(0, {'phase': 'scan_none', 'requests': len(requests),
                'input_tokens': sum(r['_input_tokens_preflight'] for r in requests), 'reserved_usd': reserve})
module.dump('chunk_plan.json', plan)
print(json.dumps({'requests': len(requests), 'max_committed': committed + reserve}))
