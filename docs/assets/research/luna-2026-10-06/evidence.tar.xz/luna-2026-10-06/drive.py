import importlib.util
import contextlib
import io
import json
import os
from pathlib import Path
import time

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
plan = json.loads((OUT / 'chunk_plan.json').read_text())
order = [p['phase'] for p in plan]
terminal = ('completed', 'failed', 'expired', 'cancelled')
observed = {}
(OUT / 'driver.pid').write_text(str(os.getpid()))
while True:
    plan = json.loads((OUT / 'chunk_plan.json').read_text())
    order = [p['phase'] for p in plan]
    ledger = json.loads((OUT / 'ledger.json').read_text())
    for phase, record in ledger['batches'].items():
        if record['status'] not in terminal:
            if not record.get('batch_id'):
                raise SystemExit('Uncertain submission; audit without automatic resubmission: ' + phase)
            with contextlib.redirect_stdout(io.StringIO()):
                module.collect(phase)
            state = json.loads((OUT / (phase + '.batch.json')).read_text())
            snapshot = (state['status'], json.dumps(state.get('request_counts'), sort_keys=True))
            if observed.get(phase) != snapshot:
                print(json.dumps({'phase': phase, 'batch_id': state['id'], 'status': state['status'],
                                  'counts': state.get('request_counts')}, ensure_ascii=False), flush=True)
                observed[phase] = snapshot
    ledger = json.loads((OUT / 'ledger.json').read_text())
    unfinished = [phase for phase in order if phase not in ledger['batches'] or ledger['batches'][phase]['status'] != 'completed']
    active = [p for p, b in ledger['batches'].items() if b['status'] not in terminal]
    if not unfinished and not active:
        print('BASELINE_BATCHES_COMPLETE', flush=True)
        break
    for phase in order:
        if phase in ledger['batches'] and ledger['batches'][phase]['status'] in ('failed', 'expired', 'cancelled'):
            raise SystemExit('Non-success terminal batch; inspect before resubmitting: ' + phase)
    queued = 0
    for phase in active:
        requests = json.loads((OUT / (phase + '.requests.json')).read_text())
        state = json.loads((OUT / (phase + '.batch.json')).read_text())
        counts = state.get('request_counts') or {}
        unfinished_count = max(0,len(requests)-counts.get('completed',0)-counts.get('failed',0))
        token_bounds = sorted((r.get('_input_tokens_preflight',10000) for r in requests),reverse=True)
        queued += sum(token_bounds[:unfinished_count])
    for item in plan:
        phase = item['phase']
        if phase not in ledger['batches'] and queued + item['input_tokens'] <= 1980000:
            module.submit(phase)
            queued += item['input_tokens']
            ledger = json.loads((OUT / 'ledger.json').read_text())
    (OUT / 'driver_heartbeat.json').write_text(json.dumps({'at': time.time(), 'queued_upper': queued}))
    time.sleep(45)
