import json
from pathlib import Path

OUT = Path(__file__).parent
path = OUT / 'quality_audit.json'
data = json.loads(path.read_text())
new = [
    {'case': 'analysis-3039-medium-base', 'severity': 'coverage_conditions',
     'field': 'key_changes and practical_impact',
     'source_fact': 'The proposed under-26 entitlement requires collective accommodation before 1 July 2026 followed immediately by daytime school or full-time university education. The answer only says some students under 26 and gives no usable eligibility conditions.',
     'source_excerpt': 'przebywa lub przebywała w obiekcie zbiorowego zakwaterowania przed dniem 1 lipca 2026 r. ... następnie bezpośrednio kontynuuje naukę ... w formie dziennej ... na uczelni w formie stacjonarnej',
     'qualification': 'The answer does not explicitly promise eligibility to every student, so classify as loss of actionable conditions rather than an invented universal entitlement. Its major groups, outside-centre healthcare and 14-day vacatio are source-supported; calibrated answers still require comparison.'},
    {'case': 'analysis-276-medium-base', 'severity': 'passed_checked_details',
     'source_fact': 'Supplied text confirms functional immunity for official acts, the director condition excluding Polish citizens and permanent residents, personal-import privileges for one year, and 14-day vacatio.',
     'qualification': 'This verifies named conditions, not a complete audit of the incorporated UN privileges convention.'},
    {'case': 'analysis-2699-medium-base', 'severity': 'passed_checked_details',
     'source_fact': 'Supplied bill and justification confirm electronic notarial transmission through CREWAN, seven-day existing transmission duty, a fee with amount set by regulation, and three-month vacatio; no new property-permit exemption is asserted.'},
    {'case': 'analysis-825-medium-base', 'severity': 'passed_checked_details',
     'source_fact': 'Supplied normative text confirms the double condition for domestic movable/property-right gifts: neither acquirer nor donor has Polish citizenship or permanent residence/headquarters in Poland. Foreign assets are taxable if the recipient has Polish citizenship or permanent residence. The date belongs to this historical draft, not proof that the proposal became law.'},
    {'case': 'analysis-1962-medium-base and high-base', 'severity': 'passed_checked_details',
     'source_fact': 'Supplied registry clauses explicitly include foreign lawyers, insurance information and suspension status. Both answers restrict the effect to professional registry access rather than general migration or work-permit changes.'},
    {'case': 'corpus-format-only-original-high-and-medium', 'severity': 'stress_false_positive',
     'source_fact': 'Both original efforts mistakenly infer added preparatory-course eligibility where the only old/new difference is one extra space in full 3141 text.',
     'qualification': 'Production diff_laws filters this zero-hunk change before model review. Both change_review_v1 efforts correctly return material=false; do not present the original stress error as a current production repost failure.'},
    {'case': 'max_v2 completed jobs', 'severity': 'configuration_output_exhaustion',
     'source_fact': 'Several real inputs exhaust the 32000-token output budget entirely on reasoning, with no final JSON and incomplete reason max_output_tokens.',
     'qualification': 'This is a genuine unusable response for the tested configuration, not commentary parsing. Test the same frozen prompt at high before selecting a practical configuration; count exhausted reasoning in paid cost.'},
    {'case': 'analysis-new-return_destination-max-max_v2_return_guard', 'severity': 'scoring_regression',
     'source_fact': 'The short controlled norm expressly permits return to Poland for permanent residents. Original medium/high scored legal_stay 5, precision_v1 high scored indirect 2. Frozen v2 gives medium 2, high 5 and max 2 despite all three describing the direction correctly.',
     'qualification': 'Routing/publication scoring can regress during prompt calibration even after the material direction error is repaired. The score expectation was not preregistered in the original control; report this as an exploratory rubric-consistency regression, not blind-test accuracy.'},
]
existing = {f['case'] for f in data['findings']}
data['findings'].extend(f for f in new if f['case'] not in existing)
temporary = path.with_suffix('.tmp')
temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2))
temporary.replace(path)
print(json.dumps({'findings': len(data['findings'])}))
