import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
phase = 'return_guard'
assert not (OUT / (phase + '.requests.json')).exists()
cases = json.loads((OUT / 'cases.json').read_text())
case = next(c for c in cases if c['id'] == 'analysis-new-return_destination')
tail = json.loads((OUT / 'max_v2_prompt.json').read_text())['tail']
requests = [module.request(case, effort, suffix='max_v2_return_guard', extra=tail)
            for effort in ('medium', 'high', 'max')]
api = module.client()
for request in requests:
    body = request['body']
    count = api.responses.input_tokens.count(model=body['model'], input=body['input'], text=body['text'])
    bound = count.input_tokens + 1024
    assert bound < 272000
    body['max_output_tokens'] = 32000
    request['_input_tokens_preflight'] = bound
    request['_input_count_exact'] = False
    request['_input_count_with_safety_margin'] = True
    request['_reserve'] = (bound * .05 + 32000 * .25) / 1000000
plan = json.loads((OUT / 'chunk_plan.json').read_text())
ledger = json.loads((OUT / 'ledger.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(p['reserved_usd'] for p in plan if p['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2
module.dump(phase + '.requests.json', requests)
module.dump('return_guard_protocol.json', {
    'case_id': case['id'], 'expected_publish': True, 'expected_score': 5,
    'source_fact': 'Valid permanent-residence permit explicitly authorizes return to Poland after travel abroad; the text excludes deportation.',
    'purpose': 'Audit a publication regression discovered in precision_v1/high using the already frozen max_v2 prompt at medium/high/max. This is an exploratory regression recheck, not a fresh blind control.',
    'reserved_usd': reserve,
})
module.dump('chunk_plan.json', plan + [{'phase': phase, 'requests': len(requests),
            'input_tokens': sum(r['_input_tokens_preflight'] for r in requests), 'reserved_usd': reserve}])
audit = json.loads((OUT / 'quality_audit.json').read_text())
audit['findings'].append({
    'case': 'analysis-new-return_destination-high-precision_v1',
    'severity': 'publication_regression',
    'source_fact': 'The supplied control explicitly gives holders of valid permanent residence the right to return to Poland after travel. Original medium/high and precision medium score it legal_stay/5; precision high scores it indirect/2 while preserving the facts.',
    'qualification': 'One synthetic control shows prompt calibration can introduce a publication false negative; frozen max_v2 is rechecked at all three reasoning levels. The score was not a preregistered gold field for the original repair holdout.',
})
module.dump('quality_audit.json', audit)
print(json.dumps({'phase': phase, 'requests': len(requests), 'reserve': reserve, 'max_total': committed + reserve}))
