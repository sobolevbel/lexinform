import importlib.util
import json
from pathlib import Path

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import ApplicantType, BillContext

OUT = Path(__file__).parent
assert not (OUT / 'conditions_v3_protocol.json').exists()
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
selected_ids = ['reanalysis-2110', 'reanalysis-2846', 'analysis-1040', 'analysis-3039',
                'analysis-RCL_12398102', 'analysis-maxguard-budget_existing',
                'analysis-maxguard-funding_new_right', 'reanalysis-RCL_12412454']
selected = [c for c in cases if c['id'] in selected_ids]
assert len(selected) == 8
extra = '''

Eligibility completeness check: for every operative provision affecting foreigners, preserve the explicitly stated inclusion and exclusion conditions, citizenship/residence distinctions, required documents and the jurisdictions and lookback periods those documents cover. Put the actionable conditions in key_changes, affected_groups or practical_impact even when space requires removing generic institutional details. Do not replace supplied concrete restrictions with vague phrases such as "under the conditions of the law" or "from the countries prescribed by law". Check temporal qualifiers such as previously, immediately, before a date and the last N years. Check whether another marriage or registered relationship, including one under foreign law, prevents access. Mention only conditions actually established in the supplied text; do not import criminal-record requirements or other conditions from another case. This completeness check changes neither the scoring rubric nor the rule against inferring a version change from silence in an old brief.
Procedure identity check: attach each deadline to exactly the application, decision, notice or document named by the operative clause, including its starting event. An application for authorization/consent is distinct from an application for reimbursement; consent obtained after urgent treatment is not itself a refund application or a guarantee of payment. Do not substitute a broad practical goal for the legally required action. Preserve any urgency condition and territorial scope of an exception.
'''
tail = json.loads((OUT / 'max_v2_prompt.json').read_text())['tail'] + extra
controls = [
    ('consent_and_refund', 'Art. 1. Osoba ubezpieczona w NFZ może uzyskać zwrot kosztów leczenia w innym państwie UE, jeżeli uzyska zgodę NFZ. W przypadku pilnego leczenia niezbędnego dla ratowania życia wniosek o wydanie zgody można złożyć po leczeniu, w terminie 18 dni od dnia zakończenia leczenia. Odrębny wniosek o zwrot kosztów składa się w terminie 40 dni od dnia zapłaty faktury. Żaden z wniosków nie daje automatycznego prawa do wypłaty.',
     {'required_conditions': ['insured by NFZ', 'another EU state', 'urgent life-saving treatment exception', 'consent application within eighteen days of treatment ending', 'separate refund application within forty days of paying invoice', 'no automatic payment entitlement'], 'forbidden_inference': ['refund application within eighteen days']}),
    ('lookback_five', 'Art. 1. Wolontariusz niebędący obywatelem państwa UE, dopuszczany do pracy z dziećmi, przedstawia informacje z rejestru karnego państwa obywatelstwa i państw zamieszkania w ciągu ostatnich 5 lat. Dokumentów z Polski nie wymaga się. Ustawa wchodzi w życie po 30 dniach od ogłoszenia.',
     {'required_conditions': ['non-EU volunteers working with children', 'citizenship state and residence states', 'last five years', 'Poland excluded'], 'forbidden_inference': ['ten-year lookback']}),
    ('foreign_relationship', 'Art. 1. Dwie pełnoletnie osoby mogą zawrzeć umowę wspólnego pożycia u notariusza w Polsce. Nie może jej zawrzeć osoba pozostająca w małżeństwie ani w zarejestrowanym związku zawartym według prawa innego państwa, nawet jeżeli związek nie jest w Polsce uznawany za małżeństwo. Umowa nie daje prawa pobytu.',
     {'required_conditions': ['foreign-law registered union excludes access even if not recognized as marriage', 'no residence entitlement']}),
    ('no_criminal_record', 'Art. 1. Cudzoziemiec posiadający pobyt stały i wychowujący dziecko do ukończenia 12 lat uzyskuje prawo do świadczenia 50 zł miesięcznie. Do wniosku załącza kopię ważnego paszportu. Art. 2. Cudzoziemiec przebywający wyłącznie na wizie turystycznej nie jest uprawniony. Ustawa nie określa żadnych innych warunków ani dokumentów.',
     {'score': 3, 'publish': True, 'required_conditions': ['permanent residence', 'child under twelve', 'passport copy', 'tourist-visa-only excluded'], 'forbidden_inference': ['criminal record', 'residence history', 'five-year or ten-year lookback']}),
]
new = []
for name, text, gold in controls:
    ctx = BillContext(number='V3-' + name, title='Projekt kontrolny', description=None,
                      document_date=None, applicant_type=ApplicantType.GOVERNMENT,
                      text=text, truncated=False, text_source='pdf')
    new.append({'id': 'analysis-v3guard-' + name, 'number': ctx.number, 'kind': 'analysis',
                'split': 'heldout', 'source': 'new_conditions_v3_guard',
                'system': prompts.gpt51_system_prompt('ru'), 'user': prompts.build_user_prompt(ctx),
                'context': ctx.model_dump(mode='json'), 'gold': gold})
original_bounds = {}
for item in json.loads((OUT / 'max_v2_plan.json').read_text()):
    for request in json.loads((OUT / (item['phase'] + '.requests.json')).read_text()):
        original_bounds[request['_case_id']] = request['_input_tokens_preflight']
requests = []
for case in selected + new:
    request = module.request(case, 'high', suffix='conditions_v3', extra=tail)
    request['body']['max_output_tokens'] = 16000
    if case in selected:
        bound = original_bounds[case['id']] + len(extra.encode())
    else:
        bound = len(json.dumps(request['body'], ensure_ascii=False).encode()) + 4096
    request['_input_tokens_preflight'] = bound
    request['_input_count_exact'] = False
    request['_input_count_bound_note'] = 'Existing model token count plus safety margin and extra-tail UTF8 bytes, or full request UTF8 bytes plus safety margin for a new control.'
    long = bound > 272000
    request['_reserve'] = (bound * (.1 if long else .05) + 16000 * (.375 if long else .25)) / 1e6
    requests.append(request)
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(x['reserved_usd'] for x in plan if x['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2
groups = []
group = []
size = 0
for request in sorted(requests, key=lambda r: (r['_input_tokens_preflight'], r['custom_id'])):
    amount = request['_input_tokens_preflight']
    if group and size + amount > 70000:
        groups.append(group)
        group = []
        size = 0
    group.append(request)
    size += amount
if group:
    groups.append(group)
added = []
for index, group in enumerate(groups):
    phase = f'conditionsv3_{index + 1}'
    assert phase not in ledger['batches']
    module.dump(phase + '.requests.json', group)
    added.append({'phase': phase, 'requests': len(group),
                  'input_tokens': sum(r['_input_tokens_preflight'] for r in group),
                  'reserved_usd': sum(r['_reserve'] for r in group)})
module.dump('conditions_v3_protocol.json', {
    'tail': tail, 'added_completeness_check': extra, 'effort': 'high', 'max_output_tokens': 16000,
    'reason': 'High-v2 partly repairs 2110 and 2846 but still omits actionable conditions. Its RCL12412454 answer restores course eligibility but mislabels the 30-day retrospective consent application as a refund application. Test generic completeness and procedure-identity checks without embedding real expected numbers. The earlier unsubmitted draft was archived; no v3 answer informed this extension.',
    'selected_case_ids': selected_ids, 'new_guard_ids': [c['id'] for c in new],
    'evaluation_type': 'Three targeted exploratory repairs plus five known passing/score checks and four fresh focused guards, fixed before their answers; not a new random blind sample or validation of v3 across all real cases.',
    'requests': len(requests), 'reserved_usd': reserve, 'max_total_usd': committed + reserve,
})
module.dump('cases.json', cases + new)
module.dump('chunk_plan.json', plan + added)
print(json.dumps({'requests': len(requests), 'fresh_controls': len(new),
                  'reserved_usd': reserve, 'max_total_usd': committed + reserve}))
