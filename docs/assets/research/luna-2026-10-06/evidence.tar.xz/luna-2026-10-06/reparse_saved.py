import importlib.util
import json
from pathlib import Path

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
summary = []
for path in OUT.glob('*.results.jsonl'):
    phase = path.name.removesuffix('.results.jsonl')
    parsed_path = OUT / (phase + '.parsed.json')
    if not parsed_path.exists():
        continue
    parsed = {r['custom_id']:r for r in json.loads(parsed_path.read_text())}
    comments = 0
    repaired = 0
    for line in path.read_text().splitlines():
        raw = json.loads(line)
        body = (raw.get('response') or {}).get('body') or {}
        messages = [x for x in body.get('output', []) if x.get('type') == 'message']
        final = [x for x in messages if x.get('phase') == 'final_answer']
        if not final:
            final = [x for x in messages if x.get('phase') is None]
        text = ''.join(c.get('text','') for m in final for c in m.get('content',[]) if c.get('type')=='output_text')
        row = parsed[raw['custom_id']]
        previous_invalid = row['answer'] is None
        kind = raw['custom_id'].split('-')[0]
        comments += any(m.get('phase')=='commentary' for m in messages)
        row['commentary_messages'] = sum(m.get('phase')=='commentary' for m in messages)
        try:
            if len(final)!=1:
                raise ValueError('Expected exactly one final assistant message')
            row['answer'] = module.MODELS[kind].model_validate_json(text).model_dump(mode='json')
            row['validation_error'] = None
            repaired += previous_invalid
        except (ValueError,KeyError) as exc:
            row['answer'] = None
            row['validation_error'] = str(exc)[:500]
    module.dump(phase + '.parsed.json',list(parsed.values()))
    summary.append({'phase':phase,'commentary_responses':comments,'parser_false_errors_fixed':repaired,
                    'remaining_invalid':sum(r['answer'] is None for r in parsed.values())})
module.dump('parser_adjustment.json',summary)
print(json.dumps(summary))
