from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
from pathlib import Path

from lexinform.adapters import llm_prompts as prompts
from lexinform.law_diff import diff_laws
from lexinform.models import ChangeContext, ChangedPassage

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert not (OUT / 'production_review_plan.json').exists()
cases = json.loads((OUT / 'cases.json').read_text())
tail = json.loads((OUT / 'change_review_v1_prompt.json').read_text())['tail']
new = []
requests = []
preparation_audit = []
for original in [c for c in cases if c['source'] == 'controlled_corpus_mutation']:
    ctx = original['context']
    diff = diff_laws(ctx['old_law'], ctx['new_law'])
    assert diff is not None
    eligible = bool(diff.hunks) and diff.ratio <= .15 and diff.chars <= 60000
    preparation_audit.append({'case_id': original['id'], 'prepared_old_chars': len(diff.old_law),
        'hunks': len(diff.hunks), 'diff_chars': diff.chars, 'ratio': diff.ratio,
        'review_eligible_with_current_defaults': eligible})
    if not eligible:
        continue
    context = ChangeContext(number=ctx['number'], title=ctx['title'], summary=ctx['summary'],
        key_changes=ctx['key_changes'],
        passages=[ChangedPassage(old=h.old, new=h.new, before=h.before, after=h.after) for h in diff.hunks],
        changed_words=diff.changed_words, total_words=diff.total_words,
        old_law=diff.old_law, new_law=diff.new_law)
    case = {'id': original['id'].replace('corpus-', 'prepared-'), 'number': original['number'],
        'kind': 'change_review', 'split': 'heldout', 'source': 'controlled_corpus_production_prepared',
        'system': prompts.change_review_system_prompt('ru'), 'user': prompts.build_change_review_prompt(context),
        'context': context.model_dump(mode='json'), 'gold': original['gold'],
        'source_case_id': original['id'], 'qualification': 'Controlled edit, using exact production diff_laws act bodies/hunks and current review eligibility limits; not an actual historical event.'}
    assert case['id'] not in {c['id'] for c in cases}
    new.append(case)
    for effort in ('medium', 'high'):
        requests.append(module.request(case, effort, suffix='production_base'))
        requests.append(module.request(case, effort, suffix='production_change_review_v1', extra=tail))
assert len(new) == 2
api = module.client()

def count(request):
    body = request['body']
    result = api.responses.input_tokens.count(model=body['model'], input=body['input'], text=body['text'])
    return request['custom_id'], result.input_tokens

with ThreadPoolExecutor(max_workers=4) as pool:
    counts = dict(pool.map(count, requests))
for request in requests:
    bound = counts[request['custom_id']] + 1024
    assert bound <= 272000
    request['_input_tokens_preflight'] = bound
    request['_input_count_exact'] = False
    request['_input_count_with_safety_margin'] = True
    request['_reserve'] = (bound * .05 + request['body']['max_output_tokens'] * .25) / 1000000
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
committed = sum(b.get('actual_usd', b['reserved_usd']) for b in ledger['batches'].values())
committed += sum(p['reserved_usd'] for p in plan if p['phase'] not in ledger['batches'])
reserve = sum(r['_reserve'] for r in requests)
assert committed + reserve <= 2
phase = 'production_review'
module.dump(phase + '.requests.json', requests)
item = {'phase': phase, 'requests': len(requests), 'input_tokens': sum(r['_input_tokens_preflight'] for r in requests), 'reserved_usd': reserve}
module.dump('production_review_plan.json', [item])
module.dump('corpus_review_preparation_audit.json', {'cases': preparation_audit,
    'scope': 'Original raw full-corpus requests include justification and are stress tests. Current production prepares normative bodies, filters zero-hunk spacing edits and bypasses LLM review above 60000 combined characters. Production-shaped follow-up requests preserve the actual eligible call path.'})
module.dump('cases.json', cases + new)
module.dump('chunk_plan.json', plan + [item])
audit = json.loads((OUT / 'quality_audit.json').read_text())
audit['findings'].append({'case': 'corpus-review-production-scope', 'severity': 'applicability_limit',
    'source_fact': 'diff_laws prepares 2353-character normative bodies for 1040, with one hunk for the date and OR/AND edits. For 3141 it prepares 38666 characters; whitespace has zero hunks, and the insurance-negation pair exceeds the 60000-character review cap. The whitespace error cannot trigger an actual production LLM review on this mutation.',
    'qualification': 'Raw full-context tests remain useful stress evidence but do not establish current production-path failure. Eight follow-up generations compare original and calibrated prompts on the exact eligible production-prepared 1040 contexts.'})
module.dump('quality_audit.json', audit)
print(json.dumps({'new_cases': len(new), 'requests': len(requests), 'reserved_usd': reserve, 'max_total': committed + reserve}))
