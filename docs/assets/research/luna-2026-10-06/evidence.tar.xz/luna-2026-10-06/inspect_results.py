import argparse
import collections
import json
from pathlib import Path
import re

OUT = Path(__file__).parent


def inspect(phase: str, split: str) -> None:
    cases = {x['id']: x for x in json.loads((OUT / 'cases.json').read_text())}
    requests = {x['custom_id']: x for x in json.loads((OUT / (phase + '.requests.json')).read_text())}
    rows = json.loads((OUT / (phase + '.parsed.json')).read_text())
    filtered = [(r, cases[requests[r['custom_id']]['_case_id']]) for r in rows
                if split == 'all' or cases[requests[r['custom_id']]['_case_id']]['split'] == split]
    metrics = collections.defaultdict(lambda: collections.Counter())
    issues = []
    for row, case in filtered:
        effort = requests[row['custom_id']]['body']['reasoning']['effort']
        key = case['kind'] + '/' + effort
        metric = metrics[key]
        metric['requests'] += 1
        metric['usd'] += row['usd']
        usage = row['usage']
        metric['input_tokens'] += usage.get('input_tokens', 0)
        metric['output_tokens'] += usage.get('output_tokens', 0)
        metric['reasoning_tokens'] += (usage.get('output_tokens_details') or {}).get('reasoning_tokens', 0)
        answer = row['answer']
        if not answer or row['status'] != 'completed':
            metric['invalid'] += 1
            issues.append({'id': row['custom_id'], 'issue': 'invalid', 'error': row['error'],
                           'incomplete': row['incomplete_details'], 'validation': row['validation_error']})
            continue
        metric['valid'] += 1
        if 'gold' in case:
            metric['gold_controls'] += 1
            gold = case['gold']
            fails = []
            for field in ('material', 'affects_foreigners', 'supports', 'same_substance'):
                if field in gold and answer.get(field) != gold[field]:
                    fails.append(field)
            if 'publish' in gold and (answer['relevant'] and answer['score'] >= 3) != gold['publish']:
                fails.append('publication_gate')
            if 'score' in gold and answer.get('score') != gold['score']:
                fails.append('score')
            if 'names_changes' in gold and bool(answer['changes_since_previous']) != gold['names_changes']:
                fails.append('names_changes')
            if fails:
                metric['gold_fail'] += 1
                issues.append({'id': row['custom_id'], 'issue': 'control_failed', 'fields': fails,
                               'gold': gold, 'answer': answer, 'split': case['split']})
        if case.get('metadata_gold') and answer['effective_date'] is not None:
            metric['metadata_date_hallucination'] += 1
            issues.append({'id': row['custom_id'], 'issue': 'metadata_date_hallucination', 'answer': answer})
        if case['kind'] == 'triage' and case.get('reference'):
            reference = case['reference']
            reject = not answer['affects_foreigners'] and answer['confidence'] >= .8
            ref_reject = not reference['affects'] and reference['confidence'] >= .8
            metric['reference_count'] += 1
            metric['rejects'] += reject
            metric['reference_gate_agreement'] += reject == ref_reject
            if reject and not ref_reject:
                metric['potential_miss'] += 1
                issues.append({'id': row['custom_id'], 'issue': 'potential_triage_miss',
                               'reference': reference, 'answer': answer, 'split': case['split']})
            elif not reject and ref_reject:
                metric['extra_full_analysis'] += 1
                issues.append({'id': row['custom_id'], 'issue': 'extra_full_analysis',
                               'reference': reference, 'answer': answer, 'split': case['split']})
        if case['kind'] in ('analysis', 'reanalysis') and case.get('baseline'):
            baseline = case['baseline']['answer']
            metric['baseline_count'] += 1
            pub = answer['relevant'] and answer['score'] >= 3
            prior_pub = baseline['relevant'] and baseline['score'] >= 3
            metric['relevance_agreement'] += answer['relevant'] == baseline['relevant']
            metric['publication_agreement'] += pub == prior_pub
            metric['score_agreement'] += answer['score'] == baseline['score']
            if pub != prior_pub or answer['relevant'] != baseline['relevant']:
                issues.append({'id': row['custom_id'], 'issue': 'analysis_gate_difference',
                               'baseline': baseline, 'answer': answer, 'split': case['split']})
        if case['kind'] in ('analysis', 'reanalysis'):
            metric['summary_over_350'] += len(answer['summary']) > 350
            metric['bullets_over_120'] += sum(len(b) > 120 for b in answer['key_changes'])
            if not case.get('previous_reconstructed') and not case.get('context', {}).get('previous_summary'):
                metric['spurious_revision_changes'] += bool(answer['changes_since_previous'])
    print(json.dumps({'phase': phase, 'split': split, 'metrics': dict(metrics), 'issues': issues},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('phase', default='phase1', nargs='?')
    p.add_argument('--split', choices=['all', 'calibration', 'heldout'], default='calibration')
    a = p.parse_args()
    inspect(a.phase, a.split)
