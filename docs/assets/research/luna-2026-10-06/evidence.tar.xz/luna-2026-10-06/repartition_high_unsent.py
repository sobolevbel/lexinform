import json
from pathlib import Path

OUT = Path(__file__).parent
assert not (OUT / 'high_unsent_repartition.json').exists()
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
old = [x for x in plan if x['phase'].startswith('highv2_') and x['phase'] not in ledger['batches']]
requests = [r for x in old for r in json.loads((OUT / (x['phase'] + '.requests.json')).read_text())]
assert len(requests) == 45
groups = []
group = []
size = 0
for request in sorted(requests, key=lambda r: (r['_input_tokens_preflight'], r['custom_id'])):
    amount = request['_input_tokens_preflight']
    if group and size + amount > 70000:
        groups.append(group)
        group = []
        size = 0
    group.append(request)
    size += amount
if group:
    groups.append(group)
added = []
for index, group in enumerate(groups):
    phase = f'highv2_small_{index + 1}'
    assert phase not in ledger['batches']
    (OUT / (phase + '.requests.json')).write_text(json.dumps(group, ensure_ascii=False, indent=2))
    added.append({'phase': phase, 'requests': len(group),
                  'input_tokens': sum(r['_input_tokens_preflight'] for r in group),
                  'reserved_usd': sum(r['_reserve'] for r in group)})
assert sum(x['requests'] for x in old) == sum(x['requests'] for x in added)
assert abs(sum(x['reserved_usd'] for x in old) - sum(x['reserved_usd'] for x in added)) < 1e-10
names = {x['phase'] for x in old}
new_plan = [x for x in plan if x['phase'] not in names] + added
temporary = OUT / 'chunk_plan.tmp'
temporary.write_text(json.dumps(new_plan, indent=2))
temporary.replace(OUT / 'chunk_plan.json')
record = {'reason': 'Smaller unsent groups allow short cases to fit the 2M queued-input account limit sooner. Every payload and reserve is preserved; no provider job was cancelled.',
          'old_unsent_groups': old, 'new_groups': added, 'requests': len(requests)}
(OUT / 'high_unsent_repartition.json').write_text(json.dumps(record, indent=2))
print(json.dumps({'requests_preserved': len(requests), 'old_groups': len(old), 'new_groups': len(added)}))
