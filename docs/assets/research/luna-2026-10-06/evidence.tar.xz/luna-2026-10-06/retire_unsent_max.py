import json
from pathlib import Path

OUT = Path(__file__).parent
assert not (OUT / 'retired_unsent_max.json').exists()
ledger = json.loads((OUT / 'ledger.json').read_text())
plan = json.loads((OUT / 'chunk_plan.json').read_text())
retired = [x for x in plan if x['phase'].startswith('maxv2_') and x['phase'] not in ledger['batches']]
assert len(retired) == 5
record = {
    'reason': 'Seven completed max-v2 responses exhausted the 32k output cap with no final answer. Do not send five more large inputs under that impractical configuration. Preserve all 46 contexts in the high-v2 rerun using the identical frozen prompt.',
    'provider_jobs_cancelled': 0,
    'retired_unsubmitted_only': retired,
    'released_reserve_usd': sum(x['reserved_usd'] for x in retired),
}
temporary = OUT / 'retired_unsent_max.tmp'
temporary.write_text(json.dumps(record, indent=2))
temporary.replace(OUT / 'retired_unsent_max.json')
names = {x['phase'] for x in retired}
temporary = OUT / 'chunk_plan.tmp'
temporary.write_text(json.dumps([x for x in plan if x['phase'] not in names], indent=2))
temporary.replace(OUT / 'chunk_plan.json')
print(json.dumps({'retired_requests': sum(x['requests'] for x in retired),
                  'released_reserve_usd': record['released_reserve_usd']}))
