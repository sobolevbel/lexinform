import gzip
import importlib.util
import json
from pathlib import Path
import sqlite3
import subprocess

from lexinform.adapters import llm_prompts as prompts
from lexinform.models import BillContext, ApplicantType, SupplementContext

OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('luna_eval', OUT / 'eval.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = json.loads((OUT / 'cases.json').read_text())
requests = json.loads((OUT / 'phase1.requests.json').read_text())
db = sqlite3.connect(':memory:')
db.row_factory = sqlite3.Row
db.executescript(subprocess.run(['git', 'show', 'origin/state:lexinform.sql'], cwd=module.ROOT,
                              check=True, capture_output=True, text=True).stdout)


def add(case):
    assert case['id'] not in {c['id'] for c in cases}
    cases.append(case)
    requests.append(module.request(case, 'medium'))


for row in db.execute("select number,title,wykaz_json,analysis_json from bills where number in ('WPL/UD368','WPL/UD338')"):
    plan = json.loads(row['wykaz_json'])
    description = '\n'.join(str(plan.get(k, '')) for k in ['goals', 'essence'])
    ctx = BillContext(number=row['number'], title=row['title'], description=description,
                      document_date=None, applicant_type=ApplicantType.GOVERNMENT,
                      text='', truncated=False, text_source='metadata_only')
    add({'id': 'analysis-' + row['number'].replace('/', '_'), 'number': row['number'],
         'kind': 'analysis', 'split': module.split(row['number']), 'source': 'real_register_metadata',
         'system': prompts.gpt51_system_prompt('ru'), 'user': prompts.build_user_prompt(ctx),
         'context': ctx.model_dump(mode='json'), 'metadata_gold': {'effective_date': None}})

for name, text, previous in [
    ('changed', 'Art. 1. Pobyt obywateli Ukrainy uznaje się za legalny do dnia 30 września 2027 r. Art. 2. Ustawa wchodzi w życie po upływie 14 dni od dnia ogłoszenia.',
     'Легальное пребывание украинцев продлевается до 30 июня 2027 г. Вступление в силу через 14 дней после опубликования.'),
    ('unchanged', 'Art. 1. Pobyt obywateli Ukrainy uznaje się za legalny do dnia 30 czerwca 2027 r. Art. 2. Ustawa wchodzi w życie po upływie 14 dni od dnia ogłoszenia.',
     'Легальное пребывание украинцев продлевается до 30 июня 2027 г. Вступление в силу через 14 дней после опубликования.'),
]:
    ctx = BillContext(number='CONTROL-revision', title='Pomoc obywatelom Ukrainy', description=None,
                      document_date=None, applicant_type=ApplicantType.GOVERNMENT,
                      text=text, truncated=False, text_source='pdf', previous_summary=previous)
    add({'id': 'reanalysis-control-' + name, 'number': 'control-revision-' + name,
         'kind': 'reanalysis', 'split': module.split('control-revision-' + name),
         'source': 'synthetic_control', 'system': prompts.gpt51_system_prompt('ru'),
         'user': prompts.build_user_prompt(ctx), 'context': ctx.model_dump(mode='json'),
         'gold': {'publish': True, 'names_changes': name == 'changed'}, 'previous_reconstructed': True})

record = json.loads((module.CORPUS / 'sejm/term10/supplements/records/1319-001.json').read_text())
with gzip.open(module.CORPUS / 'sejm/term10/supplements/text/1319-001.txt.gz', 'rt', errors='replace') as handle:
    text = handle.read()
print_record = json.loads((module.CORPUS / 'sejm/term10/prints/1319.json').read_text())
bill = db.execute("select analysis_json from bills where number='1319'").fetchone()
previous = json.loads(bill['analysis_json'])['analysis'] if bill and bill['analysis_json'] else None
ctx = SupplementContext(number='1319', title=print_record['title'], document_title=record['title'],
                        source_kind='impact_assessment', text=text, truncated=False,
                        previous_summary=previous['summary'] if previous else print_record['title'],
                        previous_key_changes=previous['key_changes'] if previous else [])
add({'id': 'supplement-real-1319', 'number': '1319', 'kind': 'supplement',
     'split': module.split('1319'), 'source': 'real_supplement',
     'system': prompts.gpt51_supplement_system_prompt('ru'), 'user': prompts.build_supplement_prompt(ctx),
     'context': ctx.model_dump(mode='json'), 'gold': {'supports': None}})

reserve = sum(r['_reserve'] for r in requests)
canary = json.loads((OUT / 'canary.requests.json').read_text())
assert reserve + sum(r['_reserve'] for r in canary) <= 2
module.dump('cases.json', cases)
module.dump('phase1.requests.json', requests)
manifest = json.loads((OUT / 'manifest.json').read_text())
manifest.update(case_count=len(cases), request_count=len(requests), phase1_reserved=reserve)
module.dump('manifest.json', manifest)
print({'cases': len(cases), 'requests': len(requests), 'phase1_reserve': reserve,
       'all_reserved': reserve + sum(r['_reserve'] for r in canary)})
