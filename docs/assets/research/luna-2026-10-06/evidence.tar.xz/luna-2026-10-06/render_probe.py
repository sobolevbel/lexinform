import datetime as dt
import html
import json
from pathlib import Path

from lexinform.adapters.telegram_format import MessageFormatter, length
from lexinform.models import Analysis, AnalysisRecord, Bill, BillStatus, ProcessSummary

OUT = Path(__file__).parent
NOW = dt.datetime(2026, 10, 6, tzinfo=dt.UTC)
cases = {c['id']: c for c in json.loads((OUT / 'cases.json').read_text())}
rows = json.loads((OUT / 'all_answers.json').read_text())
formatter = MessageFormatter(today=lambda: NOW.date())
results = []
for row in rows:
    if row['kind'] not in ('analysis', 'reanalysis') or not row['answer']:
        continue
    case = cases[row['case_id']]
    context = case.get('context', {})
    if not context.get('number'):
        continue
    answer = Analysis.model_validate(row['answer'])
    bill = Bill(
        summary=ProcessSummary(
            term=10, number=context['number'], title=context['title'],
            document_type='projekt ustawy', change_date=NOW,
        ),
        status=BillStatus.ANALYZED, first_seen_at=NOW, last_checked_at=NOW,
        analysis=AnalysisRecord(
            analysis=answer, model='gpt-6-luna', prompt_version='research',
            input_chars=case.get('chars', 0), truncated=False,
            text_source=context.get('text_source', 'pdf'), created_at=NOW,
        ),
    )
    card = formatter.new_bill(bill, None, today=NOW.date()).text
    visible = html.unescape(card)
    results.append({
        'custom_id': row['custom_id'], 'case_id': row['case_id'],
        'telegram_length': length(card),
        'summary_retained': answer.summary.strip() in visible,
        'key_changes_retained': all(s.strip() in visible for s in answer.key_changes),
        'practical_impact_retained': answer.practical_impact.strip() in visible,
        'affected_groups_retained': all(s.strip() in visible for s in answer.affected_groups),
        'effective_date_retained': not answer.effective_date or answer.effective_date.strip() in visible,
    })
data = {
    'scope': 'Offline card rendering using actual production formatter and minimal bill metadata. No Telegram sends, no real stages/consultation/RCL metadata, no update-card rendering, no semantic quality proof.',
    'results': results,
}
(OUT / 'render_probe.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
issues = [r for r in results if r['telegram_length'] > 4096 or not all(
    r[k] for k in ('summary_retained', 'key_changes_retained', 'practical_impact_retained',
                   'affected_groups_retained', 'effective_date_retained')
)]
print(json.dumps({'cards': len(results), 'issues': issues}, ensure_ascii=False))
