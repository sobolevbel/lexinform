from collections import defaultdict
import json
from pathlib import Path

OUT = Path(__file__).parent
cases = {c['id']: c for c in json.loads((OUT / 'cases.json').read_text())}
rows = json.loads((OUT / 'all_answers.json').read_text())
groups = defaultdict(list)
for row in rows:
    baseline = cases[row['case_id']].get('baseline')
    if (not baseline or row['kind'] not in ('analysis', 'reanalysis')
            or baseline['model'] not in ('claude-opus-5-5', 'gpt-5.1-2025-11-13')):
        continue
    if row['phase'].startswith('metadatav1_'):
        suffix = row['custom_id'].rsplit('-metadata_', 1)[1]
        configuration = 'corrected_metadata_' + suffix + '/' + row['effort']
    elif row['phase'].startswith('highv2_'):
        configuration = 'high_v2/high'
    elif row['phase'].startswith('conditionsv3_'):
        configuration = 'conditions_v3/high'
    elif row['phase'].startswith('maxv2_'):
        configuration = 'max_v2/max'
    elif row['custom_id'].endswith('-medium-base'):
        configuration = 'original/medium'
    else:
        continue
    groups[(configuration, baseline['model'])].append((row, baseline))
result = []
for (configuration, model), group in sorted(groups.items()):
    rates = (2., 10.) if model == 'claude-opus-5-5' else (.625, 5.)
    baseline_cost = sum(((b['input_tokens'] + (b.get('cache_read_input_tokens') or 0)
                          + (b.get('cache_creation_input_tokens') or 0)) * rates[0]
                         + b['output_tokens'] * rates[1]) / 1e6 for r, b in group)
    read_rate = .1 if model == 'claude-opus-5-5' else .0625
    cached_cost = sum((b['input_tokens'] * rates[0] + b['output_tokens'] * rates[1]
                       + (b.get('cache_read_input_tokens') or 0) * read_rate
                       + (b.get('cache_creation_input_tokens') or 0) * rates[0] * 1.25)
                      / 1e6 for r, b in group)
    luna_cost = sum(r['usd'] for r, b in group)
    result.append({
        'configuration': configuration, 'historical_model': model,
        'matched_contexts': len(group), 'usable_final_answers': sum(r['answer'] is not None for r, b in group),
        'historic_usage_at_current_cold_batch_usd': baseline_cost,
        'historic_usage_repriced_with_observed_cache_usd': cached_cost,
        'historical_cache_write_assumption': '5-minute writes; TTL is not persisted in these token records',
        'historical_uncached_input_tokens': sum(b['input_tokens'] for r, b in group),
        'historical_cache_read_tokens': sum(b.get('cache_read_input_tokens') or 0 for r, b in group),
        'historical_cache_write_tokens': sum(b.get('cache_creation_input_tokens') or 0 for r, b in group),
        'luna_actual_batch_usd': luna_cost,
        'ratio_historical_to_luna': baseline_cost / luna_cost if luna_cost else None,
        'ratio_observed_cache_historical_to_luna': cached_cost / luna_cost if luna_cost else None,
        'luna_input_tokens': sum(r['usage'].get('input_tokens', 0) for r, b in group),
        'luna_output_including_reasoning': sum(r['usage'].get('output_tokens', 0) for r, b in group),
        'luna_reasoning_tokens': sum((r['usage'].get('output_tokens_details') or {}).get('reasoning_tokens', 0) for r, b in group),
    })
data = {'comparison': result,
        'scope': 'Historical disjoint uncached/read/write token usage repriced both as fully cold input and with observed cache categories at current Batch rates, against measured Luna usage. Metadata, tokenizer, prompts and outputs can differ. Failed/no-final requests are included in cost and reported separately; price savings do not establish quality equivalence. Luna has no measured cache benefit.',
        'monthly_pipeline_roi_not_established': True}
temporary = OUT / 'configuration_costs.tmp'
temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2))
temporary.replace(OUT / 'configuration_costs.json')
print(json.dumps({'comparisons': len(result)}))
