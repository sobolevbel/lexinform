from __future__ import annotations

import html
import re
from pathlib import Path

import pymupdf
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import CondPageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

ROOT = Path('/Users/sobaleu/projects/lexinform')
SOURCE = ROOT / 'docs/reviews/2026-10-27-terra-evaluation.md'
TARGET = ROOT / 'out/2026-10-27-terra-evaluation.pdf'
PREVIEW = Path(__file__).parent / 'pdf-preview'
pdfmetrics.registerFont(TTFont('Arial', '/System/Library/Fonts/Supplemental/Arial.ttf'))
pdfmetrics.registerFont(TTFont('ArialBold', '/System/Library/Fonts/Supplemental/Arial Bold.ttf'))
pdfmetrics.registerFontFamily('Arial', normal='Arial', bold='ArialBold', italic='Arial', boldItalic='ArialBold')
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyRu', fontName='Arial', fontSize=9.8, leading=13.8,
                          spaceAfter=7, textColor=colors.HexColor('#1e293b')))
styles.add(ParagraphStyle(name='TitleRu', parent=styles['BodyRu'], fontName='ArialBold',
                          fontSize=19, leading=24, spaceAfter=15, keepWithNext=True))
styles.add(ParagraphStyle(name='HeadingRu', parent=styles['BodyRu'], fontName='ArialBold',
                          fontSize=13, leading=17, spaceBefore=14, spaceAfter=8, keepWithNext=False))
styles.add(ParagraphStyle(name='SubheadingRu', parent=styles['BodyRu'], fontName='ArialBold',
                          fontSize=10.8, leading=14, spaceBefore=10, spaceAfter=6, keepWithNext=True))
styles.add(ParagraphStyle(name='CellRu', fontName='Arial', fontSize=8.2, leading=11.4,
                          textColor=colors.HexColor('#1e293b'), alignment=TA_LEFT))
styles.add(ParagraphStyle(name='HeadCellRu', parent=styles['CellRu'], fontName='ArialBold',
                          textColor=colors.HexColor('#ffffff')))


def inline(value: str) -> str:
    value = html.escape(value.replace('\u2011', '-'))
    value = re.sub(r'\[([^\]]+)\]\(([^)]+)\)',
                   lambda m: f'<link href="{m[2]}" color="#1d4ed8">{m[1]}</link>' if m[2].startswith('https://') else m[1], value)
    value = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', value)
    value = re.sub(r'`([^`]+)`', r'<font color="#334155">\1</font>', value)
    return value


def footer(canvas, document) -> None:
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor('#cbd5e1'))
    canvas.line(43, 36, A4[0] - 43, 36)
    canvas.setFont('Arial', 8)
    canvas.setFillColor(colors.HexColor('#64748b'))
    canvas.drawString(43, 23, 'Lexinform · GPT-6.1 Terra · 27.10.2026')
    canvas.drawRightString(A4[0] - 43, 23, str(document.page))
    canvas.restoreState()


story = []
lines = SOURCE.read_text().splitlines()
i = 0
width = A4[0] - 86
while i < len(lines):
    line = lines[i].strip()
    if not line:
        i += 1
        continue
    if line.startswith('|'):
        table_rows = []
        while i < len(lines) and lines[i].strip().startswith('|'):
            cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r'[:\- ]+', c) for c in cells):
                table_rows.append(cells)
            i += 1
        columns = len(table_rows[0])
        fractions = {2: [.60, .40], 3: [.22, .25, .53], 4: [.24, .36, .20, .20]}.get(columns, [1 / columns] * columns)
        data = [[Paragraph(inline(c), styles['HeadCellRu'] if j == 0 else styles['CellRu']) for c in row] for j, row in enumerate(table_rows)]
        table = Table(data, colWidths=[width * f for f in fractions], repeatRows=1, hAlign='LEFT')
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0f4c5c')),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('LEFTPADDING', (0, 0), (-1, -1), 7),
            ('RIGHTPADDING', (0, 0), (-1, -1), 7),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#f1f5f9'), colors.white]),
            ('LINEBELOW', (0, 0), (-1, -1), .3, colors.HexColor('#cbd5e1')),
        ]))
        story.extend([table, Spacer(1, 9)])
        continue
    if line.startswith('# '):
        story.append(Paragraph(inline(line[2:]), styles['TitleRu']))
        i += 1
        continue
    if line.startswith('## '):
        story.append(CondPageBreak(125))
        story.append(Paragraph(inline(line[3:]), styles['HeadingRu']))
        i += 1
        continue
    if line.startswith('### '):
        story.append(Paragraph(inline(line[4:]), styles['SubheadingRu']))
        i += 1
        continue
    paragraph = [line]
    i += 1
    while i < len(lines) and lines[i].strip() and not lines[i].lstrip().startswith(('#', '|')):
        paragraph.append(lines[i].strip())
        i += 1
    story.append(Paragraph(inline(' '.join(paragraph)), styles['BodyRu']))

TARGET.parent.mkdir(exist_ok=True)
doc = SimpleDocTemplate(str(TARGET), pagesize=A4, rightMargin=43, leftMargin=43,
                        topMargin=39, bottomMargin=48, title='GPT-6.1 Terra для Lexinform: корпусный тест',
                        author='Lexinform', pageCompression=1)
doc.build(story, onFirstPage=footer, onLaterPages=footer)
PREVIEW.mkdir(exist_ok=True)
pdf = pymupdf.open(TARGET)
for index, page in enumerate(pdf):
    page.get_pixmap(matrix=pymupdf.Matrix(1.25, 1.25)).save(PREVIEW / f'page-{index+1:02}.png')
print('PDF', TARGET, 'pages', len(pdf), 'bytes', TARGET.stat().st_size)
