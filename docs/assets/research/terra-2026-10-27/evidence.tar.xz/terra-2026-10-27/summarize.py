from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from bs4 import BeautifulSoup

from lexinform.adapters.telegram_format import MessageFormatter, length
from lexinform.models import Analysis, AnalysisRecord, Bill, BillStatus, ProcessSummary

OUT = Path(__file__).parent / 'evidence'
cases = {c['id']: c for c in json.loads((OUT / 'cases.json').read_text())}
rows = json.loads((OUT / 'answers.json').read_text())
ledger = json.loads((OUT / 'ledger.json').read_text())
superseded = {c['supersedes_case_id'] for c in cases.values() if c.get('supersedes_case_id')}
base = [r for r in rows if r['custom_id'] == r['case_id'] + '-terra-medium' and r['case_id'] not in superseded]
real_sources = {'saved_batch_text', 'corpus_full_text', 'metadata_corrected_corpus_full_text',
                'metadata_corrected_saved_batch_text', 'exploratory_triage_disagreement_full_text',
                'real_full_scan', 'real_register_metadata', 'real_joint_descriptions',
                'real_supplement', 'real_committee_amendments', 'corpus_not_in_luna'}
by_model: dict[str, dict[str, Any]] = {}
for model in sorted({r['model'] for r in rows}):
    subset = [r for r in rows if r['model'] == model]
    by_model[model] = {
        'requests': len(subset), 'valid': sum(r['answer'] is not None for r in subset),
        'usd': sum(r['usd'] for r in subset),
        'input_tokens': sum(r['usage'].get('input_tokens', 0) for r in subset),
        'output_tokens': sum(r['usage'].get('output_tokens', 0) for r in subset),
        'reasoning_tokens': sum(r['usage'].get('output_tokens_details', {}).get('reasoning_tokens', 0) for r in subset),
        'cached_tokens': sum(r['usage'].get('input_tokens_details', {}).get('cached_tokens', 0) for r in subset),
        'cache_write_tokens': sum(r['usage'].get('input_tokens_details', {}).get('cache_write_tokens', 0) for r in subset),
    }
pairs = []
for gpt in [r for r in rows if r['model'] == 'gpt-5.1']:
    terra = next(r for r in rows if r['custom_id'] == gpt['case_id'] + '-terra-medium')
    pairs.append({'case_id': gpt['case_id'], 'gpt_usd': gpt['usd'], 'terra_usd': terra['usd'],
                  'gpt_input': gpt['usage']['input_tokens'], 'terra_input': terra['usage']['input_tokens'],
                  'gpt_output': gpt['usage']['output_tokens'], 'terra_output': terra['usage']['output_tokens'],
                  'gpt_score': gpt['answer']['score'] if gpt['answer'] else None,
                  'terra_score': terra['answer']['score'] if terra['answer'] else None})
historical = []
for r in base:
    c = cases[r['case_id']]
    b = c.get('baseline')
    if not b or not b.get('answer'):
        continue
    rate_in, rate_out, rate_cache = (2, 10, .1) if b['model'].startswith('claude') else (.625, 5, .0625)
    usd = (b['input_tokens'] * rate_in + b['output_tokens'] * rate_out + b.get('cache_read_input_tokens', 0) * rate_cache) / 1e6
    historical.append({'case_id': r['case_id'], 'old_model': b['model'], 'old_usd': usd,
                       'terra_usd': r['usd'], 'old_input': b['input_tokens'], 'terra_input': r['usage']['input_tokens'],
                       'old_score': b['answer']['score'], 'terra_score': r['answer']['score']})
controls = []
for r in base:
    c = cases[r['case_id']]
    a = r['answer']
    gold = c.get('gold') or c.get('metadata_gold') or {}
    checks = {}
    for key, value in gold.items():
        if key in a:
            checks[key] = a[key] == value
    if 'names_changes' in gold:
        checks['names_changes'] = bool(a.get('changes_since_previous')) == gold['names_changes']
    if 'publish' in gold:
        checks['publish'] = bool(a.get('relevant') and a.get('score', 0) >= 3) == gold['publish']
    if checks:
        controls.append({'case_id': r['case_id'], 'checks': checks, 'all_pass': all(checks.values())})
summary = {
    'total_requests': len(rows), 'actual_usd': sum(b.get('actual_usd', 0) for b in ledger['batches'].values()),
    'pending_reserve': sum(b['reserved_usd'] for b in ledger['batches'].values() if 'actual_usd' not in b),
    'terminal_batches': sum(b['status'] in ('completed', 'failed', 'expired', 'cancelled') for b in ledger['batches'].values()),
    'batch_count': len(ledger['batches']), 'by_model': by_model,
    'base_requests_excluding_superseded_metadata': len(base),
    'base_roles': dict(Counter(cases[r['case_id']]['kind'] for r in base)),
    'base_real_contexts': sum(cases[r['case_id']]['source'] in real_sources for r in base),
    'base_real_entities': len({cases[r['case_id']]['number'] for r in base if cases[r['case_id']]['source'] in real_sources}),
    'base_sources': dict(Counter(cases[r['case_id']]['source'] for r in base)),
    'fresh_pairs': pairs, 'historical_pairs': historical, 'control_checks': controls,
    'limitations': 'Formal controls, selected source review and finite selected contexts do not establish global legal accuracy; metadata repeats and effort/prompt variants are not independent bills.',
}
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
formatter = MessageFormatter(today=lambda: dt.date(2026, 10, 27))
now = dt.datetime(2026, 10, 27, tzinfo=dt.UTC)
render = []
def normalize(s: str) -> str:
    return re.sub(r'\s+', ' ', s).strip()
for r in rows:
    c = cases[r['case_id']]
    ctx = c.get('context')
    if not ctx or not r['answer'] or c['kind'] not in ('analysis', 'reanalysis'):
        continue
    a = Analysis.model_validate(r['answer'])
    bill = Bill(summary=ProcessSummary(term=10, number=ctx['number'], title=ctx['title'],
                document_type='projekt ustawy', change_date=now), status=BillStatus.ANALYZED,
                first_seen_at=now, last_checked_at=now, analysis=AnalysisRecord(analysis=a,
                model=r['model'], prompt_version='research', input_chars=c.get('chars', 0),
                truncated=ctx.get('truncated', False), text_source=ctx.get('text_source', 'pdf'), created_at=now))
    text = formatter.new_bill(bill, None, today=now.date()).text
    parts = formatter.message_parts(text)
    visible = normalize(BeautifulSoup('\n'.join(parts), 'html.parser').get_text(' '))
    required = [a.practical_impact, *a.key_changes, *a.affected_groups]
    if a.effective_date:
        required.append(a.effective_date)
    if not a.practical_impact.strip():
        required.append(a.summary)
    render.append({'custom_id': r['custom_id'], 'telegram_length': length(text),
                   'physical_parts': len(parts), 'part_lengths': [length(part) for part in parts],
                   'missing_visible_fields': [s for s in required if normalize(s) not in visible]})
(OUT / 'render-probe.json').write_text(json.dumps({
    'scope': 'Actual new_bill formatter and message_parts splitting with minimal metadata; summary intentionally hidden when practical_impact exists. No real stages, consultation state or update rendering. No sends.',
    'results': render,
}, ensure_ascii=False, indent=2))
print(json.dumps({k: v for k, v in summary.items() if k not in ('historical_pairs', 'control_checks', 'base_sources')}, ensure_ascii=False, indent=2))
print('rendered', len(render), 'issues', sum(bool(r['missing_visible_fields']) or max(r['part_lengths']) > 4096 for r in render), 'multipart', sum(r['physical_parts'] > 1 for r in render))
