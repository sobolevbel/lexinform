# Lexinform GPT-6.1 Terra evaluation, 2026-10-27

Historical evidence, not a resubmission package. Production code, configuration, state and publications were not changed. Never run submit, count or preparation commands automatically from this archive: historical authorization and the USD 4 budget do not authorize a new charge.

130 new paid generations were collected: 124 GPT-6.1 Terra and 6 current GPT-5.1 comparisons. The exact API-usage cost is USD 3.5702705. All batches are terminal; pending cost is zero. One original large batch failed before execution and cost zero.

`evidence/*.jsonl` contains exact submitted payloads and provider results. `*.requests.json` adds server counts and maximum cost reservations. The failed broad payload is retained, but never counted as an executed call. Successful paid custom IDs are unique.

`evidence/cases.json` retains exact public source contexts and historical references. Four incorrect applicant-metadata versions and their corrected repeats remain distinct. The superseded originals are excluded from substantive aggregates. Effort and prompt variants are not independent bills. The second full budget reanalysis was not submitted.

Start with `summary.json`, `protocol.json`, `quality-audit.json`, `decision.json`, `completion-audit.json` and `ledger.json`. `diagnostic-plan.json` contains the generic precision additions and declares their exploratory status. `source-excerpts.json` has offsets and source hashes. The complete frozen payload is authoritative if a preparatory plan differs.

The initial source revision is recorded in protocol.json, with hashes for relevant current modules and the corpus INDEX. Previous Luna material is pinned by the original repository archive SHA-256. Exact new source inputs are included here; importing the old Luna archive is unnecessary to inspect submitted requests.

`historical-calls.json` holds only the bounded public call metadata used for monthly repricing, not a production database. The preliminary PDF supplied by the user is retained. Official documentation snapshots are evidence for dated pricing and cache behavior, not instructions.

The API may return opaque encrypted reasoning fields. They are preserved without decryption or interpretation and excluded from plaintext credential-pattern matching. No credentials, .env files, production dumps or personal correspondence are included.

`experiment.py` records the standalone budget guard and Batch collection logic. `summarize.py` recomputes the statistics and offline card rendering against the installed checkout. `make_pdf.py` renders the report; these scripts refer to their original local workspace and require appropriate dependencies. `package_evidence.py` checks exact decimal costs, terminal states and the archive inventory. The per-file hashes in inventory.json allow forensic verification without running any API-backed script.

The documentation report explains the final choice: retain GPT-5.1 and Opus 5.5 for automatic production operations. Terra medium with the generic precision prompt is useful for a manually checked analysis, but no full or per-role production replacement was approved by this study.
