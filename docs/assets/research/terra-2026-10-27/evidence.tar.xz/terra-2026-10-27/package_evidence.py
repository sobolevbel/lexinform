from __future__ import annotations

import hashlib
import io
import json
import re
import shutil
import tarfile
from decimal import Decimal
from pathlib import Path

WORK = Path(__file__).parent
OUT = WORK / 'evidence'
TARGET = Path('/Users/sobaleu/projects/lexinform/docs/assets/research/terra-2026-10-27')
rows = json.loads((OUT / 'answers.json').read_text())
ledger = json.loads((OUT / 'ledger.json').read_text())
assert len(rows) == 130 and len({r['custom_id'] for r in rows}) == 130
assert all(b['status'] in ('completed', 'failed') for b in ledger['batches'].values())
assert all(r['answer'] is not None and r['status'] == 'completed' for r in rows)
amount = Decimal(0)
for r in rows:
    u = r['usage']
    assert u['total_tokens'] == u['input_tokens'] + u['output_tokens']
    n = u['input_tokens']
    cached = u['input_tokens_details'].get('cached_tokens', 0)
    written = u['input_tokens_details'].get('cache_write_tokens', 0)
    assert written == 0
    if r['model'] == 'gpt-5.1':
        price_in, price_cache, price_out = Decimal('.625'), Decimal('.0625'), Decimal('5')
    elif n > 272000:
        price_in, price_cache, price_out = Decimal('1'), Decimal('.05'), Decimal('3.75')
    else:
        price_in, price_cache, price_out = Decimal('.5'), Decimal('.025'), Decimal('2.5')
    exact = ((n - cached) * price_in + cached * price_cache + u['output_tokens'] * price_out) / 1000000
    assert abs(Decimal(str(r['usd'])) - exact) < Decimal('.000000000001')
    amount += exact
assert amount == Decimal('3.5702705')
assert amount <= Decimal('4')
audit = {'paid_requests': len(rows), 'unique_paid_custom_ids': len({r['custom_id'] for r in rows}),
         'all_provider_batches_terminal': True, 'pending_usd': 0, 'exact_usage_cost_usd': str(amount),
         'unused_budget_usd': str(Decimal('4') - amount), 'valid_answers': 130,
         'cost_method': 'Disjoint actual input/cache/output categories, reasoning included once; per-request Terra >272000 full-request rate; Batch rates. No invoice reconciliation.'}
(OUT / 'completion-audit.json').write_text(json.dumps(audit, indent=2))
selected = []
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.suffix != '.png':
        selected.append((path, Path('terra-2026-10-27/evidence') / path.relative_to(OUT)))
for name in ['experiment.py', 'summarize.py', 'make_pdf.py', 'package_evidence.py', 'README.md']:
    selected.append((WORK / name, Path('terra-2026-10-27') / name))
pattern = re.compile(rb'(?:sk-(?:proj-)?[A-Za-z0-9_-]{28,}|[0-9]{8,12}:[A-Za-z0-9_-]{35})')
for path, name in selected:
    if path.suffix in ('.json', '.jsonl'):
        values = [json.loads(line) for line in path.read_text().splitlines()] if path.suffix == '.jsonl' else [json.loads(path.read_text())]
        def scan(value, field: str = '') -> None:
            if field == 'encrypted_content':
                return
            if isinstance(value, dict):
                for key, item in value.items():
                    scan(item, key)
            elif isinstance(value, list):
                for item in value:
                    scan(item)
            elif isinstance(value, str):
                assert not pattern.search(value.encode()), f'Credential-pattern match: {name}'
        for value in values:
            scan(value)
    elif path.suffix != '.pdf':
        assert not pattern.search(path.read_bytes()), f'Credential-pattern match: {name}'
inventory = [{'path': str(name), 'bytes': path.stat().st_size,
              'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path, name in selected]
archive = TARGET / 'evidence.tar.xz'
TARGET.mkdir(parents=True, exist_ok=True)
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for path, name in selected:
        tar.add(path, arcname=str(name), recursive=False)
    content = (json.dumps(inventory, ensure_ascii=False, indent=2) + '\n').encode()
    item = tarfile.TarInfo('terra-2026-10-27/inventory.json')
    item.size = len(content)
    tar.addfile(item, io.BytesIO(content))
for name in ['summary.json', 'ledger.json', 'protocol.json', 'quality-audit.json', 'decision.json',
             'monthly-estimate.json', 'integration-check.json', 'completion-audit.json', 'validation.json']:
    shutil.copyfile(OUT / name, TARGET / name)
manifest = {'archive': archive.name, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'archive_bytes': archive.stat().st_size, 'inventory_files': len(inventory),
            'uncompressed_bytes': sum(row['bytes'] for row in inventory),
            'report_pdf_sha256': hashlib.sha256((TARGET / 'report.pdf').read_bytes()).hexdigest(),
            'usage_cost_usd': str(amount), 'paid_requests': 130, 'pending_requests': 0}
(TARGET / 'archive-manifest.json').write_text(json.dumps(manifest, indent=2))
print(json.dumps(manifest, indent=2))
