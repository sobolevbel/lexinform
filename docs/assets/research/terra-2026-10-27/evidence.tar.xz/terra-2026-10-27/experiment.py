from __future__ import annotations

import argparse
import base64
import copy
import gzip
import hashlib
import json
import math
import sqlite3
import subprocess
from pathlib import Path
from typing import Any

from openai import OpenAI
from openai.lib._pydantic import to_strict_json_schema

from lexinform.adapters import llm_prompts as prompts
from lexinform.concurrency import fan_out
from lexinform.models import Analysis, Amendments, BillContext, ChangeReview, DocumentDigest
from lexinform.models import JointComparison, Triage
from lexinform.sections import trim_print
from lexinform.settings import Settings

ROOT = Path('/Users/sobaleu/projects/lexinform')
OUT = Path(__file__).parent / 'evidence'
OLD = Path(__file__).parent / 'luna-2026-10-06'
BUDGET = 4.0
MODELS = {'analysis': Analysis, 'reanalysis': Analysis, 'amendments': Amendments,
          'supplement': DocumentDigest, 'joint': JointComparison, 'change_review': ChangeReview,
          'triage': Triage}


def dump(name: str, value: Any) -> None:
    OUT.mkdir(exist_ok=True)
    target = OUT / name
    tmp = target.with_suffix(target.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2))
    tmp.replace(target)


def api() -> OpenAI:
    return OpenAI(api_key=Settings().openai_api_key, max_retries=0, timeout=90)


def prepare() -> None:
    if (OUT / 'cases.json').exists():
        raise SystemExit('Frozen cases already exist')
    old = json.loads((OLD / 'cases.json').read_text())
    corrections = {c['original_case_id']: c for c in old if c.get('original_case_id')}
    selected = []
    for c in old:
        if c.get('original_case_id') or c['kind'] == 'triage':
            continue
        c = copy.deepcopy(corrections.get(c['id'], c))
        if c.get('original_case_id'):
            c['id'] = c.pop('original_case_id')
        kind = c['kind']
        system = {'analysis': prompts.gpt51_system_prompt, 'reanalysis': prompts.gpt51_system_prompt,
                  'amendments': prompts.gpt51_amendments_system_prompt,
                  'supplement': prompts.gpt51_supplement_system_prompt,
                  'joint': prompts.gpt51_joint_system_prompt,
                  'change_review': prompts.change_review_system_prompt}[kind]
        c['system'] = system('ru')
        if kind in ('analysis', 'reanalysis') and c.get('context'):
            c['user'] = prompts.build_user_prompt(BillContext.model_validate(c['context']))
        selected.append(c)
    corpus = ROOT.parent / 'lexinform-corpus'
    for number in ['3156', '3135', '3126']:
        meta = json.loads((corpus / 'sejm/term10/prints' / f'{number}.json').read_text())
        with gzip.open(corpus / 'sejm/term10/text' / f'{number}.txt.gz', 'rt') as h:
            text = trim_print(h.read()).text
        ctx = BillContext(number=number, title=meta['title'], description=meta.get('description'),
                          document_date=meta.get('documentDate'), applicant_type='deputies',
                          text=text, truncated=False, text_source='pdf')
        selected.append({'id': 'analysis-fresh-' + number, 'number': number, 'kind': 'analysis',
                         'source': 'corpus_not_in_luna', 'context': ctx.model_dump(mode='json'),
                         'chars': len(text), 'system': prompts.gpt51_system_prompt('ru'),
                         'user': prompts.build_user_prompt(ctx)})
    dump('cases.json', selected)
    dump('protocol.json', {
        'date': '2026-10-27', 'budget_usd': BUDGET, 'target': 'gpt-6.1-terra',
        'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'corpus_index_sha256': hashlib.sha256((corpus / 'INDEX.json').read_bytes()).hexdigest(),
        'old_archive_sha256': hashlib.sha256((ROOT / 'docs/assets/research/luna-2026-10-06/evidence.tar.xz').read_bytes()).hexdigest(),
        'prompt_version': prompts.PROMPT_VERSION,
        'selection': 'All non-triage Luna contexts, corrected metadata preferred; three additional corpus prints. Budget-constrained stages fixed separately before each submission.',
        'quality': 'No confirmed material loss of conditions, groups, amounts, dates, negation or procedure; source text adjudicates disagreements. Historical models are not gold.',
        'baseline': 'Historical 19 Opus and 5 GPT records; selected new identical-prompt GPT-5.1 comparisons within the same total budget.',
        'config': 'Current production prompts, medium effort and 8000 cap for full analysis; 4000 secondary cap. No prompt calibration before broad results.',
        'cache': 'Explicit without breakpoints, cold generation; no automatic cache writes.',
        'accounting': 'Before submit reserve server-counted input plus max(1024, 2%) and full capped output; long tier applied to whole request. Unknown submissions never retried.',
        'limitations': ['Selected risk corpus, not random sample or legal certification.', 'Repeated versions are not independent bills.', 'Some historical reanalysis contexts lack previous full texts.', 'Historical and fresh comparison strata reported separately.'],
    })
    print('prepared',len(selected),'cases',flush=True)


def make_requests() -> None:
    cases = json.loads((OUT / 'cases.json').read_text())
    requests = []
    for c in cases:
        content: Any = c['user']
        if c.get('pdf'):
            content = [{'type': 'input_file', 'filename': 'corpus-scan.pdf',
                        'file_data': 'data:application/pdf;base64,' + c['pdf']},
                       {'type': 'input_text', 'text': c['user']}]
        body = {'model': 'gpt-6.1-terra', 'reasoning': {'effort': 'medium'},
                'max_output_tokens': 8000 if c['kind'] in ('analysis', 'reanalysis') else 4000,
                'prompt_cache_options': {'mode': 'explicit'},
                'input': [{'role': 'system', 'content': c['system']}, {'role': 'user', 'content': content}],
                'text': {'format': {'type': 'json_schema', 'name': c['kind'], 'strict': True,
                                    'schema': to_strict_json_schema(MODELS[c['kind']])}}}
        requests.append({'custom_id': c['id'] + '-terra-medium', 'method': 'POST',
                         'url': '/v1/responses', 'body': body, '_case_id': c['id']})
    client = api()
    def count(r: dict[str, Any]) -> int:
        body = r['body']
        return client.responses.input_tokens.count(model=body['model'], input=body['input'],
            reasoning=body['reasoning'], text=body['text']).input_tokens
    done = []
    for outcome in fan_out(requests, count, workers=4):
        r = outcome.item
        n = outcome.result()
        bound = n + max(1024, math.ceil(n * .02))
        long = bound > 272000
        r['_count'] = n
        r['_bound'] = bound
        r['_reserve'] = (bound * (1 if long else .5) + r['body']['max_output_tokens'] * (3.75 if long else 2.5)) / 1e6
        done.append(r)
        dump('requests.json', done)
        print(r['custom_id'], n, round(r['_reserve'],6),flush=True)
    print('all reserved',sum(r['_reserve'] for r in done),flush=True)


def submit(phase: str, ids: list[str]) -> None:
    ledger = json.loads((OUT / 'ledger.json').read_text()) if (OUT / 'ledger.json').exists() else {'budget_usd': BUDGET, 'batches': {}}
    if phase in ledger['batches']:
        raise SystemExit('Existing submission intent: never automatically retry')
    candidates = json.loads((OUT / 'requests.json').read_text())
    chosen = [r for r in candidates if r['custom_id'] in ids or r['_case_id'] in ids]
    if len(chosen) != len(set(ids)):
        raise SystemExit('Selection must match exact request ids')
    committed = sum(b.get('actual_usd',b['reserved_usd']) for b in ledger['batches'].values())
    reserve = sum(r['_reserve'] for r in chosen)
    if committed + reserve > BUDGET - .015:
        raise SystemExit(f'Budget reservation rejected: {committed + reserve}')
    dump(phase + '.requests.json', chosen)
    target = OUT / (phase + '.jsonl')
    target.write_text('\n'.join(json.dumps({k:v for k,v in r.items() if not k.startswith('_')},ensure_ascii=False) for r in chosen) + '\n')
    ledger['batches'][phase] = {'reserved_usd':reserve,'request_count':len(chosen),'status':'uploading'}
    dump('ledger.json',ledger)
    client = api()
    with target.open('rb') as h:
        uploaded = client.files.create(file=h,purpose='batch')
    ledger['batches'][phase].update(file_id=uploaded.id,status='submitting_uncertain')
    dump('ledger.json',ledger)
    batch = client.batches.create(input_file_id=uploaded.id,endpoint='/v1/responses',completion_window='24h',metadata={'experiment':'lexinform-terra-20261027','phase':phase,'budget_usd':'4'})
    ledger['batches'][phase].update(batch_id=batch.id,status=batch.status)
    dump('ledger.json',ledger)
    dump(phase + '.batch.json',batch.model_dump(mode='json'))
    print(json.dumps({'phase':phase,'status':batch.status,'requests':len(chosen),'reserve':reserve,'total_max':committed+reserve}),flush=True)


def collect() -> None:
    ledger = json.loads((OUT / 'ledger.json').read_text())
    client = api()
    all_rows = []
    for phase,record in ledger['batches'].items():
        if record['status'] in ('completed','failed','expired','cancelled') and 'actual_usd' in record:
            parsed = OUT / (phase + '.parsed.json')
            if parsed.exists():
                all_rows.extend(json.loads(parsed.read_text()))
            print(phase,record['status'],record.get('actual_usd'),flush=True)
            continue
        batch = client.batches.retrieve(record['batch_id'])
        record['status'] = batch.status
        dump(phase + '.batch.json', batch.model_dump(mode='json'))
        if batch.output_file_id:
            target = OUT / (phase + '.results.jsonl')
            if not target.exists():
                target.write_text(client.files.content(batch.output_file_id).text)
        if batch.error_file_id:
            target = OUT / (phase + '.errors.jsonl')
            if not target.exists():
                target.write_text(client.files.content(batch.error_file_id).text)
        if batch.status in ('completed','failed','expired','cancelled'):
            requests = {r['custom_id']:r for r in json.loads((OUT / (phase + '.requests.json')).read_text())}
            rows=[]
            path=OUT / (phase + '.results.jsonl')
            for line in path.read_text().splitlines() if path.exists() else []:
                raw=json.loads(line); response=raw.get('response') or {}; body=response.get('body') or {}
                usage=body.get('usage') or {}; n=usage.get('input_tokens',0); details=usage.get('input_tokens_details') or {}
                read=details.get('cached_tokens',0); write=details.get('cache_write_tokens',0)
                model=requests[raw['custom_id']]['body']['model']
                rates=(1,.05,1.25,3.75) if n>272000 else (.5,.025,.625,2.5)
                if model.startswith('gpt-5.1'):
                    rates=(.625,.0625,.625,5)
                usd=((n-read-write)*rates[0]+read*rates[1]+write*rates[2]+usage.get('output_tokens',0)*rates[3])/1e6
                texts=[p.get('text','') for m in body.get('output',[]) if m.get('type')=='message' and m.get('phase') in (None,'final_answer') for p in m.get('content',[]) if p.get('type')=='output_text']
                case_id=requests[raw['custom_id']]['_case_id']; kind=case_id.split('-')[0]
                answer=None; error=None
                try:
                    answer=MODELS[kind].model_validate_json(''.join(texts)).model_dump(mode='json')
                except (ValueError,KeyError) as e:
                    error=str(e)[:400]
                rows.append({'custom_id':raw['custom_id'],'case_id':case_id,'model':model,'status':body.get('status'),
                             'http_status':response.get('status_code'),'answer':answer,'validation_error':error,'usage':usage,
                             'usd':usd,'error':raw.get('error') or body.get('error'),'incomplete_details':body.get('incomplete_details')})
            record['actual_usd']=sum(r['usd'] for r in rows)
            dump(phase + '.parsed.json',rows)
            all_rows.extend(rows)
        print(phase,batch.status,batch.request_counts.model_dump() if batch.request_counts else None,record.get('actual_usd'),[x.code for x in batch.errors.data] if batch.errors else None,flush=True)
    dump('ledger.json',ledger)
    dump('answers.json',all_rows)
    print('committed',sum(b.get('actual_usd',b['reserved_usd']) for b in ledger['batches'].values()),flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['prepare','count','submit','collect'])
    parser.add_argument('phase',nargs='?')
    parser.add_argument('ids',nargs='*')
    args=parser.parse_args()
    if args.action=='prepare': prepare()
    elif args.action=='count': make_requests()
    elif args.action=='submit': submit(args.phase,args.ids)
    else: collect()
