import hashlib,json
from pathlib import Path
from lexinform.adapters.doc_text import DocTextExtractor
from lexinform.adapters.document_text import DocumentTextExtractor,DocxTextExtractor
from lexinform.adapters.pdf_text import PypdfTextExtractor
out=Path('/private/tmp/lexinform-evidence-study-lqlelnih');r=Path('/Users/sobaleu/projects/lexinform-corpus')
index=json.loads((r/'documents/index.json').read_bytes());inventory=json.loads((out/'residual-inventory.json').read_bytes())
extractor=DocumentTextExtractor(PypdfTextExtractor(),DocxTextExtractor(),DocTextExtractor())
rows=[]
for case in inventory['groups']:
 if case['category']!='different_header_dates_parser_gap':continue
 for doc in case['documents']:
  rec=index[doc['id']];p=r/f"documents/files/{doc['id']}.{rec['extension']}"
  if not p.exists():rows.append({'id':doc['id'],'state':'raw missing'});continue
  data=p.read_bytes();body=extractor.extract(data)
  rows.append({'project':case['project'],'id':doc['id'],'raw_sha256':hashlib.sha256(data).hexdigest(),'source':rec['url'],'cached_observed_date':doc['header'],'raw_opening':body[:500],'raw_chars':len(body)})
(out/'raw-parser-gaps.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'documents':len(rows),'projects':len({x.get('project') for x in rows}),'readable':sum(x.get('raw_chars',0)>0 for x in rows)}))
