import copy,gzip,hashlib,json
from pathlib import Path
root=Path('/Users/sobaleu/projects/lexinform-corpus')
old=root/'sejm/supplements/2026-10-17-document-selection-validation'
out=Path('/private/tmp/lexinform-evidence-study-lqlelnih')
index=json.loads((root/'documents/index.json').read_bytes())
manifest={};cases=[]
def text(identity):
 p=root/f'documents/text/{identity}.txt.gz'; t=gzip.decompress(p.read_bytes()).decode()
 rec=index[str(identity)]; raw=root/f"documents/files/{identity}.{rec['extension']}"
 manifest[str(identity)]={'cached_text_sha256':hashlib.sha256(t.encode()).hexdigest(),'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest() if raw.exists() else None,'record':rec}
 return t

def filetext(name):
 p=old/name;t=p.read_text();manifest[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};return t

def candidate(identity,body,project,name='source.dat',blocks=None):
 if blocks is None:
  parts=body.split('\f')
  if len(parts)>1 and len(parts[0])<2000:
   blocks=[{'id':f'{identity}.p1','text':parts[0][:1800]},{'id':f'{identity}.p2','text':parts[1][:1800]}]
  else: blocks=[{'id':f'{identity}.head','text':body[:2000]}]
 return {'id':identity,'official_project':project,'name':name,'coverage':'excerpts_only','blocks':blocks}

def add(group,task,docs,chosen,facts,decisions=None,mutation='none'):
 c={'id':f'c{len(cases)//2:02d}-base','group':group,'variant':'base','mutation':mutation,'question':{'task':task,'official_project':group,'question':'Prefer the supplied main bill body' if task=='bill_role' else 'Prefer the latest internally dated bill draft from this official project; abstain if ordering is unproven','candidates':docs,'coverage':'Excerpts only. Never certify full-document equivalence or completeness.'},'expected':{'decisions':decisions or ['prefer'],'preferred_ids':chosen,'facts':facts}}
 cases.append(c)
 v=copy.deepcopy(c);v['id']=c['id'].replace('base','reverse-rename');v['variant']='reverse_rename';v['question']['candidates'].reverse()
 for i,d in enumerate(v['question']['candidates']): d['name']='NOWY_TEKST_USTAWY.docx' if i==0 else 'ARCHIWALNA_OPINIA.pdf'
 cases.append(v)

pairs=[(12294950,280566,'2017-03-20',272563,'2017-02-02'),(12337613,468921,'2020-09-25',469056,'2020-09-29'),(12341906,509184,'2021-05-17',509152,'2021-04-28'),(12346354,643081,'2022-05-13',643072,'2022-04-12'),(12349301,575888,'2022-04-05',575911,'2022-08-23'),(12350557,524047,'2021-09-27',524052,'2021-09-29'),(12350601,636766,'2023-08-04',636772,'2023-08-08'),(12353800,567539,'2022-06-30',567533,'2022-06-21')]
for project,a,ad,b,bd in pairs:
 add(str(project),'latest_draft',[candidate('A',text(a),str(project)),candidate('B',text(b),str(project))],['A' if ad>bd else 'B'],{'A':{'role':['bill'],'draft_date':ad},'B':{'role':['bill'],'draft_date':bd}})
add('12321775','bill_role',[candidate('A',filetext('text-418603.txt'),'12321775'),candidate('B',filetext('text-418609.txt'),'12321775')],['A'],{'A':{'role':['bill'],'draft_date':'2019-09-04'},'B':{'role':['regulation'],'draft_date':'2019-09-05'}})
add('12400754','bill_role',[candidate('A',filetext('text-730985.txt'),'12400754'),candidate('B',text(730984),'12400754')],['A'],{'A':{'role':['bill'],'draft_date':'2025-08-01'},'B':{'role':['osr']}})
add('VIII/275','bill_role',[candidate('A',filetext('8-275-1.opening.txt'),'VIII/275'),candidate('B',filetext('8-275-2.opening.txt'),'VIII/275')],['B'],{'A':{'role':['regulation'],'draft_date':'unknown'},'B':{'role':['bill'],'draft_date':'unknown'}})
# The budget control uses the previously downloaded six-page staffing annex.
from lexinform.adapters.pdf_text import PypdfTextExtractor
p=Path('/Users/sobaleu/projects/lexinform/docs/assets/audits/2026-10-17-document-selection/8-2864-selected.pdf')
annex=PypdfTextExtractor().extract(p.read_bytes());manifest['budget-staffing']={'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
add('VIII/2864','bill_role',[candidate('A',annex,'VIII/2864'),candidate('B',filetext('8-2864-0.opening.txt'),'VIII/2864')],['B'],{'A':{'role':['annex'],'draft_date':'unknown'},'B':{'role':['bill'],'draft_date':'unknown'}})
a=text(468921);b=text(469056)
a=a[a.index('\n')+1:];b=b[b.index('\n')+1:]
add('12337613','latest_draft',[candidate('A',a,'12337613'),candidate('B',b,'12337613')],[],{'A':{'role':['bill'],'draft_date':'unknown'},'B':{'role':['bill'],'draft_date':'unknown'}},['ambiguous','need_more'],'remove_draft_dates')
add('12333806','latest_draft',[candidate('A',text(447874),'12333806'),candidate('B',text(447875),'12333806')],[],{'A':{'role':['bill'],'draft_date':'2020-05-14'},'B':{'role':['bill'],'draft_date':'2020-05-14'}},['ambiguous','need_more'])
add('12321775','latest_draft',[candidate('A',filetext('text-418603.txt'),'12321775'),candidate('B',filetext('text-730985.txt'),'12400754')],['A'],{'A':{'role':['bill'],'draft_date':'2019-09-04'},'B':{'role':['bill'],'draft_date':'2025-08-01'}},mutation='foreign_candidate')
cover_a=filetext('8-275-1.opening.txt').split('\f')[0];cover_b=filetext('8-275-2.opening.txt').split('\f')[0]
add('VIII/275','bill_role',[candidate('A',cover_a,'VIII/275'),candidate('B',cover_b,'VIII/275')],[],{'A':{'role':['letter','unknown'],'draft_date':'unknown'},'B':{'role':['letter','unknown'],'draft_date':'unknown'}},['need_more','ambiguous'],'cover_only')
(out/'cases.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
(out/'source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'requests_per_model':len(cases),'groups':len({c['group'] for c in cases}),'base_scenarios':len(cases)//2,'independent_new_version_groups':8}))
