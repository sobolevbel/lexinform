import gzip,hashlib,html,io,json,zipfile
from pathlib import Path
from lexinform.adapters.doc_text import DocTextExtractor
from lexinform.adapters.document_text import DocumentTextExtractor,DocxTextExtractor
from lexinform.adapters.pdf_text import PypdfTextExtractor
from lexinform.models import TextDocument
from lexinform.services.documents import TextLoader
r=Path('/Users/sobaleu/projects/lexinform-corpus')
def package(members):
 b=io.BytesIO()
 with zipfile.ZipFile(b,'w') as z:
  for n,d in members:z.writestr(n,d)
 return b.getvalue()
def word(t):
 paras=''.join('<w:p><w:r><w:t>'+html.escape(line)+'</w:t></w:r></w:p>' for line in t.splitlines())
 return package([('word/document.xml',('<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'+paras+'</w:body></w:document>').encode())])
new=word(gzip.decompress((r/'documents/text/280566.txt.gz').read_bytes()).decode())
old=word(gzip.decompress((r/'documents/text/272563.txt.gz').read_bytes()).decode())
extractor=DocumentTextExtractor(PypdfTextExtractor(),DocxTextExtractor(),DocTextExtractor())
files={'https://source.test/new.docx':new,'https://source.test/old.docx':old}
def download(url,*,max_bytes=None):return files[url]
loader=TextLoader({'source.test':download},extractor,max_bytes=32000000)
doc=TextDocument(url='https://source.test/new.docx',kind='rcl',compare_versions=True,version_basis=('rcl/12294950',),alternatives=(TextDocument(url='https://source.test/old.docx',kind='rcl'),))
chosen,loaded=loader.select_document(doc)
combined=extractor.extract_document(package([('A.docx',new),('B.docx',old)]))
result={'source_ids':[280566,272563],'separate':{'url':chosen.url,'state':loaded.selection.state,'chars':len(loaded.text or '')},'zip':{'state':combined.selection.state,'chars':len(combined.text),'parts':[{'role':p.role,'members':p.members} for p in combined.selection.parts]},'note':'Controlled repackaging of real cached texts into minimal Word documents, not original-byte equivalence.'}
Path('/private/tmp/lexinform-evidence-study-lqlelnih/container-invariance-committed.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
