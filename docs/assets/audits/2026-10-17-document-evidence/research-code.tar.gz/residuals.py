import datetime as dt,gzip,json,re
from collections import Counter
from pathlib import Path
from lexinform.document_versions import draft_version
root=Path('/Users/sobaleu/projects/lexinform-corpus');out=Path('/private/tmp/lexinform-evidence-study-lqlelnih')
r=json.loads((out/'candidate-replay.json').read_bytes());groups={}
for k,v in r['results'].items():
 if v['state']=='ambiguous':
  p,s=k.split('/')
  if p not in groups or int(s)<int(groups[p][0].split('/')[1]):groups[p]=(k,v)
months=['stycznia','lutego','marca','kwietnia','maja','czerwca','lipca','sierpnia','września','października','listopada','grudnia']
def header_date(t):
 line=next((x.strip() for x in t[:500].splitlines() if x.strip()),'')
 if not line.lower().startswith('projekt'):return None
 n=re.search(r'(\d{1,2})[. /-]+(\d{1,2})[. /-]+(\d{4})',line)
 m=re.search(r'(\d{1,2})\s+('+'|'.join(months)+r')\s+(\d{4})',line,re.I)
 try:
  if n:return dt.date(int(n[3]),int(n[2]),int(n[1]))
  if m:return dt.date(int(m[3]),months.index(m[2].lower())+1,int(m[1]))
 except ValueError:return None
 return None
rows=[];counts=Counter()
for project,(key,value) in sorted(groups.items()):
 ids=list(dict.fromkeys(re.findall(r'dokument(\d+)',' '.join(value['reasons']))))
 facts=[]
 for i in ids:
  path=root/f'documents/text/{i}.txt.gz'
  t=gzip.decompress(path.read_bytes()).decode() if path.exists() else ''
  facts.append({'id':i,'strict':str(draft_version(t)),'header':str(header_date(t)),'opening':t[:200]})
 strict=[x['strict'] for x in facts]; headers=[x['header'] for x in facts]
 if all(x!='None' for x in strict) and len(set(strict))==1:kind='same_date_conflict'
 elif all(x!='None' for x in strict):kind='strict_dates_but_other_conflict'
 elif all(x!='None' for x in headers) and len(set(headers))>1:kind='different_header_dates_parser_gap'
 elif all(x!='None' for x in headers):kind='same_header_date_parser_gap'
 else:kind='ordering_not_established_from_header'
 counts[kind]+=1;rows.append({'project':project,'key':key,'category':kind,'documents':facts})
(out/'residual-inventory.json').write_text(json.dumps({'counts':counts,'groups':rows},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':counts,'projects':len(rows),'stages':r['counts']['ambiguous']}))
