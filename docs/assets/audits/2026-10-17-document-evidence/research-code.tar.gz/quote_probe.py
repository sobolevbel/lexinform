import gzip,json,re
from pathlib import Path
from collections import Counter
from tools.probe_document_evidence import recover_quote_span,verify_frozen
root=Path('/private/tmp/lexinform-evidence-study-lqlelnih');counts={};rows=[]
for folder in (root,root/'haiku55-low'):
 verify_frozen(folder)
 assessed=json.loads((folder/'assessed.json').read_bytes());cases={c['id']:c for c in json.loads((folder/'cases.json').read_bytes())}
 for result in assessed['rows']:
  if result['state']!='parsed':continue
  key=result['model']+(' low' if folder.name=='haiku55-low' else ' default')
  c=counts.setdefault(key,Counter());c['parsed_answers']+=1
  docs={d['id']:d for d in cases[result['case']]['question']['candidates']}
  recoverable=True
  for fact in result['answer']['facts']:
   blocks={b['id']:b['text'] for b in docs[fact['candidate_id']]['blocks']}
   for citation in fact['evidence']:
    source=blocks.get(citation['block_id'],'');quote=citation['quote'];span=recover_quote_span(source,quote)
    c['citations']+=1;c['literal']+=quote in source;c['recoverable']+=span is not None;c['literal_or_unique_whitespace']+=(quote in source or span is not None)
    if quote not in source and span is None:recoverable=False
    if span is not None:rows.append({'model':key,'case':result['case'],'block':citation['block_id'],'span':span,'original_model_quote':quote,'verbatim_source_quote':source[span[0]:span[1]]})
  c['answers_all_citations_recoverable']+=recoverable
  c['matches_with_recovered_citations_and_facts']+=recoverable and result['matches'] and not result['fact_errors']
corpus=Path('/Users/sobaleu/projects/lexinform-corpus');controls=[]
mutators={
 'date':(r'\b20\d{2}\b',lambda m:str(int(m[0])+1)),
 'reference':(r'\bArt\.?\s*\d+',lambda m:m[0]+'9'),
 'negation':(r'\bnie może\b',lambda m:'może'),
 'scope':(r'\bo zmianie ustawy\b',lambda m:'o zmianie rozporządzenia'),
 'deadline':(r'\b\d+\s+dni\b',lambda m:'9999 dni'),
 'amount':(r'\b\d+[ \u00a0]+(?:mln|000)\b',lambda m:'999 mln'),
}
for identity in (779502,791866,418603,468921,469056,643081,643072,575888,575911,636766,636772):
 p=corpus/f'documents/text/{identity}.txt.gz'
 if not p.exists():continue
 text=gzip.decompress(p.read_bytes()).decode()
 for kind,(pattern,replace) in mutators.items():
  match=re.search(pattern,text,re.I)
  if match is None:continue
  start=max(0,match.start()-80);end=min(len(text),match.end()+80);source=text[start:end];quote=source[:match.start()-start]+replace(match)+source[match.end()-start:]
  controls.append({'id':identity,'kind':kind,'source':source,'mutated_quote':quote,'original_locates':recover_quote_span(source,source) is not None,'mutated_rejected':recover_quote_span(source,quote) is None})
report={'counts':counts,'recovered':rows,'semantic_controls':controls,'semantic_control_counts':dict(Counter(c['kind'] for c in controls)),'semantic_controls_rejected':sum(c['mutated_rejected'] for c in controls)}
(root/'quote-recovery.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'counts':counts,'controls':len(controls),'rejected':report['semantic_controls_rejected'],'control_kinds':report['semantic_control_counts']}))
