import gzip,json,hashlib
from pathlib import Path
from lexinform.adapters.doc_text import DocTextExtractor
from lexinform.adapters.document_text import DocumentTextExtractor,DocxTextExtractor
from lexinform.adapters.pdf_text import PypdfTextExtractor
from lexinform.document_versions import draft_version
r=Path('/Users/sobaleu/projects/lexinform-corpus'); out=Path('/private/tmp/lexinform-evidence-study-lqlelnih')
manifest=json.loads((out/'source-manifest.json').read_bytes()); index=json.loads((r/'documents/index.json').read_bytes())
extractor=DocumentTextExtractor(PypdfTextExtractor(),DocxTextExtractor(),DocTextExtractor())
rows=[]
for key in manifest:
 if not key.isdigit(): continue
 rec=index[key]; path=r/f"documents/files/{key}.{rec['extension']}"
 if not path.exists(): rows.append({'id':key,'state':'missing raw'});continue
 data=path.read_bytes(); raw=extractor.extract(data); cached=gzip.decompress((r/f'documents/text/{key}.txt.gz').read_bytes()).decode()
 rows.append({'id':key,'raw_sha256':hashlib.sha256(data).hexdigest(),'raw_extracted_sha256':hashlib.sha256(raw.encode()).hexdigest(),'raw_chars':len(raw),'cached_chars':len(cached),'raw_date':str(draft_version(raw)),'cached_date':str(draft_version(cached)),'raw_opening':raw[:650],'same_opening':raw[:2000]==cached[:2000]})
(out/'raw-validation.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'documents':len(rows),'date_agreement':sum(x.get('raw_date')==x.get('cached_date') for x in rows),'same_opening':sum(x.get('same_opening',False) for x in rows)}))
