import gzip,hashlib,json,tarfile
from pathlib import Path
r=Path('/private/tmp/lexinform-evidence-study-lqlelnih');dest=Path('/Users/sobaleu/projects/lexinform/docs/assets/audits/2026-10-17-document-evidence');dest.mkdir(parents=True)
a=json.loads((r/'assessed.json').read_bytes());b=json.loads((r/'haiku55-low/assessed.json').read_bytes());profiles=[]
for folder,data in [(r,a),(r/'haiku55-low',b)]:
 for model,c in data['counts'].items():
  rows=[x for x in data['rows'] if x['model']==model];pairs={}
  for x in rows:pairs.setdefault(x['case'].split('-',1)[0],[]).append(x)
  comparable=[v for v in pairs.values() if len(v)==2 and all(x['state']=='parsed' for x in v)]
  profiles.append({'model':model,'profile':'low-4000' if folder.name=='haiku55-low' else 'default-800','counts':c,'factual_correct_before_citation':sum(x['state']=='parsed' and not x['fact_errors'] for x in rows),'fully_checked':sum(x['state']=='parsed' and x['matches'] and not x['issues'] and not x['fact_errors'] for x in rows),'comparable_pairs':len(comparable),'stable_preference_pairs':sum(sorted(v[0]['answer']['preferred_ids'])==sorted(v[1]['answer']['preferred_ids']) for v in comparable),'actual_cost_usd':data['costs'].get(model,0)})
summary={'baseline':'981e85c plus a frozen uncommitted candidate implementation','candidate_code_manifest':'code-manifest.json.gz','cases':16,'groups':13,'variants_per_case':2,'requests_first_batch':96,'requests_followup':32,'batches':['msgbatch_01P4Zez4y4ErUiFCpyyo7EAU','msgbatch_01MoWKJkm99iWCMtHa51sbPD'],'profiles':profiles,'prior_actual_cost_usd':0.884275,'new_actual_cost_usd':a['actual_cost_usd']+b['actual_cost_usd'],'actual_cost_usd':0.884275+a['actual_cost_usd']+b['actual_cost_usd'],'budget_usd':2,'new_ceiling_usd':0.50,'first_maximum_usd':json.loads((r/'budget.json').read_bytes())['maximum_cost_usd'],'followup_maximum_usd':json.loads((r/'haiku55-low/budget.json').read_bytes())['maximum_cost_usd'],'pricing_source':'https://platform.claude.com/docs/en/about-claude/pricing','labels_precommitted':True,'pilot_is_production_acceptance':False,'residual_counts':json.loads((r/'residual-inventory.json').read_bytes())['counts'],'residual_projects':86,'residual_stages':154}
(dest/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
files=['cases.json','source-manifest.json','code-manifest.json','requests.json','results.json','assessed.json','batch-intent.json','budget.json','batch-status.json','candidate-replay.json','residual-inventory.json','raw-validation.json','raw-parser-gaps.json','container-invariance.json','quote-recovery.json','haiku55-low/cases.json','haiku55-low/requests.json','haiku55-low/results.json','haiku55-low/assessed.json','haiku55-low/batch-intent.json','haiku55-low/budget.json','haiku55-low/batch-status.json']
for name in files:
 (dest/(name.replace('/','-')+'.gz')).write_bytes(gzip.compress((r/name).read_bytes(),mtime=0))
with tarfile.open(dest/'research-code.tar.gz','w:gz') as archive:
 for path in sorted((r/'code').rglob('*.py')):archive.add(path,arcname='code/'+str(path.relative_to(r/'code')))
 for name in ['prepare.py','check_raw.py','residuals.py','check_gaps.py','container_invariance.py','quote_probe.py','package_results.py']:
  archive.add(r/name,arcname=name)
sha={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dest.iterdir())}
(dest/'SHA256SUMS.json').write_text(json.dumps(sha,indent=2)+'\n')
print(json.dumps({'new_actual_usd':summary['new_actual_cost_usd'],'overall_actual_usd':summary['actual_cost_usd'],'artifact_files':len(list(dest.iterdir())),'artifact_bytes':sum(p.stat().st_size for p in dest.iterdir())}))
