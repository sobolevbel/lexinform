import hashlib
import json
from enum import StrEnum

from pydantic import BaseModel, ConfigDict

from lexinform.models.enums import VetoOutcome
from lexinform.models.rcl import RclProject
from lexinform.models.sejm import (
    BillSubmission,
    Stage,
    reading_adjourned,
    reading_decision,
    reading_numeral,
    second_reading_sent_back,
    senate_moved_rejection,
)
from lexinform.models.wykaz import WykazEntry


class DecisionState(StrEnum):
    ABSENT = "absent"
    PENDING = "pending"
    UNKNOWN = "unknown"
    KNOWN = "known"


class SenateOutcome(StrEnum):
    NO_AMENDMENTS = "no_amendments"
    AMENDMENTS = "amendments"
    REJECTION = "rejection"
    CONSIDERED = "considered"
    REJECTION_ACCEPTED = "rejection_accepted"


class ReadingOutcome(StrEnum):
    ADJOURNED = "adjourned"
    REJECTED = "rejected"
    PASSED = "passed"
    SENT_TO_COMMITTEE = "sent_to_committee"
    COMPLETED = "completed"


class TribunalOutcome(StrEnum):
    REFERRED = "referred"
    RULING_ISSUED = "ruling_issued"


class SourceOutcome(StrEnum):
    ACTIVE = "active"
    WITHDRAWN = "withdrawn"
    ADOPTED = "adopted"
    SENT_TO_SEJM = "sent_to_sejm"
    LINKED = "linked"


class DecisionEvidence(BaseModel):
    model_config = ConfigDict(frozen=True)

    state: DecisionState
    stage: Stage | None = None
    veto: VetoOutcome | None = None
    senate: SenateOutcome | None = None
    reading: ReadingOutcome | None = None
    tribunal: TribunalOutcome | None = None
    source: SourceOutcome | None = None


def reading_evidence(stage: Stage) -> DecisionEvidence:
    """A II reading's own "niedokończone" is not an adjournment to wait out: it is one of the
    markers of `second_reading_sent_back` (druk 1929), so it is read as sent to committee before
    the generic adjournment is asked at all — only a III reading's "niedokończone" is one."""
    if stage.stage_type != "SejmReading":
        return DecisionEvidence(state=DecisionState.ABSENT)
    decision = reading_decision(stage)
    if not decision:
        return DecisionEvidence(state=DecisionState.UNKNOWN, stage=stage)
    numeral = reading_numeral(stage)
    if "odrzuc" in decision:
        outcome = ReadingOutcome.REJECTED
        state = DecisionState.KNOWN
    elif numeral == "II" and second_reading_sent_back(stage):
        outcome = ReadingOutcome.SENT_TO_COMMITTEE
        state = DecisionState.KNOWN
    elif numeral == "III" and decision.startswith("uchwal"):
        outcome = ReadingOutcome.PASSED
        state = DecisionState.KNOWN
    elif reading_adjourned(stage):
        outcome = ReadingOutcome.ADJOURNED
        state = DecisionState.PENDING
    else:
        outcome = ReadingOutcome.COMPLETED
        state = DecisionState.KNOWN
    return DecisionEvidence(state=state, stage=stage, reading=outcome)


def tribunal_evidence(stage: Stage) -> DecisionEvidence:
    if stage.stage_type == "PresidentToTribunal":
        return DecisionEvidence(
            state=DecisionState.PENDING, stage=stage, tribunal=TribunalOutcome.REFERRED
        )
    if stage.stage_type == "ConstitutionalTribunalRuling":
        return DecisionEvidence(
            state=DecisionState.KNOWN, stage=stage, tribunal=TribunalOutcome.RULING_ISSUED
        )
    return DecisionEvidence(state=DecisionState.ABSENT)


def submission_evidence(submission: BillSubmission) -> DecisionEvidence:
    if submission.is_closed:
        outcome, state = SourceOutcome.WITHDRAWN, DecisionState.KNOWN
    elif submission.print_number:
        outcome, state = SourceOutcome.LINKED, DecisionState.KNOWN
    else:
        outcome, state = SourceOutcome.ACTIVE, DecisionState.PENDING
    return DecisionEvidence(state=state, source=outcome)


def rcl_evidence(project: RclProject) -> DecisionEvidence:
    if project.sent_to_sejm:
        outcome, state = SourceOutcome.SENT_TO_SEJM, DecisionState.KNOWN
    elif not project.is_open:
        outcome, state = SourceOutcome.WITHDRAWN, DecisionState.KNOWN
    else:
        outcome, state = SourceOutcome.ACTIVE, DecisionState.PENDING
    return DecisionEvidence(state=state, source=outcome)


def wykaz_evidence(entry: WykazEntry) -> DecisionEvidence:
    if entry.is_withdrawn:
        outcome, state = SourceOutcome.WITHDRAWN, DecisionState.KNOWN
    elif entry.is_adopted:
        outcome, state = SourceOutcome.ADOPTED, DecisionState.KNOWN
    elif entry.rcl_project_id is not None:
        outcome, state = SourceOutcome.LINKED, DecisionState.KNOWN
    else:
        outcome, state = SourceOutcome.ACTIVE, DecisionState.PENDING
    return DecisionEvidence(state=state, source=outcome)


def veto_evidence(stages: tuple[Stage, ...]) -> DecisionEvidence:
    evidence = DecisionEvidence(state=DecisionState.ABSENT)
    for stage in stages:
        if stage.stage_type == "Veto":
            evidence = DecisionEvidence(
                state=DecisionState.PENDING, stage=stage, veto=VetoOutcome.PENDING
            )
        elif stage.stage_type == "PresidentMotionConsideration":
            outcome = veto_decision(stage)
            evidence = DecisionEvidence(
                state=DecisionState.UNKNOWN
                if outcome is VetoOutcome.PENDING
                else DecisionState.KNOWN,
                stage=stage,
                veto=outcome,
            )
        elif end_names_veto_sustained(stage):
            evidence = DecisionEvidence(
                state=DecisionState.KNOWN, stage=stage, veto=VetoOutcome.SUSTAINED
            )
    return evidence


def end_names_veto_sustained(stage: Stage) -> bool:
    return stage.stage_type == "End" and "nie uchwalona ponownie" in stage.stage_name.lower()


def veto_decision(stage: Stage) -> VetoOutcome:
    decision = (stage.decision or "").strip().lower()
    if "nie uchwalon" in decision:
        return VetoOutcome.SUSTAINED
    if decision.startswith("uchwalono ponownie"):
        return VetoOutcome.OVERRIDDEN
    return VetoOutcome.PENDING


def senate_evidence(stage: Stage) -> DecisionEvidence:
    outcome = None
    if stage.stage_type == "SenatePosition":
        position = (stage.position or "").strip().lower()
        if "nie wniósł" in position:
            outcome = SenateOutcome.NO_AMENDMENTS
        elif senate_moved_rejection(stage):
            outcome = SenateOutcome.REJECTION
        elif "popraw" in position:
            outcome = SenateOutcome.AMENDMENTS
    elif stage.stage_type == "SenatePositionConsideration":
        decision = (stage.decision or "").strip().lower()
        if decision.startswith("przyjęto") and "uchwałę senatu" in decision:
            outcome = SenateOutcome.REJECTION_ACCEPTED
        elif decision.startswith(("przyjęto", "odrzucono")):
            outcome = SenateOutcome.CONSIDERED
    return DecisionEvidence(
        state=DecisionState.KNOWN if outcome is not None else DecisionState.UNKNOWN,
        stage=stage,
        senate=outcome,
    )


def terminal_stage(stages: tuple[Stage, ...]) -> Stage | None:
    veto = veto_evidence(stages)
    if veto.veto is VetoOutcome.SUSTAINED:
        return veto.stage
    for stage in reversed(stages):
        if reading_evidence(stage).reading is ReadingOutcome.REJECTED:
            return stage
        if (
            stage.stage_type == "SenatePositionConsideration"
            and senate_evidence(stage).senate is SenateOutcome.REJECTION_ACCEPTED
        ):
            return stage
    return None


def decision_changes(known: tuple[Stage, ...], found: tuple[Stage, ...]) -> tuple[Stage, ...]:
    """Only `SenatePosition`: `position` carries its outcome and is excluded from `_stage_key`."""
    previous = {
        (stage.stage_type, stage.date, stage.print_number): senate_evidence(stage).senate
        for stage in known
        if stage.stage_type == "SenatePosition"
    }
    return tuple(
        stage
        for stage in found
        if stage.stage_type == "SenatePosition"
        and (stage.stage_type, stage.date, stage.print_number) in previous
        and senate_evidence(stage).senate is not None
        and senate_evidence(stage).senate
        != previous[(stage.stage_type, stage.date, stage.print_number)]
    )


def decision_fingerprint(stages: tuple[Stage, ...]) -> str:
    facts = [
        (
            stage.stage_type,
            stage.date.isoformat() if stage.date else None,
            stage.print_number,
            senate_evidence(stage).senate,
        )
        for stage in stages
        if stage.stage_type == "SenatePosition"
    ]
    return hashlib.sha256(json.dumps(facts).encode()).hexdigest()


def process_evidence(
    stages: tuple[Stage, ...], *, passed: bool | None, closed: bool
) -> DecisionEvidence:
    """An unresolved veto blocks listing signals; closure alone does not establish a decision."""
    veto = veto_evidence(stages)
    if veto.state is not DecisionState.ABSENT:
        return veto
    terminal = terminal_stage(stages)
    if terminal is not None:
        return DecisionEvidence(
            state=DecisionState.KNOWN, stage=terminal, reading=ReadingOutcome.REJECTED
        )
    for stage in reversed(stages):
        if (
            stage.stage_type == "End"
            and closed
            and passed is False
            and "niezgodność z konstytucją" in stage.stage_name.casefold()
            and any(item.stage_type == "ConstitutionalTribunalRuling" for item in stages)
        ):
            return DecisionEvidence(
                state=DecisionState.KNOWN, stage=stage, reading=ReadingOutcome.REJECTED
            )
        if stage.stage_type == "End" and stage.stage_name.casefold() in {"odrzucono", "wycofano"}:
            return DecisionEvidence(
                state=DecisionState.KNOWN, stage=stage, source=SourceOutcome.WITHDRAWN
            )
        evidence = reading_evidence(stage)
        if evidence.reading is ReadingOutcome.PASSED:
            if closed and passed is False:
                return DecisionEvidence(state=DecisionState.UNKNOWN)
            return evidence
    if passed is True:
        return DecisionEvidence(state=DecisionState.KNOWN, reading=ReadingOutcome.PASSED)
    if closed and passed is False:
        return DecisionEvidence(state=DecisionState.KNOWN, reading=ReadingOutcome.REJECTED)
    return DecisionEvidence(state=DecisionState.UNKNOWN if closed else DecisionState.ABSENT)


def process_rejected(evidence: DecisionEvidence) -> bool:
    return evidence.state is DecisionState.KNOWN and (
        evidence.veto is VetoOutcome.SUSTAINED
        or evidence.reading is ReadingOutcome.REJECTED
        or evidence.source is SourceOutcome.WITHDRAWN
    )
