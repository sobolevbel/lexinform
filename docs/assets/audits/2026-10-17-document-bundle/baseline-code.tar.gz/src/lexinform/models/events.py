"""What a status update is about.

Not every new node of the Sejm's stage tree is news for a reader: "Skierowano do I czytania",
"Praca w komisjach" or the final "Uchwalono" only bracket the events that matter (the referral
itself, the committee's report, the vote). `is_substantive` tells the two apart, `has_news`
decides whether a detected change deserves its own post (service stages are held back and
listed with the next substantive one) and `update_event` names the post: the reader sees
"Сейм принял закон" or "Направлен в комиссии" in the header, not "Обновление".
"""

import datetime as dt

from lexinform.models.bill import (
    Bill,
    StatusChange,
    process_stages,
    veto_decision,
    veto_outcome,
    veto_stood,
)
from lexinform.models.enums import VetoOutcome
from lexinform.models.evidence import (
    DecisionState,
    ReadingOutcome,
    SenateOutcome,
    SourceOutcome,
    TribunalOutcome,
    process_evidence,
    process_rejected,
    reading_evidence,
    senate_evidence,
    submission_evidence,
    tribunal_evidence,
)
from lexinform.models.rcl import RCL_STAGE_TYPE
from lexinform.models.sejm import (
    Stage,
    flatten_stages,
    reading_numeral,
    stage_keys,
)

# `Opinion` frames nothing, but a body filing one is not this channel's genre (decided
# 2026-09-12), and it is held for the same reason: told with the next update that has something
# to say, never a post of its own.
SERVICE_STAGE_TYPES = frozenset(
    {"Start", "ReadingReferral", "Reading", "CommitteeWork", "End", "Opinion"}
)
HEARING_APPLICATION_DAYS = 10


def is_substantive(stage: Stage) -> bool:
    """True when the stage alone is worth telling the reader about.

    `SERVICE_STAGE_TYPES` only frame other events; "Ustawę przekazano Prezydentowi" is not one of
    them, because it starts the 21 days of art. 122, the reader's last window. A reading is
    decided case by case: the third one decides the bill, an earlier one is news only when it
    decided something — rejected the bill outright, or sent it back to the committee with
    amendments.
    """
    if stage.stage_type in SERVICE_STAGE_TYPES:
        return False
    if stage.stage_type == "SejmReading":
        evidence = reading_evidence(stage)
        if reading_numeral(stage) == "III" and evidence.state is DecisionState.KNOWN:
            return True
        return evidence.reading in (
            ReadingOutcome.REJECTED,
            ReadingOutcome.SENT_TO_COMMITTEE,
        )
    return True


def has_news(change: StatusChange, *, act_published: bool = False) -> bool:
    """Whether the change deserves a post now. A closure that arrives together with the act in
    Dziennik Ustaw is not news on its own: the publication notice says it all."""
    if change.withdrawn or change.discontinued or change.content_changed:
        return True
    if (change.closure_detected or change.decision_changed) and not act_published:
        return True
    if change.supplements:
        return True
    return any(is_substantive(st) for st in change.new_stages)


def fills_in_the_past(known: tuple[Stage, ...], found: tuple[Stage, ...]) -> bool:
    """Every stage this reading adds stands, in the tree, before one the channel already has.

    The Sejm does not publish the road in order, and such a change is held rather than told: named
    after its own newest stage it would announce the cause of the last post. Tree order is the
    road's order — over term 10 no road stage stands before one with an earlier date, while 521 of
    938 processes have a day carrying several. Only the road counts (`process_stages`): 196 of the
    241 `GovermentPosition` and `Opinion` nodes stand before a road stage dated later.
    """
    road = process_stages(found)
    already = set(stage_keys(process_stages(known)))
    last_known = newest_new = -1
    for index, (stage, key) in enumerate(zip(flatten_stages(road), stage_keys(road), strict=True)):
        if key in already:
            last_known = index
        elif is_substantive(stage):
            newest_new = index
    return -1 < newest_new < last_known


def update_event(change: StatusChange, bill: Bill) -> str:
    """The one event the post is named after (keys of `Labels.update_headers`)."""
    if change.discontinued:
        return "discontinued"
    if change.withdrawn:
        return "withdrawn" if _listing_says_withdrawn(bill) else "abandoned"
    if _is_first_update_of_successor(change, bill):
        return "print_assigned" if bill.has_process else "rcl_started"
    named = _newest_stage_event(change.new_stages)
    if (
        named == "passed"
        and change.closure_detected
        and process_evidence(bill.stages, passed=change.passed, closed=True).state
        is DecisionState.UNKNOWN
    ):
        return "decision_unknown"
    if named is not None:
        return named
    if change.consultation_opened:
        # The letter can arrive under a stage the timeline already showed as reached, and then
        # there is no new stage to name the post: without this the one moment a reader of an RCL
        # project can act on was announced as «Обновление».
        return "consultation_opened"
    if change.closure_detected or change.decision_changed:
        return _closure_event_of(change, bill)
    if change.content_changed:
        return "text_changed"
    supplement = supplement_event(change)
    if supplement is not None:
        return supplement
    if bill.wykaz is not None and bill.wykaz.is_adopted:
        return "wykaz_adopted"
    return "update"


def _listing_says_withdrawn(bill: Bill) -> bool:
    """The `/bills` row really says the bill is off: WITHDRAWN, NOT_PROCEEDED or OBSOLETE.

    A pre-print entry the Sejm has simply stopped listing says nothing of the kind — the
    reconciler reads the end off its age (`PrePrintReconciler._long_gone`), and an entry can wait
    months for a print number in the Marszałek's "freezer". «Проект отозван» would state a
    decision by the applicant that may never have been taken.
    """
    submission = bill.submission
    return (
        submission is not None and submission_evidence(submission).source is SourceOutcome.WITHDRAWN
    )


def supplement_event(change: StatusChange) -> str | None:
    """The filed document the post is named after: the government's position outweighs its
    assessment of the effects. The arrival of the position is also a stage (`GovermentPosition`),
    and one with no name of its own — without this the post that carries the government's verdict
    would be headed "Обновление"."""
    kinds = {record.source_kind for record in change.supplements}
    for kind in ("government_position", "impact_assessment"):
        if kind in kinds:
            return kind
    return None


def _is_first_update_of_successor(change: StatusChange, bill: Bill) -> bool:
    """A row that inherited a thread opens it by saying what it is: the druk of an RPW entry or
    an RCL project, the project of a plan."""
    return bool(bill.linked_number) and change.old_fingerprint == bill.linked_number


def _newest_stage_event(stages: list[Stage]) -> str | None:
    """The newest stage names the post; referrals to several committees are told as a group.

    `Voting` is always a child of a `SejmReading` or a `PresidentMotionConsideration` that also
    moved and already names the post more specifically ("Сейм принял закон", not "Состоялось
    голосование") — so it is the last resort, checked once everything else in the change has
    been asked, not the newest node by position.
    """
    referrals = sum(1 for st in stages if st.stage_type == "Referral")
    fallback: str | None = None
    for stage in reversed(stages):
        if stage.stage_type == "Voting":
            fallback = fallback or _stage_event(stage)
            continue
        key = _stage_event(stage)
        if key == "referral" and referrals > 1:
            return "referrals"
        if key is not None:
            return key
    return fallback


def _closure_event_of(change: StatusChange, bill: Bill) -> str:
    if bill.wykaz is not None:
        return "wykaz_withdrawn"
    if bill.rcl is not None:
        return "rcl_closed"
    # The API leaves `passed` true on a law a veto killed, so the listing alone would head the
    # post that closes the road «Сейм принял закон» (druk 410 of term 10 and seven like it).
    outcome = veto_outcome(bill.stages)
    if outcome is VetoOutcome.PENDING:
        return "text_changed" if change.content_changed else "update"
    if outcome is VetoOutcome.OVERRIDDEN:
        return "veto_overridden"
    evidence = process_evidence(
        bill.stages,
        passed=change.passed,
        closed=change.closure_detected or bill.summary.closure_date is not None,
    )
    if evidence.reading is ReadingOutcome.PASSED:
        return "passed"
    return closure_event(bill) if process_rejected(evidence) else "decision_unknown"


def closure_event(bill: Bill) -> str:
    """How a Sejm process ended without a law. `closureDate` with `passed=false` covers a
    rejection, a withdrawal by the applicant and a veto the Sejm could not override, and the
    listing tells none of them apart — so the stages and the `/bills` entry do, and what neither
    explains is told without naming a culprit."""
    if veto_stood(bill.stages):
        return "veto_sustained"
    submission = bill.submission
    if submission is not None and submission.status == "WITHDRAWN":
        return "withdrawn_by_applicant"
    if any(_rejects(stage) for stage in flatten_stages(bill.stages)):
        return "rejected"
    return "not_enacted"


def _rejects(stage: Stage) -> bool:
    return reading_evidence(stage).reading is ReadingOutcome.REJECTED


_EVENT_BY_STAGE_TYPE = {
    "ReadingReferral": "first_reading_referral",
    "Reading": "first_reading",
    "CommitteeWork": "committee_work",
    "SenatePositionConsideration": "senate_considered",
    "ToPresident": "to_president",
    "PresidentSignature": "signed",
    "Veto": "veto",
    "PublicHearing": "hearing",
    "Start": "start",
    # Always a child of a `SejmReading` or a `PresidentMotionConsideration` whose own decision
    # already names the post (both are in this table or handled above); kept as a fallback for
    # the shape it never happens to have in real data — a vote with no decided parent alongside
    # it — so it says something true instead of the bare "Обновление".
    "Voting": "voting",
    # Same key as the digest uses: the stage arrives even when the document behind it could not
    # be read, and then `supplement_event` has nothing to name the post with.
    "GovermentPosition": "government_position",
}


def _stage_event(stage: Stage) -> str | None:
    """What one stage is called in a post; None when the stage has no name of its own.

    `_EVENT_BY_STAGE_TYPE` holds the stages whose name is their type; the rest read what the
    stage decided.
    """
    kind = stage.stage_type
    if kind == RCL_STAGE_TYPE:
        return "rcl_to_sejm" if "sejm" in stage.stage_name.lower() else "rcl_stage"
    if kind == "Referral":
        return "referral_plenary" if stage.committee_code == "Sejm" else "referral"
    if kind == "SejmReading":
        return _reading_event(stage)
    tribunal = tribunal_evidence(stage).tribunal
    if tribunal is TribunalOutcome.REFERRED:
        return "tribunal"
    if tribunal is TribunalOutcome.RULING_ISSUED:
        return "tribunal_ruled"
    if kind == "CommitteeReport":
        return _report_event(stage)
    if kind == "SenatePosition":
        return _senate_event(stage)
    if kind == "SenatePositionConsideration":
        evidence = senate_evidence(stage)
        if evidence.state is not DecisionState.KNOWN:
            return "senate"
        return (
            "rejected"
            if evidence.senate is SenateOutcome.REJECTION_ACCEPTED
            else "senate_considered"
        )
    if kind == "PresidentMotionConsideration":
        return _veto_vote_event(stage)
    return _EVENT_BY_STAGE_TYPE.get(kind)


def _veto_vote_event(stage: Stage) -> str:
    """The Sejm voted on the President's motion: "uchwalono ponownie" (the 3/5 majority was
    there, the law stands) or "nie uchwalona ponownie" (the veto ended it)."""
    return {
        VetoOutcome.PENDING: "veto",
        VetoOutcome.SUSTAINED: "veto_sustained",
        VetoOutcome.OVERRIDDEN: "veto_overridden",
    }[veto_decision(stage)]


def _reading_event(stage: Stage) -> str:
    evidence = reading_evidence(stage)
    if evidence.reading is ReadingOutcome.REJECTED:
        return "rejected"
    numeral = reading_numeral(stage)
    if numeral == "III":
        return "passed" if evidence.reading is ReadingOutcome.PASSED else "third_reading"
    if numeral == "II":
        return (
            "second_reading_amendments"
            if evidence.reading is ReadingOutcome.SENT_TO_COMMITTEE
            else "second_reading"
        )
    return "first_reading"


def _report_event(stage: Stage) -> str:
    if stage.sub_committee:
        return "subcommittee_report"
    proposal = (stage.proposal or "").lower()
    if "odrzuc" in proposal and "popraw" not in proposal:
        return "committee_rejects"
    return "committee_report"


def _senate_event(stage: Stage) -> str:
    outcome = senate_evidence(stage).senate
    if outcome is None:
        return "senate"
    return {
        SenateOutcome.NO_AMENDMENTS: "senate_no_amendments",
        SenateOutcome.REJECTION: "senate_rejected",
        SenateOutcome.AMENDMENTS: "senate_amendments",
    }.get(outcome, "senate")


def amendments_stage(stages: list[Stage]) -> Stage | None:
    """The newest of the new stages that carries amendments as a document: the Senate's
    position with its resolution print, or a committee report that answers amendments (the
    "-A" print after the 2nd reading, the report on the Senate's position) rather than
    attaching a new bill text."""
    for stage in reversed(stages):
        senate = stage.stage_type == "SenatePosition" and bool(stage.print_number)
        position = (stage.position or "").lower()
        if senate and "popraw" in position and "nie wniósł" not in position:
            return stage
        report = stage.stage_type == "CommitteeReport" and bool(stage.report_file)
        proposal = (stage.proposal or "").lower()
        if (
            report
            and not stage.carries_bill_text
            and "popraw" in proposal
            and "bez poprawek" not in proposal
        ):
            return stage
    return None


_EVENT_TAG = {
    "passed": "passed",
    "veto_overridden": "passed",
    "rejected": "rejected",
    "not_enacted": "rejected",
    "veto_sustained": "rejected",
    "withdrawn_by_applicant": "withdrawn",
    "referral": "committee",
    "referrals": "committee",
    "committee_report": "committee",
    "committee_rejects": "committee",
    "subcommittee_report": "committee",
    "hearing": "hearing",
    "tribunal": "tribunal",
    "tribunal_ruled": "tribunal",
}
_SENATE_STAGES = frozenset({"SenatePosition", "SenatePositionConsideration"})
_PRESIDENT_STAGES = frozenset({"ToPresident", "PresidentSignature"})
FRAME_STAGE_TYPES = frozenset({"ReadingReferral", "CommitteeWork"})


def event_keys(change: StatusChange, event: str) -> list[str]:
    """Which searchable events a status update carries, in display order (the tags). `event` is
    what the post is named after, so that a reader can find every bill the Sejm passed or
    rejected, not only the ones whose stages happen to carry a recognised type; `_EVENT_TAG` maps
    those names to the events a reader searches the channel for."""
    types = {stage.stage_type for stage in flatten_stages(tuple(change.new_stages))}
    keys = [key for key in (_EVENT_TAG.get(event),) if key]
    if "Voting" in types or any(st.voting for st in change.new_stages):
        keys.append("voting")
    if types & _SENATE_STAGES:
        keys.append("senate")
    if types & _PRESIDENT_STAGES:
        keys.append("president")
    if "Veto" in types or event in ("veto_sustained", "veto_overridden"):
        # The post that closes the road carries no `Veto` stage — its new stage is the `End`
        # node or the Sejm's vote on the motion — so without this the veto's last word is the
        # one post a search for it misses.
        keys.append("veto")
    if change.amendments is not None or event == "second_reading_amendments":
        keys.append("amendments")
    if any(r.source_kind == "government_position" for r in change.supplements):
        keys.append("government_position")
    if any(r.source_kind == "impact_assessment" for r in change.supplements):
        keys.append("impact_assessment")
    if change.consultation_opened:
        keys.append("consultations")
    if change.withdrawn:
        keys.append("withdrawn")
    if change.discontinued:
        keys.append("discontinued")
    return list(dict.fromkeys(keys))


def reaches_sejm(change: StatusChange) -> bool:
    """The update carries the RCL stage "Skierowanie projektu ustawy do Sejmu"."""
    return any(
        st.stage_type == RCL_STAGE_TYPE and "sejm" in st.stage_name.lower()
        for st in change.new_stages
    )


def told_stages(stages: list[Stage]) -> list[Stage]:
    """The stages worth telling on their own: a frame node ("Skierowano do I czytania", "Praca
    w komisjach") says nothing its children do not, so it is dropped when they are listed
    anyway."""
    return [
        st
        for st in stages
        if not (st.stage_type in FRAME_STAGE_TYPES and any(c in stages for c in st.children))
    ]


def open_hearing(bill: Bill, today: dt.date) -> Stage | None:
    """A public hearing that is announced and has not taken place yet."""
    return next(
        (
            st
            for st in flatten_stages(bill.stages)
            if st.stage_type == "PublicHearing" and (st.date is None or st.date >= today)
        ),
        None,
    )


def hearings_due(bill: Bill, today: dt.date, *, days_before: int) -> list[Stage]:
    """Public hearings a reader should be reminded of now: the application deadline is within
    the next `days_before` days, or it is already the last one — a hearing announced with less
    than the ten days art. 70b asks for would otherwise never be reminded at all, and that is
    the case where a reader most needs to hear about it."""
    return [
        stage
        for stage in flatten_stages(bill.stages)
        if _hearing_reminder_due(stage, today, days_before=days_before)
    ]


def _hearing_reminder_due(stage: Stage, today: dt.date, *, days_before: int) -> bool:
    deadline = hearing_application_deadline(stage)
    if deadline is None or stage.date is None:
        return False
    if today <= deadline <= today + dt.timedelta(days=days_before):
        return True
    return deadline < today <= stage.date


def hearing_application_deadline(stage: Stage) -> dt.date | None:
    """Last day to apply for a public hearing (`PublicHearing` stage), if the hearing is dated:
    Regulamin Sejmu art. 70b asks for the application at least ten days before it."""
    if stage.stage_type != "PublicHearing" or stage.date is None:
        return None
    return stage.date - dt.timedelta(days=HEARING_APPLICATION_DAYS)


def adoption_signature(change: StatusChange, bill: Bill) -> str:
    if (
        change.content_changed
        or change.amendments
        or change.supplements
        or change.withdrawn
        or change.discontinued
    ):
        return ""
    event = update_event(change, bill)
    if (
        process_evidence(
            bill.stages, passed=bill.summary.passed, closed=bill.summary.closure_date is not None
        ).state
        is not DecisionState.KNOWN
    ):
        return ""
    if event not in {"passed", "voting"}:
        return ""
    parent = next(
        (
            stage
            for stage in reversed(bill.stages)
            if reading_evidence(stage).reading is ReadingOutcome.PASSED
        ),
        None,
    )
    if parent is None:
        return (
            f"listing/{bill.summary.closure_date}"
            if event == "passed" and bill.summary.closure_date is not None
            else ""
        )
    if event == "voting":
        identities = {
            (stage.voting.sitting, stage.voting.voting_number)
            for stage in flatten_stages(change.new_stages)
            if stage.voting is not None
        }
        parent_votes = {
            (stage.voting.sitting, stage.voting.voting_number)
            for stage in flatten_stages(parent.children)
            if stage.voting is not None
        }
        if (
            not identities
            or any(None in identity for identity in identities)
            or not identities <= parent_votes
        ):
            return ""
    return f"adoption/{parent.date}/{parent.sitting_num}/{parent.print_number}"
