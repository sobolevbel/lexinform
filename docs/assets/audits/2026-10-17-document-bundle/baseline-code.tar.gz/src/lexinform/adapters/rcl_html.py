"""Scraper for legislacja.rcl.gov.pl (Rządowy Proces Legislacyjny), which has no API.

Verified behaviour of the site (September 2026):
- `/lista?typeId=2` lists bills; `sKey=modifiedDate&sOrder=desc` sorts by the last change, so a
  "modified since" walk stops at the first older row. `pSize` accepts 10/50/100, `pNumber` pages.
- Unknown query parameters (`pSize=all`, `modifiedDateFrom`) and blocked clients get HTTP 200
  with a "Request Rejected" page from the WAF: we treat it as the site being unavailable.
- `/projekt/{id}` is the timeline only; folders and documents of a stage need
  `/projekt/{id}/katalog/{stageId}` (one request per stage, 5-10 s each).
- `/getIdFromLegislacja?number=RM-0610-139-26` redirects (302) to the project page: the join
  between a Sejm print (`rclNum`) and the RCL project.
"""

import logging
import re
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from datetime import date, datetime
from typing import Any
from urllib.parse import parse_qs, urljoin, urlparse

import httpx2 as httpx
from bs4 import BeautifulSoup, Tag

from lexinform.adapters.browser_identity import BROWSER_HEADERS
from lexinform.adapters.retries import backoff_delay
from lexinform.adapters.streams import read_bounded
from lexinform.errors import RclUnavailableError
from lexinform.models import (
    RclDocument,
    RclFolder,
    RclProject,
    RclProjectSummary,
    RclStage,
    normalize_wykaz_number,
)
from lexinform.models.rcl import RCL_BASE_URL, StageState, parse_stage_label

__all__ = [
    "ListPage",
    "RclClient",
    "RclPageError",
    "parse_list",
    "parse_list_page",
    "parse_project",
    "parse_stage_catalog",
]

log = logging.getLogger(__name__)

BILLS_TYPE_ID = 2
_REJECTED_TITLE = "request rejected"
_DOCUMENT_ID = re.compile(r"dokument(\d+)\.", re.IGNORECASE)
_PROJECT_ID = re.compile(r"/projekt/(\d+)")
_LIST_TOTAL = re.compile(r"Lista projektów według wybranych kryteriów:\s*(\d+)")


class RclPageError(RuntimeError):
    """A page that does not look like what we expect (missing project, changed markup)."""


class RclClient:
    def __init__(
        self,
        base_url: str = RCL_BASE_URL,
        *,
        page_size: int = 100,
        timeout: float = 60.0,
        probe_timeout: float = 20.0,
        max_retries: int = 3,
        backoff_seconds: float = 1.0,
        proxy: str | None = None,  # HTTP forward proxy with an EU address (see Settings)
        transport: httpx.BaseTransport | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        # The first list page of a run is a probe: RCL answers it in well under a second when it
        # is up, so a site that does not answer is declared down after one short attempt instead
        # of `max_retries` full timeouts (4 minutes with the defaults). Project pages, which take
        # ~10 s each, keep the long timeout and the retries.
        self._probe_timeout = probe_timeout
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            # A browser's identity: the site is built for browsers and its WAF judges clients.
            headers=BROWSER_HEADERS,
            proxy=proxy,
            transport=transport,
            follow_redirects=False,
        )
        self._page_size = page_size
        self._max_retries = max_retries
        self._backoff = backoff_seconds
        self._sleep = sleep
        self._unreachable_since: str | None = None

    def list_projects(self, *, modified_since: date) -> Iterator[RclProjectSummary]:
        page = 1
        previous_first: int | None = None
        while True:
            params: dict[str, str | int] = {
                "typeId": BILLS_TYPE_ID,
                "sKey": "modifiedDate",
                "sOrder": "desc",
                "pSize": self._page_size,
                "pNumber": page,
            }
            listing = parse_list_page(self._get_text("/lista", params=params, probe=page == 1))
            rows = listing.rows
            if not rows and listing.total and page == 1:
                raise RclPageError(f"list page shows {listing.total} projects but no rows parsed")
            if not rows or rows[0].id == previous_first:
                return
            previous_first = rows[0].id
            for row in rows:
                if row.modified is not None and row.modified < modified_since:
                    return
                yield row
            if len(rows) < self._page_size:
                return
            page += 1

    def get_project(self, project_id: int) -> RclProject:
        html = self._get_text(f"/projekt/{project_id}")
        return parse_project(html, project_id, base_url=self._base_url)

    def get_stage(self, project_id: int, stage_id: int) -> RclStage:
        html = self._get_text(f"/projekt/{project_id}/katalog/{stage_id}")
        return parse_stage_catalog(html, stage_id, base_url=self._base_url)

    def resolve_project_id(self, rm_number: str) -> int | None:
        response = self._request(
            "GET", "/getIdFromLegislacja", params={"number": rm_number}, allow_404=True
        )
        response.close()
        location = response.headers.get("location", "")
        match = _PROJECT_ID.search(location)
        return int(match.group(1)) if match else None

    def download(self, url: str, *, max_bytes: int | None = None) -> bytes:
        """Stream a document; stop as soon as `max_bytes` is exceeded."""
        response = self._request("GET", url, stream=True)
        try:
            body = read_bounded(response.iter_bytes(), url, max_bytes)
        finally:
            response.close()
        if _is_rejected_html(body):
            raise RclUnavailableError(f"GET {url}: request rejected by the WAF")
        return body

    def close(self) -> None:
        self._client.close()

    def _get_text(
        self, path: str, params: dict[str, str | int] | None = None, *, probe: bool = False
    ) -> str:
        response = self._request("GET", path, params=params, probe=probe)
        text = response.text
        if _is_rejected_html(text.encode("utf-8", "ignore")):
            raise RclUnavailableError(f"GET {path}: request rejected by the WAF")
        return text

    def _request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, str | int] | None = None,
        allow_404: bool = False,
        stream: bool = False,
        probe: bool = False,
    ) -> httpx.Response:
        """One request with retries; a `probe` gets one attempt with the short timeout.

        A client that has found the host unreachable keeps probing until one request gets
        through: full patience for every later request is spent on a question the run has already
        answered — one run spent 247 s of its 516 proving RCL down a second time. A short attempt
        costs 20 s, and the host coming back mid-run is still noticed.
        """
        probe = probe or self._unreachable_since is not None
        retries = 0 if probe else self._max_retries
        timeout = self._probe_timeout if probe else self._client.timeout
        attempt = 0
        while True:
            attempt += 1
            try:
                request = self._client.build_request(method, url, params=params, timeout=timeout)
                response = self._client.send(request, stream=stream)
            except httpx.TransportError as exc:
                if attempt > retries:
                    raise self._down(
                        f"{method} {url} failed after {attempt} attempt(s): {exc}"
                    ) from exc
                self._wait(attempt, f"{method} {url}: {exc}")
                continue
            if response.status_code >= 500 or response.status_code == 429:
                response.close()
                if attempt <= retries:
                    self._wait(attempt, f"{method} {url}: HTTP {response.status_code}")
                    continue
                raise self._down(
                    f"{method} {url}: HTTP {response.status_code} after {attempt} attempts"
                )
            self._unreachable_since = None
            if response.status_code == 404 and allow_404:
                return response
            if response.status_code >= 400:
                response.close()
                raise RclPageError(f"{method} {url}: HTTP {response.status_code}")
            return response

    def _down(self, reason: str) -> RclUnavailableError:
        """The host did not answer: remember it, so the next request asks briefly."""
        self._unreachable_since = reason
        return RclUnavailableError(reason)

    def _wait(self, attempt: int, reason: str) -> None:
        delay = backoff_delay(self._backoff, attempt)
        log.warning("RCL retry %d in %.1fs (%s)", attempt, delay, reason)
        self._sleep(delay)


def _is_rejected_html(body: bytes) -> bool:
    head = body[:2048].lower()
    return b"<title>" in head and _REJECTED_TITLE.encode() in head


@dataclass(frozen=True)
class ListPage:
    """One page of `/lista`: its rows, the total the page announces, its number."""

    rows: list[RclProjectSummary]
    total: int | None
    number: int


def parse_list(html: str, *, base_url: str = RCL_BASE_URL) -> list[RclProjectSummary]:
    """Rows of `/lista`: id, title, applicant, wykaz number, created and modified dates."""
    return parse_list_page(html).rows


def parse_list_page(html: str) -> ListPage:
    soup = _soup(html)
    total_match = _LIST_TOTAL.search(soup.get_text(" "))
    current = soup.select_one("div.text-right span.text-lightgrey")
    number = 1
    if current is not None and current.parent is not None:
        digits = [t for t in current.parent.stripped_strings if t.isdigit()]
        number = int(digits[0]) if digits else 1
    rows: list[RclProjectSummary] = []
    for tr in soup.select("table#table tbody tr"):
        cells = tr.find_all("td", recursive=False)
        if len(cells) < 5:
            continue
        link = cells[0].find("a")
        if not isinstance(link, Tag):
            continue
        match = _PROJECT_ID.search(_href(link))
        if match is None:
            continue
        rows.append(
            RclProjectSummary(
                id=int(match.group(1)),
                title=_text(link),
                applicant=_text(cells[1]),
                wykaz_number=normalize_wykaz_number(_text(cells[2])),
                created=_parse_date(_text(cells[3])),
                modified=_parse_date(_text(cells[4])),
            )
        )
    return ListPage(rows, int(total_match.group(1)) if total_match else None, number)


def parse_project(html: str, project_id: int, *, base_url: str = RCL_BASE_URL) -> RclProject:
    """The project page: metadata rows and the stage timeline (folders are not on this page)."""
    soup = _soup(html)
    title_tag = soup.select_one("div.rcl-title")
    info = soup.select_one("div.info")
    if title_tag is None or info is None:
        raise RclPageError(f"project {project_id}: no title or info block on the page")
    fields = _info_fields(info)
    wykaz = fields.get("Numer z wykazu")
    stages = tuple(_parse_timeline(soup))
    if not stages:
        raise RclPageError(f"project {project_id}: no stage timeline on the page (markup changed?)")
    sejm_url, rm_number = _sejm_reference(soup)
    created = _parse_date(_text(fields["Data utworzenia"])) if "Data utworzenia" in fields else None
    if created is None:
        raise RclPageError(f"project {project_id}: no creation date")
    modified = max([created, *(st.modified for st in stages if st.modified)])
    return RclProject(
        id=project_id,
        title=_text(title_tag),
        applicant=_text(fields["Wnioskodawca"]) if "Wnioskodawca" in fields else "",
        wykaz_number=normalize_wykaz_number(_text(wykaz)) if wykaz else None,
        wykaz_url=_first_href(wykaz) if wykaz else None,
        created=created,
        modified=modified,
        departments=_links_text(fields.get("Działy")),
        keywords=_links_text(fields.get("Hasła")),
        status=_text(fields["Status projektu"]) if "Status projektu" in fields else "",
        eu_note=_text(fields["Projekt realizuje przepisy prawa Unii Europejskiej"])
        if "Projekt realizuje przepisy prawa Unii Europejskiej" in fields
        else None,
        term_label=_text(fields["Kadencja"]) if "Kadencja" in fields else None,
        rm_number=rm_number,
        sejm_url=sejm_url,
        stages=stages,
    )


def parse_stage_catalog(html: str, stage_id: int, *, base_url: str = RCL_BASE_URL) -> RclStage:
    """One stage with its folders and documents, from `/projekt/{id}/katalog/{stageId}`."""
    soup = _soup(html)
    node = soup.find("li", id=str(stage_id))
    if not isinstance(node, Tag):
        raise RclPageError(f"stage {stage_id}: not on the page")
    stage = _parse_stage_node(node)
    folders: list[RclFolder] = []
    for box in node.select("div.clearbox"):
        head = box.select_one("li.childdir")
        if head is None or not head.get("id"):
            continue
        folder_id = int(str(head.get("id")))
        name = _own_text(head)
        modified_tag = head.select_one("div.small2")
        modified = _date_after_colon(_text(modified_tag)) if modified_tag else None
        documents = tuple(
            doc for doc in (_parse_document(li, base_url) for li in box.select("li.doc")) if doc
        )
        folders.append(RclFolder(id=folder_id, name=name, modified=modified, documents=documents))
    # The catalog page is the only place `catalog_read` is set: a stage that came from the
    # timeline carries the folders nobody has looked for, which is not the same as none.
    return stage.model_copy(update={"folders": tuple(folders), "catalog_read": True})


def _soup(html: str) -> BeautifulSoup:
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.get_text(strip=True).lower() if soup.title else ""
    if title == _REJECTED_TITLE:
        raise RclUnavailableError("request rejected by the WAF")
    return soup


def _parse_timeline(soup: BeautifulSoup) -> Iterator[RclStage]:
    nodes = soup.select("ul.cbp_tmtimeline > li[id]")
    skipped = 0
    for node in nodes:
        try:
            yield _parse_stage_node(node)
        except ValueError as exc:
            skipped += 1
            log.warning("stage node %s skipped: %s", node.get("id"), exc)
    if nodes and skipped == len(nodes):
        raise RclPageError("no stage node could be read (markup changed?)")


def _parse_stage_node(node: Tag) -> RclStage:
    label = node.select_one("div[class^=cbp_tmlabel] > div")
    if label is None:
        raise ValueError("stage without a label")
    link = label.find("a", recursive=False)
    number, name = parse_stage_label(_text(link) if isinstance(link, Tag) else _own_text(label))
    started = ended = modified = None
    for p in node.select("span.cbp_tmtime p"):
        text = _text(p).lower()
        if text.startswith("rozpoczęcie"):
            started = _date_after_colon(text)
        elif text.startswith("zakończenie"):
            ended = _date_after_colon(text)
    small = label.select_one("div.small2")
    if small is not None:
        modified = _date_after_colon(_text(small))
    return RclStage(
        id=int(str(node.get("id"))),
        number=number,
        name=name,
        state=_state_of(node),
        started=started,
        ended=ended,
        modified=modified,
    )


def _state_of(node: Tag) -> StageState:
    icon = node.select_one("div[class^=cbp_tmicon]")
    classes = " ".join(icon.get_attribute_list("class")) if icon else ""
    if "notstart" in classes:
        return "not_started"
    if "active" in classes:
        return "active"
    return "reached"


def _parse_document(li: Tag, base_url: str) -> RclDocument | None:
    link = li.find("a")
    if not isinstance(link, Tag):
        return None
    href = _href(link)
    match = _DOCUMENT_ID.search(href)
    if match is None:
        return None
    author = created = None
    for small in li.select("div.small3"):
        text = _text(small)
        if "Autor dokumentu:" in text:
            author = text.split("Autor dokumentu:", 1)[1].split(", wprowadzony", 1)[0].strip()
        if "Data utworzenia:" in text:
            created = _date_after_colon(text)
    return RclDocument(
        id=int(match.group(1)),
        name=_text(link),
        url=urljoin(base_url + "/", href),
        created=created,
        author=author or None,
    )


def _info_fields(info: Tag) -> dict[str, Tag]:
    """`div.info` rows: label ("Wnioskodawca") -> the value cell."""
    fields: dict[str, Tag] = {}
    for row in info.select("div.row"):
        cells = row.find_all("div", recursive=False)
        if len(cells) >= 2:
            fields[_text(cells[0]).rstrip(":")] = cells[1]
    return fields


def _sejm_reference(soup: BeautifulSoup) -> tuple[str | None, str | None]:
    for link in soup.select("ul.cbp_tmtimeline a[href]"):
        href = _href(link)
        if "sejm.gov.pl" not in href:
            continue
        ids = parse_qs(urlparse(href).query).get("Id", [])
        return href, (ids[0] if ids else None)
    return None, None


def _links_text(cell: Tag | None) -> tuple[str, ...]:
    if cell is None:
        return ()
    return tuple(_text(a) for a in cell.find_all("a") if _text(a))


def _first_href(cell: Tag) -> str | None:
    link = cell.find("a")
    return _href(link) or None if isinstance(link, Tag) else None


def _href(tag: Tag) -> str:
    value: Any = tag.get("href")
    if isinstance(value, list):
        return str(value[0]) if value else ""
    return str(value) if value else ""


def _text(tag: Tag | None) -> str:
    return " ".join(tag.get_text(" ").split()) if tag is not None else ""


def _own_text(tag: Tag) -> str:
    """Text of the element without its child elements (the folder name before its dates)."""
    return " ".join(" ".join(s for s in tag.find_all(string=True, recursive=False)).split())


def _date_after_colon(text: str) -> date | None:
    return _parse_date(text.rsplit(":", 1)[-1]) if ":" in text else None


def _parse_date(text: str) -> date | None:
    text = text.strip()
    if not text:
        return None
    try:
        return datetime.strptime(text, "%d-%m-%Y").date()
    except ValueError:
        return None
