"""LlmAnalyzer's per-bill work on the OpenAI SDK (Responses API, structured outputs).

Everything but `triage`: the full analysis, amendments, filed-document digests and joint
comparisons — `count_input_tokens` too, since it exists only to guard `analyze`'s cost. Which of
these actually run here, as against Claude, is `llm_hybrid.py`'s decision, made per call kind
(`llm_*_model` in settings): this class only has to answer honestly for whichever it is asked.
The full analysis was measured against Claude Opus 5 on 26 real prints and one scan before the
switch (docs/llm-cost.md): 96% agreement on relevance, zero missed bills, ~10x cheaper.
"""

import json
import logging
from collections.abc import Callable, Iterator, Sequence
from datetime import UTC, datetime
from hashlib import sha256
from typing import Any, Literal, NotRequired, TypedDict, TypeVar

import openai
import tiktoken
from openai.types.responses.response import Response
from openai.types.responses.response_input_file_param import ResponseInputFileParam
from openai.types.responses.response_input_message_content_list_param import (
    ResponseInputMessageContentListParam,
)
from openai.types.responses.response_input_param import ResponseInputParam
from openai.types.responses.response_input_text_param import ResponseInputTextParam
from pydantic import BaseModel, ValidationError

from lexinform.adapters.llm_prompts import (
    PROMPT_VERSION,
    build_amendments_prompt,
    build_joint_prompt,
    build_supplement_prompt,
    build_user_prompt,
    gpt51_amendments_system_prompt,
    gpt51_joint_system_prompt,
    gpt51_supplement_system_prompt,
    gpt51_system_prompt,
)
from lexinform.adapters.review_prompts import (
    REVIEW_PROMPT_VERSION,
    REVIEW_SCHEMA,
    review_prompt,
    review_system,
)
from lexinform.analysis_records import RecordFactory, UsageFields
from lexinform.errors import BatchNotSubmittedError, LlmContextExceededError, LlmUnavailableError
from lexinform.models import (
    Amendments,
    AmendmentsContext,
    AmendmentSourceEvidence,
    AmendmentsRecord,
    Analysis,
    AnalysisRecord,
    BatchRequest,
    BatchResult,
    BatchStatus,
    BillContext,
    DocumentDigest,
    JointComparison,
    JointContext,
    JointRecord,
    ReviewContext,
    ScannedDocument,
    SupplementContext,
    SupplementRecord,
)
from lexinform.models.batch import BatchAnswer, batch_output_model
from lexinform.models.report import CallKind
from lexinform.pricing import estimate_batch_reservation
from lexinform.settings import OpenAiEffort

log = logging.getLogger(__name__)

_T = TypeVar("_T", bound=BaseModel)


class LlmError(RuntimeError):
    """Per-bill LLM failure (refusal, truncated output, bad request for this input)."""


class LlmFatalError(LlmUnavailableError):
    """Systemic failure that will not go away by moving to the next bill: auth, permissions,
    rate limits, connection problems, server errors, missing credentials."""


# Every schema below mirrors its `models.py` counterpart field for field; strict Structured
# Outputs takes no `$ref` to a pydantic-generated schema without the same by-hand adjustments
# (every property required, `additionalProperties: false` at every level), so these are kept by
# hand like the prompts' own "## Output fields" sections already are, rather than through a
# converter that would still need the same care to get right and would hide it in a second place.
_ANALYSIS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "relevant": {"type": "boolean"},
        "score": {"type": "integer"},
        "category": {
            "type": "string",
            "enum": ["legal_stay", "employment", "social", "indirect", "marginal", "none"],
        },
        "summary": {"type": "string"},
        "key_changes": {"type": "array", "items": {"type": "string"}},
        "affected_groups": {"type": "array", "items": {"type": "string"}},
        "practical_impact": {"type": "string"},
        "effective_date": {"type": ["string", "null"]},
        "confidence": {"type": "number"},
        "rationale": {"type": "string"},
        "mnemonic_candidate": {"type": "string"},
        "mnemonic_fallback": {"type": "string"},
        "mnemonic_basis": {"type": "string"},
        "mnemonic_language": {"type": "string"},
        "changes_since_previous": {"type": "array", "items": {"type": "string"}},
    },
    "required": [
        "relevant",
        "score",
        "category",
        "summary",
        "key_changes",
        "affected_groups",
        "practical_impact",
        "effective_date",
        "confidence",
        "rationale",
        "mnemonic_candidate",
        "mnemonic_fallback",
        "mnemonic_basis",
        "mnemonic_language",
        "changes_since_previous",
    ],
    "additionalProperties": False,
}

_AMENDMENTS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "summary": {"type": "string"},
        "changes": {"type": "array", "items": {"type": "string"}},
        "affects_foreigners": {"type": "boolean"},
        "confidence": {"type": "number"},
        "source_evidence": {
            "anyOf": [
                {"type": "null"},
                AmendmentSourceEvidence.model_json_schema(),
            ]
        },
    },
    "required": ["summary", "changes", "affects_foreigners", "confidence", "source_evidence"],
    "additionalProperties": False,
}

_DOCUMENT_DIGEST_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "summary": {"type": "string"},
        "points": {"type": "array", "items": {"type": "string"}},
        "supports": {"type": ["boolean", "null"]},
        "affects_foreigners": {"type": "boolean"},
        "confidence": {"type": "number"},
    },
    "required": ["summary", "points", "supports", "affects_foreigners", "confidence"],
    "additionalProperties": False,
}

_JOINT_COMPARISON_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "same_substance": {"type": "boolean"},
        "summary": {"type": "string"},
        "differences": {"type": "array", "items": {"type": "string"}},
        "confidence": {"type": "number"},
    },
    "required": ["same_substance", "summary", "differences", "confidence"],
    "additionalProperties": False,
}


class OpenAiAnalyzer:
    def __init__(
        self,
        client: Callable[[], openai.OpenAI],
        *,
        model: str = "gpt-5.1",
        output_language: str = "ru",
        effort: OpenAiEffort = "medium",
        max_output_tokens: int = 8000,
        clock: Callable[[], datetime] = lambda: datetime.now(UTC),
    ) -> None:
        """`client` is a factory, not a built client: the openai SDK validates credentials at
        construction (unlike anthropic's, which only fails at the first real call), so building
        it eagerly would demand an API key from every command that merely wires the container —
        `/forget`, `/status`, a dry run over a quiet Sejm — never mind that this one never calls
        the model. Built once, on first actual use."""
        self._client_factory = client
        self._client: openai.OpenAI | None = None
        self._model = model
        self._effort = effort
        self._max_output_tokens = max_output_tokens
        self._clock = clock
        self._language = output_language
        self._system = gpt51_system_prompt(output_language)

    @property
    def _resolved_client(self) -> openai.OpenAI:
        if self._client is None:
            self._client = self._client_factory()
        return self._client

    def analyze(self, ctx: BillContext) -> AnalysisRecord:
        analysis, usage = self._structured_call(
            system=self._system,
            user_prompt=build_user_prompt(ctx),
            scan=ctx.scan,
            schema_name="analysis",
            schema=_ANALYSIS_SCHEMA,
            output_model=Analysis,
        )
        log.info(
            "LLM analysed druk %s: relevant=%s score=%d in=%s (cached %s) out=%s",
            ctx.number,
            analysis.relevant,
            analysis.score,
            usage.input_tokens,
            usage.cached_tokens or 0,
            usage.output_tokens,
        )
        return self._records(usage).analysis(
            analysis,
            input_chars=len(ctx.text),
            truncated=ctx.truncated,
            text_source=ctx.text_source,
        )

    def summarize_amendments(self, ctx: AmendmentsContext) -> AmendmentsRecord:
        amendments, usage = self._structured_call(
            system=gpt51_amendments_system_prompt(self._language),
            user_prompt=build_amendments_prompt(ctx),
            scan=ctx.scan,
            schema_name="amendments",
            schema=_AMENDMENTS_SCHEMA,
            output_model=Amendments,
        )
        log.info(
            "LLM summarised amendments of druk %s (%s): %d change(s), affects=%s in=%s out=%s",
            ctx.number,
            ctx.source_kind,
            len(amendments.changes),
            amendments.affects_foreigners,
            usage.input_tokens,
            usage.output_tokens,
        )
        return self._records(usage).amendments(amendments, source_kind=ctx.source_kind)

    def digest_supplement(self, ctx: SupplementContext) -> SupplementRecord:
        digest, usage = self._structured_call(
            system=gpt51_supplement_system_prompt(self._language),
            user_prompt=build_supplement_prompt(ctx),
            scan=ctx.scan,
            schema_name="document_digest",
            schema=_DOCUMENT_DIGEST_SCHEMA,
            output_model=DocumentDigest,
        )
        log.info(
            "LLM digested %s of druk %s: %d point(s), supports=%s affects=%s in=%s out=%s",
            ctx.source_kind,
            ctx.number,
            len(digest.points),
            digest.supports,
            digest.affects_foreigners,
            usage.input_tokens,
            usage.output_tokens,
        )
        return self._records(usage).supplement(
            digest, title=ctx.document_title, source_kind=ctx.source_kind
        )

    def compare_joint(self, ctx: JointContext) -> JointRecord:
        comparison, usage = self._structured_call(
            system=gpt51_joint_system_prompt(self._language),
            user_prompt=build_joint_prompt(ctx),
            scan=None,
            schema_name="joint_comparison",
            schema=_JOINT_COMPARISON_SCHEMA,
            output_model=JointComparison,
        )
        log.info(
            "LLM compared druk %s with %s: same_substance=%s, %d difference(s) in=%s out=%s",
            ctx.subject.number,
            ", ".join(other.number for other in ctx.others),
            comparison.same_substance,
            len(comparison.differences),
            usage.input_tokens,
            usage.output_tokens,
        )
        return self._records(usage).joint(
            comparison,
            compared_with=[other.number for other in ctx.others],
        )

    def _records(self, usage: _Usage) -> RecordFactory:
        return RecordFactory(self._model, PROMPT_VERSION, self._clock(), usage.fields())

    def count_input_tokens(self, ctx: BillContext) -> int | None:
        """A local encoding, not a call: OpenAI has no free-standing token-counting endpoint, and
        asking the model to spend a request just to learn a number defeats the guard it feeds.
        Approximate for a scan (page-image tokens are not text tokens at all — the per-bill guard
        prices those from the page count instead, see `pricing.estimate_scan_cost`)."""
        try:
            encoding = tiktoken.encoding_for_model(self._model)
        except Exception as exc:
            log.warning("no tiktoken encoding for %s (%s); estimating", self._model, _short(exc))
            return None
        if ctx.scan is not None:
            return None
        return len(encoding.encode(self._system)) + len(encoding.encode(build_user_prompt(ctx)))

    def prepare_request(self, request: BatchRequest) -> BatchRequest:
        if request.payload_json is not None:
            return request
        ctx = request.ctx
        model = request.model or self._model
        scan = (
            ctx.scan
            if isinstance(ctx, (BillContext, SupplementContext, AmendmentsContext))
            else None
        )
        if isinstance(ctx, BillContext):
            system, prompt = self._system, build_user_prompt(ctx)
        elif isinstance(ctx, AmendmentsContext):
            system, prompt = (
                gpt51_amendments_system_prompt(self._language),
                build_amendments_prompt(ctx),
            )
        elif isinstance(ctx, SupplementContext):
            system, prompt = (
                gpt51_supplement_system_prompt(self._language),
                build_supplement_prompt(ctx),
            )
        elif isinstance(ctx, ReviewContext):
            system, prompt = review_system(self._language), review_prompt(ctx)
        else:
            system, prompt = gpt51_joint_system_prompt(self._language), build_joint_prompt(ctx)
        schema_name, schema = {
            "analysis": ("analysis", _ANALYSIS_SCHEMA),
            "reanalysis": ("analysis", _ANALYSIS_SCHEMA),
            "amendments": ("amendments", _AMENDMENTS_SCHEMA),
            "supplement": ("document_digest", _DOCUMENT_DIGEST_SCHEMA),
            "joint": ("joint_comparison", _JOINT_COMPARISON_SCHEMA),
            "consultation_review": ("document_review", REVIEW_SCHEMA),
            "act_application": ("document_review", REVIEW_SCHEMA),
        }[request.call_kind]
        payload = {
            "custom_id": request.custom_id,
            "method": "POST",
            "url": "/v1/responses",
            "body": {
                "model": model,
                **_cache_options(model, system, schema_name),
                "reasoning": None if self._effort == "none" else {"effort": self._effort},
                "max_output_tokens": self._max_output_tokens,
                "input": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": _content(prompt, scan)},
                ],
                "text": {
                    "format": {
                        "type": "json_schema",
                        "name": schema_name,
                        "schema": schema,
                        "strict": True,
                    }
                },
            },
        }
        tokens = self.count_input_tokens(ctx) if isinstance(ctx, BillContext) else None
        return request.model_copy(
            update={
                "payload_json": json.dumps(payload, ensure_ascii=False),
                "model": model,
                "prompt_version": REVIEW_PROMPT_VERSION
                if isinstance(ctx, ReviewContext)
                else PROMPT_VERSION,
                "estimated_cost_usd": estimate_batch_reservation(
                    model,
                    counted_tokens=tokens,
                    prompt_chars=len(prompt),
                    system_chars=len(system),
                    scan_pages=scan.pages if scan is not None else 0,
                    max_output_tokens=self._max_output_tokens,
                ),
            }
        )

    def submit(self, requests: Sequence[BatchRequest]) -> str:
        """File one Batches API submission against `/v1/responses` — half of the synchronous
        price, answered within 24h at the most. One JSONL line per request, uploaded as a file
        first: the Batches API takes a file id, never the requests inline."""
        lines = [self.prepare_request(req).payload_json or "{}" for req in requests]
        payload = ("\n".join(lines) + "\n").encode("utf-8")
        try:
            uploaded = self._resolved_client.files.create(
                file=("batch.jsonl", payload, "application/jsonl"), purpose="batch"
            )
            batch = self._resolved_client.batches.create(
                input_file_id=uploaded.id, endpoint="/v1/responses", completion_window="24h"
            )
        except (
            openai.AuthenticationError,
            openai.PermissionDeniedError,
            openai.NotFoundError,
            openai.RateLimitError,
        ) as exc:
            raise BatchNotSubmittedError(f"{type(exc).__name__}: {_short(exc)}") from exc
        except (
            openai.InternalServerError,
            openai.APIConnectionError,
        ) as exc:
            raise LlmFatalError(f"{type(exc).__name__}: {_short(exc)}") from exc
        except openai.APIError as exc:
            raise LlmFatalError(f"{type(exc).__name__}: {_short(exc)}") from exc
        log.info("submitted batch %s of %d request(s)", batch.id, len(lines))
        return batch.id

    def poll(self, batch_id: str) -> BatchStatus:
        try:
            batch = self._resolved_client.batches.retrieve(batch_id)
        except (
            openai.NotFoundError,
            openai.AuthenticationError,
            openai.PermissionDeniedError,
            openai.RateLimitError,
            openai.InternalServerError,
            openai.APIConnectionError,
        ) as exc:
            raise LlmFatalError(f"{type(exc).__name__}: {_short(exc)}") from exc
        if batch.status in ("completed", "expired", "cancelled"):
            return "ended"
        if batch.status == "failed":
            return "failed"
        return "submitted"

    def fetch_results(self, batch_id: str, kind: CallKind = "analysis") -> Iterator[BatchResult]:
        try:
            batch = self._resolved_client.batches.retrieve(batch_id)
            files = [
                self._resolved_client.files.content(file_id)
                for file_id in (batch.output_file_id, batch.error_file_id)
                if file_id is not None
            ]
        except (
            openai.NotFoundError,
            openai.AuthenticationError,
            openai.PermissionDeniedError,
            openai.RateLimitError,
            openai.InternalServerError,
            openai.APIConnectionError,
        ) as exc:
            raise LlmFatalError(f"{type(exc).__name__}: {_short(exc)}") from exc
        for content in files:
            for line in content.text.splitlines():
                if line.strip():
                    try:
                        decoded = json.loads(line)
                    except json.JSONDecodeError:
                        log.warning("batch %s contains an invalid JSONL line", batch_id)
                        continue
                    if not isinstance(decoded, dict) or not isinstance(
                        decoded.get("custom_id"), str
                    ):
                        log.warning("batch %s contains a result without custom_id", batch_id)
                        continue
                    yield self._batch_result_line(decoded, batch_output_model(kind))

    def forget(self, batch_id: str) -> None:
        """OpenAI has no batch delete; the poller excludes consumed items using persisted state."""

    def _batch_result_line(
        self, line: dict[str, Any], output_model: type[BatchAnswer]
    ) -> BatchResult:
        custom_id = str(line["custom_id"])
        error = line.get("error")
        if error is not None:
            return _batch_error(custom_id, error)
        response_data = line.get("response")
        body = response_data.get("body") if isinstance(response_data, dict) else None
        if body is None:
            return BatchResult(custom_id=custom_id, error="batch item carries no response")
        if isinstance(body, dict) and body.get("error") is not None:
            return _batch_error(custom_id, body["error"])
        try:
            response = Response.model_validate(body)
        except ValidationError as exc:
            return BatchResult(custom_id=custom_id, error=str(exc))
        usage = _usage_of(response)
        answer = BatchResult(
            custom_id=custom_id,
            model=response.model,
            input_tokens=usage.input_tokens,
            output_tokens=usage.output_tokens,
            cache_read_input_tokens=usage.cached_tokens,
            cache_creation_input_tokens=0,
        )
        try:
            if response.status != "completed":
                raise LlmError(f"response is {response.status}")
            analysis = _parsed_output(response, output_model)
        except (LlmError, ValidationError) as exc:
            return answer.model_copy(update={"error": str(exc)})
        return answer.model_copy(update={"answer": analysis})

    def _structured_call(
        self,
        *,
        system: str,
        user_prompt: str,
        scan: ScannedDocument | None,
        schema_name: str,
        schema: dict[str, Any],
        output_model: type[_T],
    ) -> tuple[_T, _Usage]:
        input_messages: ResponseInputParam = [
            {"role": "system", "content": system},
            {"role": "user", "content": _content(user_prompt, scan)},
        ]
        try:
            response = self._resolved_client.responses.create(
                model=self._model,
                **_cache_options(self._model, system, schema_name),
                reasoning=None if self._effort == "none" else {"effort": self._effort},
                max_output_tokens=self._max_output_tokens,
                input=input_messages,
                text={
                    "format": {
                        "type": "json_schema",
                        "name": schema_name,
                        "schema": schema,
                        "strict": True,
                    }
                },
            )
        except (
            openai.AuthenticationError,
            openai.PermissionDeniedError,
            openai.NotFoundError,  # unknown model id: would fail for every bill
            openai.RateLimitError,
            openai.InternalServerError,
            openai.APIConnectionError,
        ) as exc:
            raise LlmFatalError(f"{type(exc).__name__}: {_short(exc)}") from exc
        except openai.BadRequestError as exc:
            if _is_context_problem(str(exc)) or _is_context_problem(str(exc.body)):
                raise LlmContextExceededError(f"BadRequestError: {_short(exc)}") from exc
            raise LlmFatalError(f"BadRequestError: {_short(exc)}") from exc
        except openai.APIError as exc:
            raise LlmError(f"{type(exc).__name__}: {_short(exc)}") from exc

        if response.status == "incomplete":
            reason = getattr(response.incomplete_details, "reason", None)
            raise LlmError(f"response incomplete: {reason}")
        return _parsed_output(response, output_model), _usage_of(response)


def _content(
    user_prompt: str, scan: ScannedDocument | None
) -> ResponseInputMessageContentListParam:
    """The user turn: a scanned document goes in front of the prompt, so the model reads its
    pages; a readable one is already inside the prompt as text."""
    blocks: ResponseInputMessageContentListParam = []
    if scan is not None:
        blocks.append(
            ResponseInputFileParam(
                type="input_file",
                filename="document.pdf",
                file_data=f"data:{scan.media_type};base64,{scan.data}",
            )
        )
    blocks.append(ResponseInputTextParam(type="input_text", text=user_prompt))
    return blocks


class _Usage(BaseModel):
    input_tokens: int | None
    output_tokens: int | None
    cached_tokens: int | None

    def fields(self) -> UsageFields:
        return UsageFields(
            input_tokens=self.input_tokens,
            output_tokens=self.output_tokens,
            cache_read_input_tokens=self.cached_tokens,
            cache_creation_input_tokens=0,
        )


class _CacheOptions(TypedDict):
    prompt_cache_key: str
    prompt_cache_retention: NotRequired[Literal["24h"]]


def _cache_options(model: str, system: str, schema_name: str) -> _CacheOptions:
    options: _CacheOptions = {
        "prompt_cache_key": f"lexinform:{schema_name}:{sha256(system.encode()).hexdigest()[:16]}"
    }
    if model == "gpt-5.1" or model.startswith("gpt-5.1-"):
        options["prompt_cache_retention"] = "24h"
    return options


def _usage_of(response: Any) -> _Usage:
    usage = response.usage
    details = getattr(usage, "input_tokens_details", None)
    total = getattr(usage, "input_tokens", None)
    cached = getattr(details, "cached_tokens", None)
    # OpenAI includes cached tokens in input_tokens; our cost model prices disjoint categories.
    return _Usage(
        input_tokens=max(0, total - (cached or 0)) if total is not None else None,
        output_tokens=getattr(usage, "output_tokens", None),
        cached_tokens=cached,
    )


def _parsed_output[T: BaseModel](response: Any, output_model: type[T]) -> T:
    for item in getattr(response, "output", []) or []:
        if getattr(item, "type", None) == "refusal":
            raise LlmError("model refused the request")
        if getattr(item, "type", None) == "message":
            for block in item.content:
                if getattr(block, "type", None) == "output_text":
                    return output_model.model_validate_json(block.text)
                if getattr(block, "type", None) == "refusal":
                    raise LlmError("model refused the request")
    raise LlmError("model returned no parsable structured output")


_CONTEXT_PROBLEM_MARKERS = (
    "context_length_exceeded",
    "context_window_exceeded",
    "exceeds the context",
    "maximum context length",
    "input is too long",
    "too many tokens",
    "input tokens exceed the configured limit",
)


def _is_context_problem(message: str) -> bool:
    return any(marker in message.lower() for marker in _CONTEXT_PROBLEM_MARKERS)


def _batch_error(custom_id: str, error: object) -> BatchResult:
    return BatchResult(
        custom_id=custom_id, error=str(error), context_exceeded=_is_context_problem(str(error))
    )


def _short(exc: BaseException, limit: int = 300) -> str:
    text = str(exc).strip().splitlines()[0] if str(exc).strip() else type(exc).__name__
    return text[:limit]
