"""LlmAnalyzer implementation on top of the official Anthropic SDK (structured outputs)."""

import json
import logging
from collections.abc import Callable, Iterator, Sequence
from datetime import UTC, datetime
from typing import Any, Protocol, cast

import anthropic
from anthropic import transform_schema
from anthropic.lib._parse._response import parse_response
from anthropic.types.json_output_format_param import JSONOutputFormatParam
from anthropic.types.messages.batch_create_params import Request as AnthropicBatchRequest
from pydantic import TypeAdapter, ValidationError

from lexinform.adapters.llm_prompts import (
    PROMPT_VERSION,
    amendments_system_prompt,
    build_amendments_prompt,
    build_change_review_prompt,
    build_joint_prompt,
    build_supplement_prompt,
    build_triage_prompt,
    build_user_prompt,
    change_review_system_prompt,
    joint_system_prompt,
    supplement_system_prompt,
    system_prompt,
    triage_system_prompt,
)
from lexinform.adapters.review_prompts import REVIEW_PROMPT_VERSION, review_prompt, review_system
from lexinform.analysis_records import RecordFactory, UsageFields
from lexinform.errors import BatchNotSubmittedError, LlmUnavailableError
from lexinform.models import (
    Amendments,
    AmendmentsContext,
    AmendmentsRecord,
    Analysis,
    AnalysisRecord,
    BatchRequest,
    BatchResult,
    BatchStatus,
    BillContext,
    ChangeContext,
    ChangeReview,
    ChangeReviewRecord,
    DocumentDigest,
    JointComparison,
    JointContext,
    JointRecord,
    ReviewContext,
    ScannedDocument,
    SupplementContext,
    SupplementRecord,
    Triage,
    TriageContext,
    TriageRecord,
)
from lexinform.models.batch import BatchAnswer, batch_output_model
from lexinform.models.report import CallKind
from lexinform.pricing import estimate_batch_reservation
from lexinform.settings import Effort

log = logging.getLogger(__name__)


class LlmError(RuntimeError):
    """Per-bill LLM failure (refusal, truncated output, bad request for this input)."""


class LlmFatalError(LlmUnavailableError):
    """Systemic failure that will not go away by moving to the next bill: auth, permissions,
    rate limits, connection problems, server errors, missing credentials."""


class _ParsedMessageLike(Protocol):
    """The subset of anthropic.ParsedMessage we use; lets tests stub the client."""

    @property
    def parsed_output(self) -> Any: ...

    @property
    def stop_reason(self) -> Any: ...

    @property
    def usage(self) -> Any: ...


class AnthropicAnalyzer:
    def __init__(
        self,
        client: anthropic.Anthropic,
        *,
        model: str = "claude-opus-5-5",
        triage_model: str | None = None,
        output_language: str = "ru",
        effort: Effort = "medium",
        max_tokens: int = 4000,
        clock: Callable[[], datetime] = lambda: datetime.now(UTC),
    ) -> None:
        self._client = client
        self._model = model
        self._language = output_language
        self._triage_model = triage_model or model
        self._effort = effort
        self._max_tokens = max_tokens
        self._clock = clock
        self._system = system_prompt(output_language)
        self._triage_system = triage_system_prompt(output_language)
        self._change_review_system = change_review_system_prompt(output_language)
        self._amendments_system = amendments_system_prompt(output_language)
        self._supplement_system = supplement_system_prompt(output_language)
        self._joint_system = joint_system_prompt(output_language)
        self._analysis_format = _json_output_format(Analysis)

    def analyze(self, ctx: BillContext) -> AnalysisRecord:
        response = self._parse(
            self._model,
            self._system,
            build_user_prompt(ctx),
            Analysis,
            thinking=True,
            scan=ctx.scan,
        )
        analysis = response.parsed_output
        if not isinstance(analysis, Analysis):
            raise LlmError("model returned no parsable structured output")
        usage = getattr(response, "usage", None)
        log.info(
            "LLM analysed druk %s: relevant=%s score=%d in=%s (cached %d) out=%s",
            ctx.number,
            analysis.relevant,
            analysis.score,
            _usage_int(usage, "input_tokens"),
            _usage_int(usage, "cache_read_input_tokens") or 0,
            _usage_int(usage, "output_tokens"),
        )
        return self._records(usage).analysis(
            analysis,
            input_chars=len(ctx.text),
            truncated=ctx.truncated,
            text_source=ctx.text_source,
        )

    def count_input_tokens(self, ctx: BillContext) -> int | None:
        """The tokenizer's own count of what `analyze` would send, without sending it.

        The structured-output schema of the request is not counted: it is about a thousand
        tokens, it is cached, and this number exists to decide whether a document is too
        expensive to read at all. A failure is not one — the caller falls back to estimating
        from the text."""
        try:
            counted = self._client.messages.count_tokens(
                model=self._model,
                system=[{"type": "text", "text": self._system}],
                messages=[{"role": "user", "content": _content(build_user_prompt(ctx), ctx.scan)}],
            )
        except Exception as exc:
            log.warning("tokens of druk %s not counted (%s); estimating", ctx.number, _short(exc))
            return None
        return int(counted.input_tokens)

    def triage(self, ctx: TriageContext) -> TriageRecord:
        """The cheap first pass on excerpts; may run on a smaller model than the analysis."""
        response = self._parse(
            self._triage_model,
            self._triage_system,
            build_triage_prompt(ctx),
            Triage,
            thinking=False,
            scan=ctx.scan,
        )
        triage = response.parsed_output
        if not isinstance(triage, Triage):
            raise LlmError("model returned no parsable structured output")
        usage = getattr(response, "usage", None)
        log.info(
            "LLM triaged druk %s: affects_foreigners=%s confidence=%.2f in=%s out=%s",
            ctx.number,
            triage.affects_foreigners,
            triage.confidence,
            _usage_int(usage, "input_tokens"),
            _usage_int(usage, "output_tokens"),
        )
        return TriageRecord(
            triage=triage,
            model=self._triage_model,
            prompt_version=PROMPT_VERSION,
            **_usage_fields(usage),
        )

    def review_change(self, ctx: ChangeContext) -> ChangeReviewRecord:
        """Whether a new text's changed passages alter the analysis; on the triage model."""
        response = self._parse(
            self._triage_model,
            self._change_review_system,
            build_change_review_prompt(ctx),
            ChangeReview,
            thinking=False,
        )
        review = response.parsed_output
        if not isinstance(review, ChangeReview):
            raise LlmError("model returned no parsable structured output")
        usage = getattr(response, "usage", None)
        log.info(
            "LLM reviewed the changes of %s: material=%s confidence=%.2f in=%s out=%s",
            ctx.number,
            review.material,
            review.confidence,
            _usage_int(usage, "input_tokens"),
            _usage_int(usage, "output_tokens"),
        )
        return ChangeReviewRecord(
            review=review,
            model=self._triage_model,
            prompt_version=PROMPT_VERSION,
            **_usage_fields(usage),
        )

    def summarize_amendments(self, ctx: AmendmentsContext) -> AmendmentsRecord:
        """What a set of amendments changes; runs on the analysis model, with thinking."""
        response = self._parse(
            self._model,
            self._amendments_system,
            build_amendments_prompt(ctx),
            Amendments,
            thinking=True,
            scan=ctx.scan,
        )
        amendments = response.parsed_output
        if not isinstance(amendments, Amendments):
            raise LlmError("model returned no parsable structured output")
        usage = getattr(response, "usage", None)
        log.info(
            "LLM summarised amendments of druk %s (%s): %d change(s), affects=%s in=%s out=%s",
            ctx.number,
            ctx.source_kind,
            len(amendments.changes),
            amendments.affects_foreigners,
            _usage_int(usage, "input_tokens"),
            _usage_int(usage, "output_tokens"),
        )
        return self._records(usage).amendments(amendments, source_kind=ctx.source_kind)

    def digest_supplement(self, ctx: SupplementContext) -> SupplementRecord:
        """What a document filed to the print says about the bill; the analysis model, thinking."""
        response = self._parse(
            self._model,
            self._supplement_system,
            build_supplement_prompt(ctx),
            DocumentDigest,
            thinking=True,
            scan=ctx.scan,
        )
        digest = response.parsed_output
        if not isinstance(digest, DocumentDigest):
            raise LlmError("model returned no parsable structured output")
        usage = getattr(response, "usage", None)
        log.info(
            "LLM digested %s of druk %s: %d point(s), supports=%s affects=%s in=%s out=%s",
            ctx.source_kind,
            ctx.number,
            len(digest.points),
            digest.supports,
            digest.affects_foreigners,
            _usage_int(usage, "input_tokens"),
            _usage_int(usage, "output_tokens"),
        )
        return self._records(usage).supplement(
            digest, title=ctx.document_title, source_kind=ctx.source_kind
        )

    def compare_joint(self, ctx: JointContext) -> JointRecord:
        """How one print of a jointly considered group differs from the others.

        The analysis model with thinking, on a prompt of a few descriptions: the input is a
        thousandth of a bill's text, and the question — telling two bills on one subject apart —
        is the kind a cheap model answers by inventing a difference.
        """
        response = self._parse(
            self._model,
            self._joint_system,
            build_joint_prompt(ctx),
            JointComparison,
            thinking=True,
        )
        comparison = response.parsed_output
        if not isinstance(comparison, JointComparison):
            raise LlmError("model returned no parsable structured output")
        usage = getattr(response, "usage", None)
        log.info(
            "LLM compared druk %s with %s: same_substance=%s, %d difference(s) in=%s out=%s",
            ctx.subject.number,
            ", ".join(other.number for other in ctx.others),
            comparison.same_substance,
            len(comparison.differences),
            _usage_int(usage, "input_tokens"),
            _usage_int(usage, "output_tokens"),
        )
        return self._records(usage).joint(
            comparison,
            compared_with=[other.number for other in ctx.others],
        )

    def _records(self, usage: Any) -> RecordFactory:
        return RecordFactory(self._model, PROMPT_VERSION, self._clock(), _usage_fields(usage))

    def prepare_request(self, request: BatchRequest) -> BatchRequest:
        if request.payload_json is not None:
            return request
        ctx = request.ctx
        model = request.model or self._model
        scan = (
            ctx.scan
            if isinstance(ctx, (BillContext, SupplementContext, AmendmentsContext))
            else None
        )
        if isinstance(ctx, BillContext):
            system, prompt = self._system, build_user_prompt(ctx)
        elif isinstance(ctx, AmendmentsContext):
            system, prompt = self._amendments_system, build_amendments_prompt(ctx)
        elif isinstance(ctx, SupplementContext):
            system, prompt = self._supplement_system, build_supplement_prompt(ctx)
        elif isinstance(ctx, ReviewContext):
            system, prompt = review_system(self._language), review_prompt(ctx)
        else:
            system, prompt = self._joint_system, build_joint_prompt(ctx)
        payload: AnthropicBatchRequest = {
            "custom_id": request.custom_id,
            "params": {
                "model": model,
                "max_tokens": self._max_tokens,
                "system": [{"type": "text", "text": system}],
                "messages": [{"role": "user", "content": _content(prompt, scan)}],
                "thinking": {"type": "adaptive"},
                "output_config": {
                    "effort": self._effort,
                    "format": _json_output_format(batch_output_model(request.call_kind)),
                },
            },
        }
        tokens = self.count_input_tokens(ctx) if isinstance(ctx, BillContext) else None
        return request.model_copy(
            update={
                "payload_json": json.dumps(payload, ensure_ascii=False),
                "model": model,
                "prompt_version": REVIEW_PROMPT_VERSION
                if isinstance(ctx, ReviewContext)
                else PROMPT_VERSION,
                "estimated_cost_usd": estimate_batch_reservation(
                    model,
                    counted_tokens=tokens,
                    prompt_chars=len(prompt),
                    system_chars=len(system),
                    scan_pages=scan.pages if scan is not None else 0,
                    max_output_tokens=self._max_tokens,
                ),
            }
        )

    def submit(self, requests: Sequence[BatchRequest]) -> str:
        """File one Messages Batches API submission — half of `analyze`'s price, answered within
        a run or two rather than at once. `output_config` is built the way `messages.parse`
        builds it internally: the Batches API takes raw request params, with no `.parse()`
        convenience of its own, but the structured-output feature underneath is the same one."""
        batch_requests = [
            cast(AnthropicBatchRequest, json.loads(self.prepare_request(req).payload_json or "{}"))
            for req in requests
        ]
        try:
            batch = self._client.messages.batches.create(requests=batch_requests)
        except (
            anthropic.AuthenticationError,
            anthropic.PermissionDeniedError,
            anthropic.NotFoundError,
            anthropic.RateLimitError,
        ) as exc:
            raise BatchNotSubmittedError(f"{type(exc).__name__}: {_short(exc)}") from exc
        except (
            anthropic.InternalServerError,
            anthropic.APIConnectionError,
        ) as exc:
            raise LlmFatalError(f"{type(exc).__name__}: {_short(exc)}") from exc
        except anthropic.APIError as exc:
            raise LlmFatalError(f"{type(exc).__name__}: {_short(exc)}") from exc
        log.info("submitted batch %s of %d request(s)", batch.id, len(batch_requests))
        return batch.id

    def poll(self, batch_id: str) -> BatchStatus:
        try:
            batch = self._client.messages.batches.retrieve(batch_id)
        except (
            anthropic.NotFoundError,
            anthropic.AuthenticationError,
            anthropic.PermissionDeniedError,
            anthropic.RateLimitError,
            anthropic.InternalServerError,
            anthropic.APIConnectionError,
        ) as exc:
            raise LlmFatalError(f"{type(exc).__name__}: {_short(exc)}") from exc
        return "ended" if batch.processing_status == "ended" else "submitted"

    def fetch_results(self, batch_id: str, kind: CallKind = "analysis") -> Iterator[BatchResult]:
        try:
            for item in self._client.messages.batches.results(batch_id):
                yield self._batch_result(item, batch_output_model(kind))
        except (
            anthropic.NotFoundError,
            anthropic.AuthenticationError,
            anthropic.PermissionDeniedError,
            anthropic.RateLimitError,
            anthropic.InternalServerError,
            anthropic.APIConnectionError,
        ) as exc:
            raise LlmFatalError(f"{type(exc).__name__}: {_short(exc)}") from exc

    def forget(self, batch_id: str) -> None:
        try:
            self._client.messages.batches.delete(batch_id)
        except anthropic.NotFoundError:
            return
        except (
            anthropic.AuthenticationError,
            anthropic.PermissionDeniedError,
            anthropic.RateLimitError,
            anthropic.InternalServerError,
            anthropic.APIConnectionError,
        ) as exc:
            raise LlmFatalError(f"{type(exc).__name__}: {_short(exc)}") from exc
        log.info("deleted collected batch %s", batch_id)

    def _batch_result(self, item: Any, output_model: type[BatchAnswer]) -> BatchResult:
        result = item.result
        if result.type != "succeeded":
            reason = result.type
            if result.type == "errored":
                reason = f"errored: {result.error.error.message}"
            return BatchResult(custom_id=item.custom_id, error=reason)
        message = result.message
        usage = message.usage
        answer = BatchResult(
            custom_id=item.custom_id,
            model=message.model,
            input_tokens=_usage_int(usage, "input_tokens"),
            output_tokens=_usage_int(usage, "output_tokens"),
            cache_read_input_tokens=_usage_int(usage, "cache_read_input_tokens"),
            cache_creation_input_tokens=_usage_int(usage, "cache_creation_input_tokens"),
        )
        if message.stop_reason in ("refusal", "max_tokens"):
            return answer.model_copy(update={"error": f"response stopped: {message.stop_reason}"})
        try:
            parsed: Any = parse_response(output_format=output_model, response=message)
        except ValidationError as exc:
            return answer.model_copy(update={"error": str(exc)})
        if not isinstance(parsed.parsed_output, output_model):
            return answer.model_copy(
                update={"error": "model returned no parsable structured output"}
            )
        return answer.model_copy(update={"answer": parsed.parsed_output})

    def _parse(
        self,
        model: str,
        system: str,
        user_prompt: str,
        output_format: type[Any],
        *,
        thinking: bool,
        scan: ScannedDocument | None = None,
    ) -> _ParsedMessageLike:
        """One structured-output request with the error classification shared by both passes.

        The analysis thinks at the configured effort; the triage sends no thinking settings, so the
        model's default applies (adaptive on Sonnet 5, none on Haiku 4.5, which rejects effort).
        A `scan` is the document itself, attached before the prompt so the model reads its pages:
        that is the only way to read the signed paper the Sejm files as images.
        """
        reasoning: dict[str, Any] = (
            {"thinking": {"type": "adaptive"}, "output_config": {"effort": self._effort}}
            if thinking
            else {}
        )
        try:
            response: _ParsedMessageLike = self._client.messages.parse(
                model=model,
                max_tokens=self._max_tokens,
                system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
                messages=[{"role": "user", "content": _content(user_prompt, scan)}],
                output_format=output_format,
                **reasoning,
            )
        except (
            anthropic.AuthenticationError,
            anthropic.PermissionDeniedError,
            anthropic.NotFoundError,  # unknown model id: would fail for every bill
            anthropic.RateLimitError,
            anthropic.InternalServerError,
            anthropic.APIConnectionError,
        ) as exc:
            raise LlmFatalError(f"{type(exc).__name__}: {_short(exc)}") from exc
        except anthropic.BadRequestError as exc:
            if _is_input_problem(exc):
                raise LlmError(f"BadRequestError: {_short(exc)}") from exc
            # Unsupported parameter, malformed schema, ...: a configuration problem, not this bill.
            raise LlmFatalError(f"BadRequestError: {_short(exc)}") from exc
        except TypeError as exc:
            # The SDK raises TypeError when no credentials can be resolved at request time.
            raise LlmFatalError(f"client misconfigured: {_short(exc)}") from exc
        except anthropic.APIError as exc:
            raise LlmError(f"{type(exc).__name__}: {_short(exc)}") from exc

        if response.stop_reason == "refusal":
            raise LlmError("model refused the request")
        if response.stop_reason == "max_tokens":
            raise LlmError("response truncated by max_tokens")
        return response


def _json_output_format(output_format: type[Any]) -> JSONOutputFormatParam:
    """The raw `output_config.format` `messages.parse` builds from `output_format=`, for the
    Batches API's plain request params, which take no `output_format=` shortcut of their own."""
    schema = TypeAdapter(output_format).json_schema()
    return JSONOutputFormatParam(type="json_schema", schema=transform_schema(schema))


def _content(user_prompt: str, scan: ScannedDocument | None) -> list[Any]:
    """The user turn: a scanned document goes in front of the prompt, so the model reads its
    pages; a readable one is already inside the prompt as text."""
    blocks: list[Any] = []
    if scan is not None:
        blocks.append(
            {
                "type": "document",
                "source": {
                    "type": "base64",
                    "media_type": scan.media_type,
                    "data": scan.data,
                },
            }
        )
    blocks.append({"type": "text", "text": user_prompt})
    return blocks


def _usage_fields(usage: Any) -> UsageFields:
    return UsageFields(
        input_tokens=_usage_int(usage, "input_tokens"),
        output_tokens=_usage_int(usage, "output_tokens"),
        cache_read_input_tokens=_usage_int(usage, "cache_read_input_tokens"),
        cache_creation_input_tokens=_usage_int(usage, "cache_creation_input_tokens"),
    )


def _usage_int(usage: Any, field: str) -> int | None:
    value = getattr(usage, field, None)
    return int(value) if isinstance(value, int) else None


_INPUT_PROBLEM_MARKERS = ("prompt is too long", "too many tokens", "exceeds the context")


def _is_input_problem(exc: Exception) -> bool:
    text = str(exc).lower()
    return any(marker in text for marker in _INPUT_PROBLEM_MARKERS)


def _short(exc: BaseException, limit: int = 300) -> str:
    text = str(exc).strip().splitlines()[0] if str(exc).strip() else type(exc).__name__
    return text[:limit]
