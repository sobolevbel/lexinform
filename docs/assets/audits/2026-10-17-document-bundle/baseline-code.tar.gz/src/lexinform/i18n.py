"""Static labels used by the Telegram formatter, keyed by output language.

Bill titles stay in Polish; only the surrounding UI text is localised. The LLM output
language is controlled separately (Settings.output_language) and normally matches.
"""

from dataclasses import dataclass, field

from lexinform.models import ApplicantType, Category


@dataclass(frozen=True)
class Labels:
    """Every piece of text the formatter can put around a bill, in one language.

    The fields follow the shape of a card: the Sejm's process, then the government's two earlier
    sources, then the replies. `update_headers` and `event_tags` are keyed by event key
    (`models.update_event`); `next_step_labels`, `typical_durations` and `no_action_labels` by
    phase key, with `urgent_step_labels` and `urgent_durations` consulted first for an
    urgent bill. `stage_labels` goes by `Stage.stage_type`, and `rcl_stage_labels`,
    `decision_labels` and `proposal_labels` by a lower-case fragment, first match winning; a value
    none of them knows passes through in Polish.
    """

    new_bill_header: str
    analysis_queued: str
    finished_bill_header: str
    update_header: str
    importance: str
    category: str
    about: str
    key_changes: str
    practical_impact: str
    affected: str
    effective_date: str
    effective_date_unknown: str
    stage: str
    applicant: str
    document_date: str
    print_number: str
    partial_text_note: str
    new_stages: str
    reading_stage: str
    process_closed: str
    process_passed: str
    process_not_enacted: str
    process_veto_sustained: str
    process_tribunal_ruled: str
    stage_veto_sustained: str
    link_sejm_project: str
    link_process: str
    link_pdf: str
    link_text_after3: str
    joint_prints: str
    joint_bill_header: str
    joint_bill_note: str
    joint_differs: str
    joint_same: str
    current_summary: str
    changes_since_previous: str
    card_part_superseded: str
    reanalyzed_note: str
    run_report_title: str
    tag_importance: str
    voting: str
    votes_for: str
    votes_against: str
    votes_abstain: str
    not_voting: str
    link_voting_pdf: str
    referred_to_committee: str
    no_print_yet: str
    received: str
    found_in_text: str
    representative: str
    signatories: str
    pre_print_stage: str
    pre_print_note: str
    consultation: str
    consultation_until: str
    consultation_closed_on: str
    consultation_closed_undated: str
    consultation_hint: str
    print_assigned: str
    process_withdrawn: str
    process_abandoned: str
    process_discontinued: str
    process_carried_over: str
    link_submission_pdf: str
    act_published_header: str
    journal: str
    published_on: str
    enters_into_force: str
    already_in_force_since: str
    entry_into_force_unknown: str
    partial_vacatio_note: str
    in_force_header: str
    in_force_header_dated: str
    in_force_since: str
    act_summary: str
    link_isap: str
    link_act_pdf: str
    tag_published: str
    tag_in_force: str
    consultation_deadline_header: str
    consultation_days_left: str
    consultation_last_day: str
    tag_consultations: str
    tag_consultation_results: str
    tag_term: str
    tag_ukraine: str
    consultation_link: str
    consultation_page: str
    action_now: str
    action_senate: str
    action_senate_many: str
    action_senate_pending: str
    action_senate_in_polish: str
    path: str
    action_send_opinion: str
    action_consultation_page: str
    action_committee: str
    action_before_sitting: str
    action_hearing: str
    action_hearing_route: str
    link_committee_letter: str
    link_hearing_rules: str
    next_step: str
    sittings_header: str
    updates_header: str
    attention_important: str
    attention_urgent: str
    attention_roundup: str
    previous_name: str
    norm_states: dict[str, str]
    version_changes: str
    roundup_rcl_action: str
    sittings_sejm: str
    sittings_committees: str
    agenda_cancelled_header: str
    agenda_dropped_header: str
    agenda_was_planned: str
    agenda_conditional: str
    agenda_conditional_unknown: str
    agenda_conditional_short: str
    agenda_closed_note: str
    agenda_apply: str
    agenda_apply_by: str
    sitting_moved_from: str
    sitting_moved_within_day: str
    sejm_sitting: str
    link_video: str
    link_committee: str
    link_senate_bills: str
    link_senate_act: str
    tag_committee_sitting: str
    tag_sejm_sitting: str
    consultation_results_header: str
    consultation_results_hint: str
    rcl_header: str
    rcl_wykaz: str
    rcl_published: str
    rcl_no_stage: str
    rcl_metadata_note: str
    consultation_letter: str
    consultation_days_from_letter: str
    consultation_deadline_in_letter: str
    consultation_email: str
    action_email_ministry: str
    action_in_polish: str
    action_rcl_comment: str
    action_rcl_window_closed: str
    action_in_force: str
    rcl_results_hint: str
    rcl_sent_to_sejm: str
    link_rcl_project: str
    link_bill_text: str
    link_justification: str
    link_osr: str
    link_wykaz: str
    link_ministry_plan: str
    tag_rcl: str
    wykaz_header: str
    wykaz_intention: str
    wykaz_stage: str
    wykaz_stage_adopted: str
    wykaz_published: str
    wykaz_planned: str
    wykaz_metadata_note: str
    wykaz_organ_unknown: str
    action_wykaz_interest: str
    action_ministry_site: str
    action_rcl_interest: str
    link_wykaz_entry: str
    tag_wykaz: str
    rcl_process_closed: str
    wykaz_process_closed: str
    committee_report: str
    subcommittee_report: str
    proposes: str
    deadline_until: str
    deadline_passed: str
    stalled_for_weeks: str
    stalled_for_months: str
    urgent_mode: str
    hearing_deadline_header: str
    hearing_on: str
    hearing_apply_until: str
    hearing_applications_closed: str
    hearing_hint: str
    hearing_application_details: str
    tag_hearing: str
    senate_deadline_header: str
    president_deadline_header: str
    senate_deadline_line: str
    president_deadline_line: str
    senate_deadline_body: str
    president_deadline_body: str
    senate_deadline_body_urgent: str
    president_deadline_body_urgent: str
    deadline_counted_from_vote: str
    amendments_senate: str
    amendments_committee: str
    link_amendments: str
    link_supplement: str
    supplement_unreadable: str
    digest_header: str
    digest_figures: str
    digest_found: str
    digest_filtered: str
    digest_published: str
    digest_no_data: str
    digest_cards: str
    digest_updates: str
    digest_remember: str
    digest_actions: str
    digest_consultations: str
    digest_sittings: str
    digest_quiet: str
    digest_month: str
    digest_month_discovered: str
    digest_month_dropped: str
    digest_month_analyzed: str
    digest_month_published: str
    digest_month_cost: str
    digest_support: str
    digest_and_more: str
    digest_support_coffee: str
    digest_support_sponsor: str
    tag_digest: str
    supplement_headers: dict[str, str] = field(default_factory=dict)
    """What a document filed to the print is called in the block that carries its digest."""
    supplement_supports: dict[str, str] = field(default_factory=dict)
    """The government's verdict, when its position states one."""
    deadline_passed_labels: dict[str, str] = field(default_factory=dict)
    """What a constitutional term running out means, by phase; `deadline_passed` otherwise."""
    urgent_deadline_passed_labels: dict[str, str] = field(default_factory=dict)
    """The same for a bill declared pilny, whose term was half as long (art. 123)."""
    agenda_conditions: dict[str, str] = field(default_factory=dict)
    """What a conditional sitting waits for, by `agenda.sitting_condition` kind; the sitting is
    announced with `agenda_conditional` and this, or with `agenda_conditional` alone."""
    update_headers: dict[str, str] = field(default_factory=dict)
    decision_labels: dict[str, str] = field(default_factory=dict)
    proposal_labels: dict[str, str] = field(default_factory=dict)
    event_tags: dict[str, str] = field(default_factory=dict)
    next_step_labels: dict[str, str] = field(default_factory=dict)
    typical_durations: dict[str, str] = field(default_factory=dict)
    urgent_step_labels: dict[str, str] = field(default_factory=dict)
    urgent_durations: dict[str, str] = field(default_factory=dict)
    no_action_labels: dict[str, str] = field(default_factory=dict)
    path_steps: dict[str, str] = field(default_factory=dict)
    stage_labels: dict[str, str] = field(default_factory=dict)
    rcl_stage_labels: dict[str, str] = field(default_factory=dict)
    consultation_review_header: str = ""
    act_application_header: str = ""
    consultation_outcomes: dict[str, str] = field(default_factory=dict)
    consultation_text_unconfirmed: str = ""
    document_review_incomplete: str = ""
    rule_date_unknown: str = ""
    project_analysis_header: str = ""
    message_part: str = ""
    document_review_source: str = ""
    act_review_ready: str = ""
    digest_expectations: str = ""
    digest_coverage_warning: str = ""
    digest_route_unknown: str = ""
    digest_source_unknown: str = ""
    digest_source: str = ""
    digest_submit_polish: str = ""
    digest_history_limited: str = ""
    digest_organ_deadline: str = ""
    agenda_purpose_labels: dict[str, str] = field(default_factory=dict)
    agenda_purpose_unknown: str = ""
    date_format: str = "%Y-%m-%d"
    short_months: tuple[str, ...] = ()
    # A month on its own, spelled in full: dates decline it («мая»), a heading does not («май»).
    month_names: tuple[str, ...] = ()
    stage_type_labels: dict[str, str] = field(default_factory=dict)
    senate_position_labels: dict[str, str] = field(default_factory=dict)
    category_labels: dict[Category, str] = field(default_factory=dict)
    category_tags: dict[Category, str] = field(default_factory=dict)
    applicant_labels: dict[ApplicantType, str] = field(default_factory=dict)


RU = Labels(
    analysis_queued="Анализ поставлен в очередь. Результат будет обработан после завершения batch.",
    new_bill_header="Новый законопроект",
    finished_bill_header="Законопроект: процесс завершён",
    update_header="Обновление",
    importance="Важность",
    category="Категория",
    about="О чём проект",
    key_changes="Ключевые изменения",
    practical_impact="Что это значит на практике",
    affected="Кого касается",
    effective_date="Вступление в силу",
    effective_date_unknown="не указано",
    stage="Стадия",
    applicant="Инициатор",
    document_date="Дата druku",
    print_number="druk nr",
    partial_text_note="Анализ основан на неполном тексте документа.",
    new_stages="Новые стадии",
    reading_stage="{numeral} чтение на заседании Сейма",
    consultation_review_header="Что дали консультации",
    act_application_header="Как применяется окончательный акт",
    consultation_outcomes={
        "accepted": "Предложение принято",
        "rejected": "Предложение отклонено",
        "partial": "Принято частично",
        "unknown": "Решение по предложению не подтверждено",
    },
    consultation_text_unconfirmed="Включение изменения в текст не подтверждено.",
    document_review_incomplete=(
        "Разбор неполный; неустановленные условия требуют проверки в официальных документах."
    ),
    rule_date_unknown="Календарная дата применения нормы не подтверждена.",
    project_analysis_header="Исторический анализ проекта, до окончательного текста закона",
    document_review_source="Документ-источник разбора",
    act_review_ready=(
        "Разобран окончательный текст: условия и исключения проверяйте по указанным нормам Dz.U."
    ),
    message_part=(
        "Часть {index}/{total} · подготовлено {date}. Условия и исключения — во всём тексте;"
        " прочитайте все части."
    ),
    digest_expectations="Что ожидается",
    digest_coverage_warning=(
        "Ожидают доставки событий: {pending}; unknown доставок: {unknown}. "
        "Полнота обзора ограничена ожидающей работой или проверками источников."
    ),
    digest_route_unknown="Маршрут подачи пока не подтверждён.",
    digest_source_unknown="Источник окна не сохранён.",
    digest_source="Источник окна",
    digest_submit_polish="Писать на польском; для проекта правительства укажите номер wykaz.",
    digest_history_limited="Исходный snapshot не сохранился; исторический исход не восстановлен.",
    digest_organ_deadline="Срок рассмотрения органом, не подачи мнения",
    agenda_purpose_labels={
        "first_reading": "Первое чтение проекта",
        "second_reading": "Второе чтение проекта",
        "third_reading": "Третье чтение проекта",
        "senate_amendments": "Рассмотрение постановления Сената",
        "voting": "Голосование",
        "hearing": "Публичные слушания",
    },
    agenda_purpose_unknown="В повестке:",
    process_closed="Сейм отклонил проект, процесс завершён.",
    process_not_enacted="Процесс завершён: закон не принят.",
    process_veto_sustained=(
        "Сейм не отклонил вето Президента (нужно 3/5 голосов): закон не принят."
    ),
    process_tribunal_ruled="Конституционный трибунал вынес решение по закону.",
    stage_veto_sustained="закон не принят повторно после вето Президента",
    process_passed="Сейм принял закон.",
    link_sejm_project="Страница проекта в Сейме",
    link_process="Ход процесса в Сейме",
    link_pdf="PDF",
    link_text_after3="Текст после III чтения",
    joint_prints="Рассматривается совместно с druk",
    joint_bill_header="Альтернативный проект того же закона",
    joint_bill_note=(
        "Рассматривается совместно с druk {numbers}: комиссия рассматривает их вместе, "
        "дальнейший ход дела — в этой ветке."
    ),
    joint_differs="Чем отличается от других проектов",
    joint_same="По сути то же самое",
    current_summary="Суть проекта",
    changes_since_previous="Что изменилось с прошлого раза",
    card_part_superseded="Карточка обновлена. Актуальный текст приведён выше.",
    reanalyzed_note="Текст проекта обновился, анализ выполнен заново.",
    run_report_title="lexinform run report",
    tag_importance="важность",
    voting="Голосование",
    votes_for="за",
    votes_against="против",
    votes_abstain="воздержались",
    not_voting="не голосовали",
    link_voting_pdf="протокол голосования (PDF)",
    referred_to_committee="Направлен в комиссию",
    no_print_yet="номер druku ещё не присвоен",
    received="Поступил в Сейм",
    found_in_text="Найден по тексту проекта: название об иностранцах не говорит.",
    representative="представитель",
    signatories="подписали",
    pre_print_stage="проект поступил в Сейм, ожидает присвоения номера druku",
    pre_print_note=(
        "Анализ основан на официальном описании проекта: текст пока доступен только на сайте Сейма."
    ),
    consultation="Общественные консультации",
    consultation_until="до",
    consultation_closed_on="завершились",
    consultation_closed_undated="завершились — срок был указан в письме",
    consultation_hint="мнение подаётся анкетой на сайте Сейма",
    print_assigned="Проекту присвоен номер druku",
    process_withdrawn="Проект отозван до присвоения номера druku.",
    process_abandoned=(
        "Сейм больше не показывает проект среди внесённых, и номера druku он так и не получил"
        " за год. Скорее всего работа над ним прекращена; формального решения Сейм не публиковал."
    ),
    process_discontinued=(
        "Каденция Сейма закончилась, проект не был рассмотрен до конца и прекращён"
        " (zasada dyskontynuacji). Чтобы вернуться к нему, проект нужно внести заново в новый Сейм."
    ),
    process_carried_over=(
        "Каденция Сейма закончилась. Гражданский проект переходит к Сейму новой каденции"
        " и получит новый номер druku."
    ),
    link_submission_pdf="PDF проекта (сайт Сейма)",
    act_published_header="Опубликован в Dziennik Ustaw",
    journal="Публикация",
    published_on="опубликован",
    enters_into_force="Вступает в силу",
    already_in_force_since="Уже действует с",
    entry_into_force_unknown="дата вступления в силу пока не указана",
    partial_vacatio_note=(
        "Это общая дата из ELI. Применение отдельных норм и переходные условия ещё не разобраны."
    ),
    in_force_header="С сегодняшнего дня действует",
    in_force_header_dated="Закон вступил в силу",
    in_force_since="вступил в силу",
    act_summary="Суть закона",
    link_isap="ISAP",
    link_act_pdf="Текст закона (PDF)",
    tag_published="закон",
    tag_in_force="вступилвсилу",
    consultation_deadline_header="Консультации заканчиваются",
    consultation_days_left="осталось дней",
    consultation_last_day="сегодня последний день",
    tag_consultations="консультации",
    tag_consultation_results="мнениявконсультациях",
    tag_term="kadencja",
    tag_ukraine="Украина",
    consultation_link="анкета на сайте Сейма",
    consultation_page="страница консультаций на сайте Сейма",
    action_now="Что можно сделать сейчас",
    action_senate="направить мнение в комиссию Сената —",
    action_senate_many="направить мнение в комиссии Сената —",
    action_senate_pending=(
        "Данные о комиссии и маршруте подачи пока не подтверждены; проверьте страницу Сената."
    ),
    action_senate_in_polish="(на польском, с номером сенатского druk nr {number})",
    path="Путь",
    action_send_opinion="заполнить анкету",
    action_consultation_page="на сайте Сейма",
    action_committee="направить мнение в комиссию —",
    action_before_sitting="до заседания",
    action_hearing="подать заявку на участие в публичных слушаниях",
    action_hearing_route=(
        "бланк zgłoszenia — на {email} с электронной подписью (kwalifikowany, osobisty или zaufany)"
    ),
    link_committee_letter="форма письма",
    link_hearing_rules="бланк и порядок на сайте Сейма",
    next_step="Что дальше",
    sittings_header="Заседания",
    updates_header="Что изменилось",
    attention_important="Важно",
    attention_urgent="Нужно действовать",
    attention_roundup="Коротко по проектам",
    previous_name="Прежнее имя: {}",
    norm_states={
        "passed": "Принят Сеймом",
        "passed_dated": "Принят Сеймом {date}",
        "published": "Опубликован",
        "published_dated": "Опубликован {date}",
        "in_force": "Действует",
        "in_force_dated": "Действует с {date}",
        "ended": "Процесс завершён",
    },
    version_changes="Изменения между версиями проекта",
    roundup_rcl_action=(
        "консультации закрыты; {comment}; заявить интерес к работам"
        " (zgłoszenie zainteresowania): {organ} · писать на польском, указать {number}"
    ),
    sittings_sejm="Сейм",
    sittings_committees="Комиссии",
    agenda_cancelled_header="Заседание отменено",
    agenda_dropped_header="Проект снят с повестки заседания",
    agenda_was_planned="было запланировано на",
    agenda_conditional="Заседание объявлено условно: состоится, только если",
    agenda_conditional_unknown="Заседание объявлено условно; дату нужно подтвердить у комиссии.",
    agenda_conditional_short="условно",
    agenda_closed_note="Заседание закрытое — публику на него не пускают.",
    agenda_apply="Заявка на участие в слушании — на адрес",
    agenda_apply_by="срок подачи — до",
    sitting_moved_from="Заседание перенесено с",
    sitting_moved_within_day="Изменились время или зал; ранее было объявлено:",
    sejm_sitting="заседание Сейма №",
    link_video="Трансляция",
    link_committee="Страница комиссии",
    link_senate_bills="законы в Сенате",
    link_senate_act="закон на сайте Сената",
    tag_committee_sitting="заседаниекомиссии",
    tag_sejm_sitting="заседаниесейма",
    consultation_results_header="Опубликованы мнения из консультаций",
    consultation_results_hint=(
        "поданные анкеты и их число видны на странице проекта на сайте Сейма"
    ),
    rcl_header="Правительственный проект (RCL)",
    rcl_wykaz="номер в wykazie prac RM",
    rcl_published="Опубликован на RCL",
    rcl_no_stage="проект опубликован на RCL, работа над ним ещё не началась",
    rcl_metadata_note=(
        "Текст проекта на RCL не удалось прочитать — анализ по названию и описанию."
    ),
    consultation_letter="письмо о консультациях",
    consultation_days_from_letter="{days} дн. с даты письма",
    consultation_deadline_in_letter="срок указан в письме",
    consultation_email="замечания на e-mail",
    action_email_ministry="направить замечания на {email}",
    action_in_polish="(на польском, с номером {wykaz})",
    action_rcl_comment="оставить комментарий через форму на RCL",
    action_rcl_window_closed=(
        "публичные консультации уже закрыты, но пока проект в правительстве остаётся:"
    ),
    action_in_force=(
        "откройте окончательный текст Dz.U. и проверьте условия для своей ситуации;"
        " прежняя карточка описывала проект, а не окончательный закон."
    ),
    rcl_results_hint=(
        "поданные мнения (stanowiska) и ответ министерства опубликованы на странице проекта на RCL"
    ),
    rcl_sent_to_sejm="Проект направлен в Сейм — ждём номер druku",
    link_rcl_project="Проект на RCL",
    link_bill_text="Текст проекта",
    link_justification="Uzasadnienie",
    link_osr="OSR",
    link_wykaz="Wykaz prac RM",
    link_ministry_plan="План работ министерства",
    tag_rcl="RCL",
    wykaz_header="План правительства",
    wykaz_intention=(
        "Это пока только намерение: текста проекта ещё нет. Запись в плане работ"
        " правительства от {date}. Разбор текста придёт ответом в эту же ветку, когда проект"
        " опубликуют на RCL и начнутся публичные консультации."
    ),
    wykaz_stage="проект внесён в план работ правительства, текста ещё нет",
    wykaz_stage_adopted="правительство приняло проект, ждём внесения в Сейм",
    wykaz_published="Внесён в план работ",
    wykaz_planned="принятие правительством: {quarter} кв. {year}",
    wykaz_metadata_note=(
        "Оценка по описанию из плана работ правительства: текста проекта ещё не существует."
    ),
    wykaz_organ_unknown="профильное министерство",
    action_wykaz_interest=(
        "можно заявить интерес к работам над проектом (zgłoszenie zainteresowania): закон"
        " допускает это с публикации плана — письмом органу, который готовит проект: {organ}"
    ),
    action_ministry_site="адреса канцелярии, ePUAP и e-Doręczenia",
    action_rcl_interest=(
        "можно заявить интерес к работам над проектом (zgłoszenie zainteresowania) — письмом"
        " органу, который готовит проект: {organ}"
    ),
    link_wykaz_entry="Запись в плане работ",
    tag_wykaz="wykazRM",
    rcl_process_closed="Проект закрыт на RCL, в Сейм не направлен.",
    wykaz_process_closed="Правительство отказалось от проекта: он снят с плана работ.",
    committee_report="отчёт комиссии (sprawozdanie)",
    subcommittee_report="отчёт подкомиссии",
    proposes="предлагает",
    deadline_until="решение до",
    deadline_passed="срок истёк",
    stalled_for_weeks="без движения уже {weeks} нед.",
    stalled_for_months="без движения уже {months} мес.",
    urgent_mode="срочный режим, tryb pilny",
    hearing_deadline_header="Заявки на публичные слушания",
    hearing_on="слушания",
    hearing_apply_until="заявки на участие до",
    hearing_applications_closed="приём заявок на участие закрыт",
    hearing_hint=(
        "заявить участие может любой — заявки подаются в Сейм не позднее чем за 10 дней до"
        " слушаний (рег. Сейма, ст. 70b); если места в зале не хватает, участников ограничивают,"
        " и решает порядок подачи — поэтому заявку стоит подать сразу"
    ),
    hearing_application_details=(
        "бланк zgłoszenia — на {email} с электронной подписью (kwalifikowany, osobisty или"
        " zaufany); бланк и другие способы подачи — по ссылке ниже"
    ),
    tag_hearing="слушания",
    senate_deadline_header="Закон в Сенате",
    president_deadline_header="Закон у Президента",
    senate_deadline_line="Сенат должен решить до {date}",
    president_deadline_line="Президент должен решить до {date}",
    senate_deadline_body=(
        "Это срок рассмотрения Сенатом, не срок подачи мнения. "
        "Возможность обращения зависит от подтверждённой работы комиссии."
    ),
    president_deadline_body=(
        "Подписать закон, наложить вето или направить его в Конституционный трибунал"
        " (ст. 122 Конституции)."
    ),
    senate_deadline_body_urgent=(
        "Срок рассмотрения Сенатом сокращён в срочной процедуре. Это не срок подачи мнения."
    ),
    president_deadline_body_urgent=(
        "Подписать закон, наложить вето или направить его в Конституционный трибунал"
        " (ст. 122 Конституции). Проект срочный (tryb pilny, ст. 123): у Президента 7 дней"
        " вместо обычных 21."
    ),
    deadline_counted_from_vote=(
        "Срок отсчитан от голосования в Сейме: фактический на несколько дней позже —"
        " он идёт с момента передачи закона."
    ),
    amendments_senate="Что меняют поправки Сената",
    amendments_committee="Что меняют поправки (по отчёту комиссии)",
    link_amendments="Текст поправок",
    link_supplement="Документ (PDF)",
    supplement_unreadable="Документ не удалось прочитать — он есть по ссылке ниже.",
    digest_header="Итоги недели",
    digest_figures="Неделя в цифрах",
    digest_found="Найдено новых записей о законопроектах: {}",
    digest_filtered="Отсеяно при проверке релевантности: {}",
    digest_published="Опубликовано новых разборов: {}",
    digest_no_data="нет полных данных",
    digest_cards="Новые законопроекты",
    digest_updates="Что изменилось",
    digest_remember="Что запомнить",
    digest_actions="Что сделать на ближайшей неделе",
    digest_consultations="Идут консультации — можно успеть",
    digest_sittings="Ближайшие заседания",
    digest_quiet="На этой неделе в канале не было публикаций.",
    digest_month="Итоги месяца",
    digest_month_discovered="просмотрено записей",
    digest_month_dropped="отсеяно по ключевым словам",
    digest_month_analyzed="прочитано моделью",
    digest_month_published="опубликовано карточек",
    digest_month_cost="расходы на модель",
    digest_support="Канал бесплатный и без рекламы. Если он вам полезен — можно поддержать:",
    digest_and_more="и ещё {} — смотрите в канале",
    digest_support_coffee="Buy me a coffee",
    digest_support_sponsor="GitHub Sponsors",
    tag_digest="#дайджест",
    supplement_headers={
        "government_position": "Позиция правительства по проекту",
        "impact_assessment": "Оценка последствий (OSR)",
    },
    supplement_supports={
        "yes": "правительство поддерживает проект",
        "no": "правительство против проекта",
    },
    deadline_passed_labels={
        "president": "21 день на подпись истёк",
        "president_after_veto": "7 дней на подпись истекли",
    },
    urgent_deadline_passed_labels={
        "president": "7 дней на подпись истекли",
    },
    agenda_conditions={
        "second_reading_amendments": (
            "во втором чтении будут внесены поправки и Сейм направит их в эту комиссию"
        ),
        "first_reading_referral": ("Сейм закончит первое чтение и направит проект в эту комиссию"),
        "senate_amendments": "Сенат примет поправки и Сейм направит их в эту комиссию",
        "referral": "Сейм направит проект в эту комиссию",
    },
    update_headers={
        "update": "Обновление",
        "print_assigned": "Присвоен номер druku",
        "start": "Проект поступил в Сейм",
        "first_reading_referral": "Направлен на I чтение",
        "referral": "Направлен в комиссию",
        "referrals": "Направлен в комиссии",
        "referral_plenary": "I чтение пройдёт на заседании Сейма",
        "first_reading": "I чтение прошло",
        "committee_work": "Работа в комиссии началась",
        "committee_report": "Отчёт комиссии",
        "subcommittee_report": "Отчёт подкомиссии",
        "committee_rejects": "Комиссия предлагает отклонить проект",
        "hearing": "Назначены публичные слушания",
        "second_reading": "II чтение прошло",
        "second_reading_amendments": "Поправки во II чтении: проект вернулся в комиссию",
        "third_reading": "III чтение",
        "voting": "Состоялось голосование",
        "passed": "Сейм принял закон",
        "rejected": "Сейм отклонил проект",
        "withdrawn_by_applicant": "Проект отозван",
        "veto_sustained": "Вето Президента осталось в силе",
        "veto_overridden": "Сейм отклонил вето: закон принят повторно",
        "not_enacted": "Процесс завершён: закон не принят",
        "decision_unknown": "Результат решения пока не подтверждён",
        "senate": "Позиция Сената",
        "senate_no_amendments": "Сенат принял закон без поправок",
        "senate_amendments": "Сенат внёс поправки",
        "senate_rejected": "Сенат отклонил закон",
        "senate_considered": "Сейм рассмотрел поправки Сената",
        "to_president": "Закон передан Президенту",
        "signed": "Президент подписал закон",
        "veto": "Президент наложил вето",
        "tribunal": "Закон направлен в Конституционный трибунал",
        "tribunal_ruled": "Конституционный трибунал вынес решение",
        "text_changed": "Новая версия текста",
        "government_position": "Правительство высказалось о проекте",
        "impact_assessment": "Появилась оценка последствий проекта",
        "withdrawn": "Проект отозван",
        "abandoned": "Проект больше не отслеживается",
        "discontinued": "Проект прекращён с концом каденции",
        "rcl_stage": "Новая стадия на RCL",
        "consultation_opened": "Открылись публичные консультации",
        "rcl_to_sejm": "Проект направлен в Сейм",
        "rcl_closed": "Проект закрыт на RCL",
        "rcl_started": "Проект опубликован на RCL",
        "wykaz_withdrawn": "Правительство отказалось от проекта",
        "wykaz_adopted": "Правительство приняло проект",
    },
    decision_labels={
        "niezwłocznie przystąpiono do iii": "сразу перешли к III чтению",
        "skierowano ponownie do komisji": "возвращён в комиссию для рассмотрения поправок",
        "skierowano do komisji": "направлен в комиссию",
        # Longer first: `_translate` matches on the first fragment found, and "uchwalono
        # ponownie" contains "uchwalono".
        "uchwalono ponownie": "вето отклонено, закон принят повторно",
        "nie uchwalona ponownie": "закон не принят повторно, вето устояло",
        "przyjęto część poprawek": "часть поправок Сената принята",
        "przyjęto poprawki": "поправки Сената приняты",
        "odrzucono poprawki": "поправки Сената отклонены",
        "uchwalono": "закон принят",
        "odrzucono": "проект отклонён",
    },
    proposal_labels={
        "załączony projekt": "принять проект в новой редакции (текст приложен)",
        "przyjąć bez poprawek": "принять без поправок",
        "przyjąć część poprawek": "принять часть поправок",
        "odrzucić poprawki": "отклонить поправки",
        "przyjąć poprawki": "принять поправки",
        "odrzucić": "отклонить проект",
    },
    event_tags={
        "voting": "голосование",
        "senate": "сенат",
        "president": "президент",
        "veto": "вето",
        "amendments": "поправки",
        "government_position": "правительство",
        "impact_assessment": "оценкапоследствий",
        "consultations": "консультации",
        "committee": "комиссия",
        "hearing": "слушания",
        "passed": "принят",
        "rejected": "непринят",
        "tribunal": "трибунал",
        "withdrawn": "отозван",
        "discontinued": "прекращён",
    },
    next_step_labels={
        "pre_print": "присвоение номера druku, затем I чтение",
        "pre_print_consultation": (
            "консультации до {date}, затем присвоение номера druku и I чтение"
        ),
        "first_reading": "I чтение",
        "first_reading_committee": "I чтение в комиссии — {committee}",
        "first_reading_committee_unnamed": "I чтение в комиссии",
        "first_reading_sitting": "I чтение на заседании Сейма",
        "committee_work": (
            "работа в комиссии — {committee} (sprawozdanie), затем II чтение на заседании Сейма"
        ),
        "committee_work_unnamed": "работа в комиссии (sprawozdanie), затем II чтение в Сейме",
        "second_reading": "II чтение на заседании Сейма",
        "second_reading_committee": (
            "комиссия рассматривает поправки II чтения — {committee} (дополнительное"
            " sprawozdanie), затем III чтение"
        ),
        "second_reading_committee_unnamed": (
            "комиссия рассматривает поправки II чтения, затем III чтение"
        ),
        "third_reading": "III чтение и голосование в Сейме",
        "senate": "рассмотрение в Сенате (до 30 дней)",
        "decision_unknown": "решение пока не указано в данных Сейма; следующий шаг уточняется",
        "senate_amendments": "Сейм рассматривает поправки Сената",
        "senate_rejection": (
            "Сейм голосует по решению Сената отклонить закон: закон будет принят, только если"
            " Сейм отклонит это решение абсолютным большинством"
        ),
        "president": "подпись Президента (до 21 дня), затем публикация в Dziennik Ustaw",
        "president_overdue": "подпись Президента, затем публикация в Dziennik Ustaw",
        "president_after_senate_silence": (
            "Сенат не принял решения за 30 дней — по ст. 121 ч. 2 Конституции закон считается"
            " принятым в редакции Сейма и уходит к Президенту (подпись до 21 дня), затем"
            " публикация в Dziennik Ustaw. В базе Сейма передача Президенту ещё не отмечена"
        ),
        "president_after_veto": (
            "подпись Президента — после отклонения вето у него 7 дней и права на вето или"
            " обращение в трибунал больше нет (ст. 122 ч. 5), затем публикация в Dziennik Ustaw"
        ),
        "publication": "публикация в Dziennik Ustaw",
        "in_force": "вступление в силу {date}",
        "in_force_unknown": "вступление в силу (дата пока не указана)",
        "veto": (
            "комиссия рассматривает вето — {committee}, затем голосование в Сейме:"
            " вето будет отклонено, только если за закон снова проголосуют 3/5"
        ),
        "veto_unnamed": "голосование в Сейме по вето: отклонить его можно 3/5 голосов",
        "tribunal": "решение Конституционного трибунала",
        "tribunal_after_ruling": (
            "дальнейший шаг после решения Конституционного трибунала: подпись Президента,"
            " новый druk или публикация в Dziennik Ustaw"
        ),
        "wykaz": (
            "публикация проекта на RCL и общественные консультации, затем комитеты Совета"
            " министров, Rada Ministrów и внесение в Сейм"
        ),
        "wykaz_to_rcl": "публикация проекта на RCL и общественные консультации",
        "wykaz_adopted": "внесение проекта в Сейм и присвоение номера druku",
        "rcl_consultation": (
            "общественные консультации до {date}, затем сбор мнений (opiniowanie), комитеты"
            " Совета министров, Rada Ministrów и внесение в Сейм"
        ),
        "rcl_consultation_undated": (
            "общественные консультации (срок указан в письме), затем сбор мнений (opiniowanie),"
            " комитеты Совета министров, Rada Ministrów и внесение в Сейм"
        ),
        "rcl_opinions": (
            "межведомственные согласования и сбор мнений, затем комитеты Совета министров,"
            " Rada Ministrów и внесение в Сейм"
        ),
        "rcl_committees": (
            "комитеты Совета министров и Komisja Prawnicza, затем Rada Ministrów и направление"
            " в Сейм"
        ),
        "rcl_council": "принятие Радой министров, затем направление в Сейм и номер druku",
        "rcl_to_sejm": "присвоение номера druku в Сейме, затем I чтение",
    },
    date_format="%d.%m.%Y",
    short_months=(
        "янв",
        "фев",
        "марта",
        "апр",
        "мая",
        "июня",
        "июля",
        "авг",
        "сент",
        "окт",
        "нояб",
        "дек",
    ),
    month_names=(
        "январь",
        "февраль",
        "март",
        "апрель",
        "май",
        "июнь",
        "июль",
        "август",
        "сентябрь",
        "октябрь",
        "ноябрь",
        "декабрь",
    ),
    typical_durations={
        "pre_print": "обычно от нескольких дней до нескольких месяцев",
        "first_reading": "обычно 2–6 недель после поступления",
        "first_reading_committee": "обычно 2–6 недель после поступления",
        "first_reading_sitting": "обычно 2–6 недель после поступления",
        "committee_work": "от нескольких недель до года",
        "second_reading": "часто на одном заседании с III чтением",
        "second_reading_committee": "обычно дни — до ближайшего блока голосований",
        "third_reading": "часто на одном заседании со II чтением",
        "senate_amendments": "обычно на ближайшем заседании Сейма",
        "senate_rejection": "обычно на ближайшем заседании Сейма",
        "veto": "Сейм голосует, когда решит: от недель до конца каденции",
        "tribunal": "трибунал рассматривает месяцами",
        "publication": "обычно 1–4 недели после подписи",
        "wykaz": "обычно 1–6 месяцев до публикации проекта",
        "wykaz_to_rcl": "обычно несколько недель",
        "wykaz_adopted": "обычно несколько недель",
        "rcl_opinions": "обычно 1–3 месяца на этом этапе; весь путь на RCL — 3–12 месяцев",
        "rcl_committees": "обычно 1–3 месяца",
        "rcl_council": "обычно несколько недель",
        "rcl_to_sejm": "обычно несколько дней",
    },
    urgent_step_labels={
        "senate": "рассмотрение в Сенате (срочный режим: до 14 дней)",
        "president": (
            "подпись Президента (срочный режим: до 7 дней), затем публикация в Dziennik Ustaw"
        ),
    },
    urgent_durations={
        "first_reading": "обычно несколько дней после поступления",
        "first_reading_committee": "обычно несколько дней после поступления",
        "first_reading_sitting": "обычно несколько дней после поступления",
        "committee_work": "обычно дни, а не недели",
        "second_reading": "III чтение обычно сразу после II",
        "third_reading": "обычно на том же заседании, что и II чтение",
        "senate_amendments": "обычно на ближайшем заседании Сейма",
        "publication": "обычно несколько дней после подписи",
    },
    no_action_labels={
        "pre_print": "пока ничего — следующая возможность: замечания в комиссию после I чтения",
        "decision_unknown": (
            "проверить документы по ссылке на Сейм; срок следующего действия пока неизвестен"
        ),
        "pre_print_consultation": (
            "пока ничего — следующая возможность: замечания в комиссию после I чтения"
        ),
        "first_reading": "пока ничего — следующая возможность: замечания в комиссию после I чтения",
        "first_reading_committee": (
            "пока ничего — следующая возможность: замечания в комиссию после I чтения"
        ),
        "first_reading_sitting": (
            "пока ничего — следующая возможность: замечания в комиссию после I чтения"
        ),
        "committee_work": (
            "написать в комиссию, которая ведёт проект — её название указано на странице"
            " процесса в Сейме"
        ),
        "second_reading": (
            "пока ничего — после голосования в Сейме мнение можно направить в комиссию Сената"
        ),
        "second_reading_committee": (
            "написать в комиссию, которая дорабатывает поправки — её название указано на"
            " странице процесса в Сейме"
        ),
        "third_reading": (
            "пока ничего — после голосования в Сейме мнение можно направить в комиссию Сената"
        ),
        "senate": "пока ничего — комиссии Сената уже рассмотрели закон, дальше голосование Сената",
        "senate_amendments": "пока ничего — Сейм решает по поправкам Сената",
        "senate_rejection": "пока ничего — Сейм решает, отклонить ли решение Сената",
        "president": "пока ничего — закон у Президента",
        "president_after_senate_silence": "пока ничего — закон у Президента",
        "president_after_veto": "пока ничего — Президент обязан подписать закон в 7 дней",
        "publication": "пока ничего — ждём публикации в Dziennik Ustaw",
        "in_force": "пока ничего — закон принят, остаётся подготовиться к вступлению в силу",
        "in_force_unknown": "пока ничего — закон принят, дата вступления в силу ещё не известна",
        "veto": "пока ничего — решение за Сеймом",
        "tribunal": "пока ничего — решение за Конституционным трибуналом",
        "tribunal_after_ruling": (
            "пока ничего — дальнейший шаг зависит от решения Трибунала; следим за подписью"
            " Президента, новым druk или публикацией в Dz.U."
        ),
        "wykaz_to_rcl": (
            "пока ничего — ждём публикации проекта на RCL, тогда откроются консультации"
        ),
        "wykaz_adopted": (
            "пока ничего — правительство приняло проект, ждём внесения в Сейм и номера druku"
        ),
        "wykaz": "пока ничего — ждём публикации проекта на RCL, тогда откроются консультации",
        "rcl_consultation": "пока ничего — консультации по проекту уже закрыты",
        "rcl_opinions": "пока ничего — проект проходит согласования внутри правительства",
        "rcl_committees": "пока ничего — проект в комитетах Совета министров",
        "rcl_council": "пока ничего — проект ждёт принятия Радой министров",
        "rcl_to_sejm": "пока ничего — ждём номер druku, затем I чтение и комиссия",
    },
    path_steps={
        "wykaz": "план",
        "rcl": "RCL",
        "sejm": "Сейм",
        "committee": "комиссии",
        "readings": "II и III чтение",
        "senate": "Сенат",
        "president": "Президент",
        "journal": "Dz.U.",
        "in_force": "в силе",
    },
    stage_labels={
        "Start": "проект поступил в Сейм",
        "ReadingReferral": "направлен на I чтение",
        "Referral": "направлен в комиссию",
        "Reading": "I чтение в комиссиях",
        "CommitteeWork": "работа в комиссии",
        "CommitteeReport": "отчёт комиссии (sprawozdanie)",
        "Voting": "голосование в Сейме",
        "SenatePosition": "позиция Сената",
        "End": "процесс в Сейме завершён",
    },
    rcl_stage_labels={
        "zgłoszenia lobbingowe": "лоббистские заявления",
        "uzgodnienia": "межведомственные согласования",
        "konsultacje publiczne": "общественные консультации",
        "opiniowanie": "сбор мнений министерств и партнёров",
        "komisja prawnicza": "Юридическая комиссия правительства",
        "stały komitet": "Постоянный комитет Совета министров",
        "komitet": "комитет Совета министров",
        "notyfikacja": "нотификация в Европейской комиссии",
        "rada ministrów": "Совет министров",
        "do sejmu": "направлен в Сейм",
    },
    stage_type_labels={
        "ToPresident": "Закон передан Президенту",
        "PresidentSignature": "✍️ Президент подписал закон",
        "Veto": "⛔ Президент наложил вето",
        "PresidentToTribunal": "⚖️ Президент направил закон в Конституционный трибунал",
        "ConstitutionalTribunalRuling": "⚖️ Решение Конституционного трибунала",
        "PublicHearing": "📢 Публичные слушания (wysłuchanie publiczne)",
        "SenatePositionConsideration": "Сейм рассмотрел позицию Сената",
        "PresidentMotionConsideration": "Сейм рассмотрел вето Президента",
        "GovermentPosition": "поступила позиция правительства",
        "Opinion": "поступило мнение организации",
    },
    senate_position_labels={
        "nie wniósł poprawek": "Сенат принял закон без поправок",
        "wniósł poprawki": "Сенат внёс поправки",
        "wniósł poprawkę": "Сенат внёс поправку",
        "odrzucił ustawę": "Сенат отклонил закон",
    },
    category_labels={
        Category.LEGAL_STAY: "легализация пребывания",
        Category.EMPLOYMENT: "работа и трудоустройство",
        Category.SOCIAL: "соцсфера",
        Category.INDIRECT: "косвенное влияние",
        Category.MARGINAL: "второстепенное",
        Category.NONE: "не относится",
    },
    category_tags={
        Category.LEGAL_STAY: "легализация",
        Category.EMPLOYMENT: "работа",
        Category.SOCIAL: "соцсфера",
        Category.INDIRECT: "косвенно",
        Category.MARGINAL: "второстепенное",
        Category.NONE: "прочее",
    },
    applicant_labels={
        ApplicantType.GOVERNMENT: "правительственный",
        ApplicantType.DEPUTIES: "депутатский",
        ApplicantType.SENATE: "сенатский",
        ApplicantType.PRESIDENT: "президентский",
        ApplicantType.PRESIDIUM: "Президиум Сейма",
        ApplicantType.CITIZENS: "гражданский",
        ApplicantType.COMMITTEE: "комиссионный",
        ApplicantType.UNKNOWN: "не определён",
    },
)

EN = Labels(
    analysis_queued="Analysis queued. The result will be processed when the batch completes.",
    new_bill_header="New bill",
    finished_bill_header="Bill: the process is over",
    update_header="Update",
    importance="Importance",
    category="Category",
    about="What it is about",
    key_changes="Key changes",
    practical_impact="What it means in practice",
    affected="Who is affected",
    effective_date="Entry into force",
    effective_date_unknown="not specified",
    stage="Stage",
    applicant="Submitted by",
    document_date="Print date",
    print_number="print no.",
    partial_text_note="The analysis is based on a partial text of the document.",
    new_stages="New stages",
    reading_stage="{numeral} reading at a Sejm sitting",
    consultation_review_header="What consultations achieved",
    act_application_header="How the final act applies",
    consultation_outcomes={
        "accepted": "Proposal accepted",
        "rejected": "Proposal rejected",
        "partial": "Partially accepted",
        "unknown": "Proposal outcome is not confirmed",
    },
    consultation_text_unconfirmed="Incorporation into the text is not confirmed.",
    document_review_incomplete=(
        "The review is incomplete; unresolved conditions need checking against official documents."
    ),
    rule_date_unknown="The rule's calendar application date is not confirmed.",
    project_analysis_header="Historical draft analysis, before the final act text",
    document_review_source="Review source document",
    act_review_ready=(
        "The final text has been reviewed: check conditions and exceptions against"
        " its cited provisions."
    ),
    message_part=(
        "Part {index}/{total} · prepared {date}. Conditions and exceptions span the"
        " full text; read all parts."
    ),
    digest_expectations="What is expected",
    digest_coverage_warning=(
        "Events awaiting delivery: {pending}; unknown deliveries: {unknown}. "
        "Pending work or source checks limit coverage."
    ),
    digest_route_unknown="The submission route is not confirmed.",
    digest_source_unknown="The window source was not saved.",
    digest_source="Window source",
    digest_submit_polish="Write in Polish; quote the wykaz number for a government project.",
    digest_history_limited=(
        "The original snapshot is unavailable; the historic outcome was not reconstructed."
    ),
    digest_organ_deadline="Organ decision deadline, not an opinion submission deadline",
    agenda_purpose_labels={
        "first_reading": "First reading",
        "second_reading": "Second reading",
        "third_reading": "Third reading",
        "senate_amendments": "Consideration of the Senate resolution",
        "voting": "Voting",
        "hearing": "Public hearing",
    },
    agenda_purpose_unknown="On the agenda:",
    process_closed="The Sejm rejected the bill; the process is over.",
    process_not_enacted="The process is over: no law was enacted.",
    process_veto_sustained=(
        "The Sejm did not override the veto (a 3/5 majority is needed): no law was enacted."
    ),
    process_tribunal_ruled="The Constitutional Tribunal has ruled on the act.",
    stage_veto_sustained="not passed again after the President's veto",
    process_passed="The Sejm passed the bill.",
    link_sejm_project="Sejm project page",
    link_process="Legislative process",
    link_pdf="Print PDF",
    link_text_after3="Text after 3rd reading",
    joint_prints="Considered jointly with print",
    joint_bill_header="Alternative bill on the same subject",
    joint_bill_note=(
        "Considered jointly with print {numbers}: the committee works on them together; "
        "what happens next is posted in this thread."
    ),
    joint_differs="How it differs from the other bills",
    joint_same="The same in substance",
    current_summary="Summary",
    changes_since_previous="What changed since the previous version",
    card_part_superseded="The card was updated. The current text is above.",
    reanalyzed_note="The bill text was updated; the analysis was redone.",
    run_report_title="lexinform run report",
    tag_importance="importance",
    voting="Vote",
    votes_for="for",
    votes_against="against",
    votes_abstain="abstained",
    not_voting="did not vote",
    link_voting_pdf="voting record (PDF)",
    referred_to_committee="Referred to committee",
    no_print_yet="no print number yet",
    received="Received by the Sejm",
    found_in_text="Found by scanning the bill text: the title does not mention foreigners.",
    representative="representative",
    signatories="signed by",
    pre_print_stage="submitted to the Sejm, awaiting a print number",
    pre_print_note=(
        "Analysis based on the official description: the text is only on the Sejm website so far."
    ),
    consultation="Public consultation",
    consultation_until="until",
    consultation_closed_on="closed on",
    consultation_closed_undated="closed — the deadline was in the letter",
    consultation_hint="opinions go in through the survey form (ankieta) on the Sejm website",
    print_assigned="Print number assigned",
    process_withdrawn="The bill was withdrawn before receiving a print number.",
    process_abandoned=(
        "The Sejm no longer lists the bill among those submitted, and it never received a print"
        " number in a year. Work on it has most likely stopped; the Sejm published no decision."
    ),
    process_discontinued=(
        "The Sejm term ended before the bill was finished: it lapsed (zasada dyskontynuacji)."
        " To come back, it must be submitted to the new Sejm again."
    ),
    process_carried_over=(
        "The Sejm term ended. As a citizens' bill it is taken over by the new Sejm"
        " and will receive a new print number."
    ),
    link_submission_pdf="Bill PDF (Sejm website)",
    act_published_header="Published in Dziennik Ustaw",
    journal="Publication",
    published_on="published",
    enters_into_force="Enters into force",
    already_in_force_since="Already in force since",
    entry_into_force_unknown="entry-into-force date not stated yet",
    partial_vacatio_note=(
        "This is the general ELI date. Individual provisions and transition rules have not yet"
        " been reviewed."
    ),
    in_force_header="In force from today",
    in_force_header_dated="The act has entered into force",
    in_force_since="in force since",
    act_summary="What the act does",
    link_isap="ISAP",
    link_act_pdf="Act text (PDF)",
    tag_published="law",
    tag_in_force="inforce",
    consultation_deadline_header="Public consultation is closing",
    consultation_days_left="days left",
    consultation_last_day="today is the last day",
    tag_consultations="consultation",
    tag_consultation_results="consultationopinions",
    tag_term="term",
    tag_ukraine="Ukraine",
    consultation_link="survey form on the Sejm site",
    consultation_page="consultation page on the Sejm website",
    action_now="What you can do now",
    action_senate="send an opinion to the Senate committee —",
    action_senate_many="send an opinion to the Senate committees —",
    action_senate_pending=(
        "The committee and submission route are not confirmed; check the Senate page."
    ),
    action_senate_in_polish="(in Polish, quoting Senate print no. {number})",
    path="Path",
    action_send_opinion="fill in the survey form (ankieta)",
    action_consultation_page="on the Sejm website",
    action_committee="send an opinion to the committee —",
    action_before_sitting="before the sitting on",
    action_hearing="apply to take part in the public hearing",
    action_hearing_route=(
        "the application form goes to {email} with an electronic signature (qualified, personal"
        " or trusted)"
    ),
    link_committee_letter="letter form",
    link_hearing_rules="form and rules on the Sejm's site",
    next_step="What comes next",
    sittings_header="Sittings",
    updates_header="What changed",
    attention_important="Important",
    attention_urgent="Action needed",
    attention_roundup="Briefly on the bills",
    previous_name="Previously: {}",
    norm_states={
        "passed": "Passed by the Sejm",
        "passed_dated": "Passed by the Sejm on {date}",
        "published": "Published",
        "published_dated": "Published on {date}",
        "in_force": "In force",
        "in_force_dated": "In force since {date}",
        "ended": "Process ended",
    },
    version_changes="Changes between draft versions",
    roundup_rcl_action=(
        "consultations closed; {comment}; declare interest in the work"
        " (zgłoszenie zainteresowania): {organ} · write in Polish, cite {number}"
    ),
    sittings_sejm="Sejm",
    sittings_committees="Committees",
    agenda_cancelled_header="Sitting called off",
    agenda_dropped_header="Bill taken off the sitting's agenda",
    agenda_was_planned="was planned for",
    agenda_conditional="The sitting is announced conditionally: it happens only if",
    agenda_conditional_unknown="The sitting is conditional; confirm the date with the committee.",
    agenda_conditional_short="conditional",
    agenda_closed_note="The sitting is closed — the public is not admitted.",
    agenda_apply="To take part in the hearing, write to",
    agenda_apply_by="applications are open until",
    sitting_moved_from="The sitting was moved from",
    sitting_moved_within_day="The time or the room changed; it was announced as:",
    sejm_sitting="Sejm sitting no.",
    link_video="Live stream",
    link_committee="Committee page",
    link_senate_bills="bills in the Senate",
    link_senate_act="the act on the Senate's site",
    tag_committee_sitting="committeesitting",
    tag_sejm_sitting="sejmsitting",
    consultation_results_header="Consultation opinions published",
    consultation_results_hint=(
        "the surveys submitted, and how many there were, are on the bill's page on the Sejm site"
    ),
    rcl_header="Government bill (RCL)",
    rcl_wykaz="wykaz prac RM number",
    rcl_published="Published on RCL",
    rcl_no_stage="published on RCL, work has not started yet",
    rcl_metadata_note=("The text on RCL could not be read — analysed from title and description."),
    consultation_letter="consultation letter",
    consultation_days_from_letter="{days} days from the letter",
    consultation_deadline_in_letter="deadline stated in the letter",
    consultation_email="comments by e-mail to",
    action_email_ministry="send comments to {email}",
    action_in_polish="(in Polish, quoting {wykaz})",
    action_rcl_comment="leave a comment through the RCL form",
    action_rcl_window_closed=(
        "the public consultation has closed; while the draft is still with the government there"
        " remains:"
    ),
    action_in_force=(
        "the law now applies: check whether the change affects you, and verify deadlines and"
        " documents in the Dz.U. text"
    ),
    rcl_results_hint=(
        "the opinions submitted (stanowiska) and the ministry's answer are on the project page"
        " on RCL"
    ),
    rcl_sent_to_sejm="The bill went to the Sejm — waiting for the print number",
    link_rcl_project="Project on RCL",
    link_bill_text="Bill text",
    link_justification="Uzasadnienie",
    link_osr="OSR",
    link_wykaz="Wykaz prac RM",
    link_ministry_plan="Ministry work plan",
    tag_rcl="RCL",
    wykaz_header="Government plan",
    wykaz_intention=(
        "An intention so far: there is no draft text yet. Entered in the government's"
        " legislative plan on {date}. The text will be analysed in a reply in this thread once"
        " the project is published on RCL and the public consultation starts."
    ),
    wykaz_stage="entered in the government's legislative plan, no text yet",
    wykaz_stage_adopted="the Council of Ministers has adopted the draft; it goes to the Sejm",
    wykaz_published="Entered in the plan",
    wykaz_planned="adoption by the government: Q{quarter} {year}",
    wykaz_metadata_note=("Scored from the register entry: the draft text does not exist yet."),
    wykaz_organ_unknown="the responsible ministry",
    action_wykaz_interest=(
        "you may register an interest in work on the draft (zgłoszenie zainteresowania): the law"
        " permits this once the plan is published — by letter to the body drafting it: {organ}"
    ),
    action_ministry_site="its office, ePUAP and e-Doręczenia addresses",
    action_rcl_interest=(
        "you may register an interest in work on the draft (zgłoszenie zainteresowania) — by"
        " letter to the body drafting it: {organ}"
    ),
    link_wykaz_entry="Register entry",
    tag_wykaz="wykazRM",
    rcl_process_closed="The project was closed on RCL without reaching the Sejm.",
    wykaz_process_closed="The government dropped the project: it was taken off the plan.",
    committee_report="committee report (sprawozdanie)",
    subcommittee_report="sub-committee report",
    proposes="proposes to",
    deadline_until="decision by",
    deadline_passed="deadline passed",
    stalled_for_weeks="no movement for {weeks} weeks",
    stalled_for_months="no movement for {months} months",
    urgent_mode="urgent procedure, tryb pilny",
    hearing_deadline_header="Public hearing: applications close",
    hearing_on="hearing on",
    hearing_apply_until="applications until",
    hearing_applications_closed="applications are closed",
    hearing_hint=(
        "anyone may apply, and the application goes to the Sejm no later than 10 days before the"
        " hearing (Regulamin Sejmu art. 70b); if the room cannot hold everyone, participation is"
        " capped in the order applications arrived — so it is worth applying at once"
    ),
    hearing_application_details=(
        "the application form goes to {email} with an electronic signature (qualified, personal"
        " or trusted); the form and the other ways to file are at the link below"
    ),
    tag_hearing="hearing",
    senate_deadline_header="The act is with the Senate",
    president_deadline_header="The act is with the President",
    senate_deadline_line="The Senate must decide by {date}",
    president_deadline_line="The President must decide by {date}",
    senate_deadline_body=(
        "This is the Senate decision deadline, not an opinion submission deadline. "
        "Contact depends on confirmed committee work."
    ),
    president_deadline_body=(
        "Sign the act, veto it or refer it to the Constitutional Tribunal"
        " (art. 122 of the Constitution)."
    ),
    senate_deadline_body_urgent=(
        "The Senate decision term is shorter under the urgent procedure. "
        "It is not an opinion submission deadline."
    ),
    president_deadline_body_urgent=(
        "Sign the act, veto it or refer it to the Constitutional Tribunal"
        " (art. 122 of the Constitution). The bill is urgent (tryb pilny, art. 123): the"
        " President has 7 days instead of the usual 21."
    ),
    deadline_counted_from_vote=(
        "Counted from the Sejm's vote: the real deadline is a few days later, as it runs from"
        " the day the act is handed over."
    ),
    amendments_senate="What the Senate's amendments change",
    amendments_committee="What the amendments change (per the committee's report)",
    link_amendments="Amendments",
    link_supplement="Document (PDF)",
    supplement_unreadable="The document could not be read — it is at the link below.",
    digest_header="The week in the channel",
    digest_figures="The week in figures",
    digest_found="New bill records found: {}",
    digest_filtered="Filtered out during relevance checks: {}",
    digest_published="New explainers published: {}",
    digest_no_data="complete data unavailable",
    digest_cards="New bills",
    digest_updates="What changed",
    digest_remember="What to remember",
    digest_actions="What to do next week",
    digest_consultations="Consultations still open",
    digest_sittings="Sittings ahead",
    digest_quiet="Nothing was posted in the channel this week.",
    digest_month="The month in figures",
    digest_month_discovered="entries seen",
    digest_month_dropped="dropped by the keywords",
    digest_month_analyzed="read by the model",
    digest_month_published="cards published",
    digest_month_cost="spent on the model",
    digest_support="The channel is free and carries no advertising. If it helps you:",
    digest_and_more="and {} more — see the channel",
    digest_support_coffee="Buy me a coffee",
    digest_support_sponsor="GitHub Sponsors",
    tag_digest="#digest",
    supplement_headers={
        "government_position": "The government's position on the bill",
        "impact_assessment": "Assessment of the effects (OSR)",
    },
    supplement_supports={
        "yes": "the government backs the bill",
        "no": "the government is against the bill",
    },
    deadline_passed_labels={
        "president": "the 21 days for the signature are out",
        "president_after_veto": "the 7 days for the signature are out",
    },
    urgent_deadline_passed_labels={
        "president": "the 7 days for the signature are out",
    },
    agenda_conditions={
        "second_reading_amendments": (
            "amendments are tabled at the second reading and the Sejm refers them to this committee"
        ),
        "first_reading_referral": (
            "the Sejm finishes the first reading and refers the bill to this committee"
        ),
        "senate_amendments": (
            "the Senate adopts amendments and the Sejm refers them to this committee"
        ),
        "referral": "the Sejm refers the bill to this committee",
    },
    update_headers={
        "update": "Update",
        "print_assigned": "Print number assigned",
        "start": "Bill received by the Sejm",
        "first_reading_referral": "Referred to the first reading",
        "referral": "Referred to a committee",
        "referrals": "Referred to committees",
        "referral_plenary": "First reading at a Sejm sitting",
        "first_reading": "First reading held",
        "committee_work": "Committee work started",
        "committee_report": "Committee report",
        "subcommittee_report": "Sub-committee report",
        "committee_rejects": "The committee proposes to reject the bill",
        "hearing": "Public hearing announced",
        "second_reading": "Second reading held",
        "second_reading_amendments": "Amendments at the 2nd reading: back to the committee",
        "third_reading": "Third reading",
        "voting": "A vote was held",
        "passed": "The Sejm passed the bill",
        "rejected": "The Sejm rejected the bill",
        "withdrawn_by_applicant": "The bill was withdrawn",
        "veto_sustained": "The President's veto stood",
        "veto_overridden": "The Sejm overrode the veto: the act is passed again",
        "not_enacted": "The process is over: no law was enacted",
        "decision_unknown": "The decision outcome is not confirmed yet",
        "senate": "Senate position",
        "senate_no_amendments": "The Senate passed the act without amendments",
        "senate_amendments": "The Senate introduced amendments",
        "senate_rejected": "The Senate rejected the act",
        "senate_considered": "The Sejm considered the Senate's amendments",
        "to_president": "Sent to the President",
        "signed": "The President signed the act",
        "veto": "The President vetoed the act",
        "tribunal": "Referred to the Constitutional Tribunal",
        "tribunal_ruled": "The Constitutional Tribunal has ruled",
        "text_changed": "New version of the text",
        "government_position": "The government has spoken on the bill",
        "impact_assessment": "An assessment of the bill's effects was filed",
        "withdrawn": "Bill withdrawn",
        "abandoned": "Bill no longer followed",
        "discontinued": "Bill lapsed with the end of the term",
        "rcl_stage": "New stage on RCL",
        "consultation_opened": "The public consultation is open",
        "rcl_to_sejm": "Sent to the Sejm",
        "rcl_closed": "Project closed on RCL",
        "rcl_started": "Draft published on RCL",
        "wykaz_withdrawn": "The government dropped the project",
        "wykaz_adopted": "The government adopted the project",
    },
    decision_labels={
        "niezwłocznie przystąpiono do iii": "moved straight on to the 3rd reading",
        "skierowano ponownie do komisji": "sent back to the committee to consider amendments",
        "skierowano do komisji": "referred to a committee",
        # Longer first: `_translate` matches on the first fragment found, and "uchwalono
        # ponownie" contains "uchwalono".
        "uchwalono ponownie": "the veto overridden, the act passed again",
        "nie uchwalona ponownie": "not passed again, the veto stood",
        "przyjęto część poprawek": "some of the Senate's amendments accepted",
        "przyjęto poprawki": "the Senate's amendments accepted",
        "odrzucono poprawki": "the Senate's amendments rejected",
        "uchwalono": "passed",
        "odrzucono": "rejected",
    },
    proposal_labels={
        "załączony projekt": "adopt the bill as amended (text attached)",
        "przyjąć bez poprawek": "adopt without amendments",
        "przyjąć część poprawek": "accept some of the amendments",
        "odrzucić poprawki": "reject the amendments",
        "przyjąć poprawki": "accept the amendments",
        "odrzucić": "reject the bill",
    },
    event_tags={
        "voting": "vote",
        "senate": "senate",
        "president": "president",
        "veto": "veto",
        "amendments": "amendments",
        "government_position": "government",
        "impact_assessment": "impactassessment",
        "consultations": "consultation",
        "committee": "committee",
        "hearing": "hearing",
        "passed": "passed",
        "rejected": "notenacted",
        "tribunal": "tribunal",
        "withdrawn": "withdrawn",
        "discontinued": "lapsed",
    },
    next_step_labels={
        "pre_print": "print number assignment, then the first reading",
        "pre_print_consultation": (
            "consultation until {date}, then print number assignment and the first reading"
        ),
        "first_reading": "first reading",
        "first_reading_committee": "first reading in committee — {committee}",
        "first_reading_committee_unnamed": "first reading in committee",
        "first_reading_sitting": "first reading at a Sejm sitting",
        "committee_work": (
            "committee work — {committee} (report), then the second reading at a Sejm sitting"
        ),
        "committee_work_unnamed": "committee work (report), then the second reading in the Sejm",
        "second_reading": "second reading at a Sejm sitting",
        "second_reading_committee": (
            "the committee works on the second reading's amendments — {committee} (additional"
            " report), then the third reading"
        ),
        "second_reading_committee_unnamed": (
            "the committee works on the second reading's amendments, then the third reading"
        ),
        "third_reading": "third reading and the vote in the Sejm",
        "senate": "consideration by the Senate (up to 30 days)",
        "decision_unknown": (
            "the Sejm data does not yet give the decision; the next step is unknown"
        ),
        "senate_amendments": "the Sejm considers the Senate's amendments",
        "senate_rejection": (
            "the Sejm votes on the Senate's rejection: the law passes only if the Sejm throws"
            " that rejection out by an absolute majority"
        ),
        "president": (
            "the President's signature (up to 21 days), then publication in Dziennik Ustaw"
        ),
        "president_overdue": "the President's signature, then publication in Dziennik Ustaw",
        "president_after_senate_silence": (
            "the Senate let its 30 days pass — under art. 121 ust. 2 the act counts as passed in"
            " the Sejm's wording and goes to the President (signature within 21 days), then"
            " publication in Dziennik Ustaw. The Sejm has not recorded the hand-over yet"
        ),
        "president_after_veto": (
            "the President's signature — once the veto is overridden he has 7 days and no"
            " veto or Tribunal left (art. 122 ust. 5), then publication in Dziennik Ustaw"
        ),
        "publication": "publication in Dziennik Ustaw",
        "in_force": "entry into force on {date}",
        "in_force_unknown": "entry into force (date not stated yet)",
        "veto": (
            "the committee considers the veto — {committee}, then the Sejm votes: the veto is"
            " overridden only if 3/5 vote for the act again"
        ),
        "veto_unnamed": "the Sejm votes on the veto: overriding it takes a 3/5 majority",
        "tribunal": "ruling of the Constitutional Tribunal",
        "tribunal_after_ruling": (
            "the next step after the Tribunal's ruling: the President's signature, a new print"
            " or publication in Dziennik Ustaw"
        ),
        "wykaz": (
            "the draft published on RCL with a public consultation, then the committees of the"
            " Council of Ministers, the Council itself and the Sejm"
        ),
        "wykaz_to_rcl": "the draft published on RCL with a public consultation",
        "wykaz_adopted": "submission to the Sejm and a print number",
        "rcl_consultation": (
            "public consultation until {date}, then opinions, the committees of the Council of"
            " Ministers, the Council and submission to the Sejm"
        ),
        "rcl_consultation_undated": (
            "public consultation (the deadline is in the letter), then opinions, the committees"
            " of the Council of Ministers, the Council and submission to the Sejm"
        ),
        "rcl_opinions": (
            "inter-ministerial agreement and opinions, then the committees of the Council of"
            " Ministers, the Council and submission to the Sejm"
        ),
        "rcl_committees": (
            "committees of the Council of Ministers and Komisja Prawnicza, then the Council and"
            " submission to the Sejm"
        ),
        "rcl_council": "adoption by the Council of Ministers, then the Sejm and a print number",
        "rcl_to_sejm": "print number assignment in the Sejm, then the first reading",
    },
    typical_durations={
        "pre_print": "usually days to months",
        "first_reading": "usually 2–6 weeks after submission",
        "first_reading_committee": "usually 2–6 weeks after submission",
        "first_reading_sitting": "usually 2–6 weeks after submission",
        "committee_work": "weeks to a year",
        "second_reading": "often at the same sitting as the third reading",
        "second_reading_committee": "usually days — until the next block of votes",
        "third_reading": "often at the same sitting as the second reading",
        "senate_amendments": "usually at the next Sejm sitting",
        "senate_rejection": "usually at the next Sejm sitting",
        "veto": "the Sejm votes when it chooses: weeks to the end of the term",
        "tribunal": "the Tribunal takes months",
        "publication": "usually 1–4 weeks after the signature",
        "wykaz": "usually 1–6 months until the draft is published",
        "wykaz_to_rcl": "usually a few weeks",
        "wykaz_adopted": "usually a few weeks",
        "rcl_opinions": "usually 1–3 months at this stage; the whole RCL path takes 3–12",
        "rcl_committees": "usually 1–3 months",
        "rcl_council": "usually a few weeks",
        "rcl_to_sejm": "usually a few days",
    },
    urgent_step_labels={
        "senate": "consideration by the Senate (urgent procedure: up to 14 days)",
        "president": (
            "the President's signature (urgent procedure: up to 7 days), then publication in"
            " Dziennik Ustaw"
        ),
    },
    urgent_durations={
        "first_reading": "usually a few days after submission",
        "first_reading_committee": "usually a few days after submission",
        "first_reading_sitting": "usually a few days after submission",
        "committee_work": "days rather than weeks",
        "second_reading": "the third reading usually follows at once",
        "third_reading": "usually at the same sitting as the second reading",
        "senate_amendments": "usually at the next Sejm sitting",
        "publication": "usually a few days after the signature",
    },
    no_action_labels={
        "pre_print": "nothing yet — next chance: comments to the committee after the first reading",
        "decision_unknown": (
            "check the documents linked on the Sejm website; the next action's deadline is unknown"
        ),
        "pre_print_consultation": (
            "nothing yet — next chance: comments to the committee after the first reading"
        ),
        "first_reading": (
            "nothing yet — next chance: comments to the committee after the first reading"
        ),
        "first_reading_committee": (
            "nothing yet — next chance: comments to the committee after the first reading"
        ),
        "first_reading_sitting": (
            "nothing yet — next chance: comments to the committee after the first reading"
        ),
        "committee_work": (
            "write to the committee handling the bill — its name is on the Sejm process page"
        ),
        "second_reading": (
            "nothing yet — after the Sejm vote an opinion can go to the Senate committee"
        ),
        "second_reading_committee": (
            "write to the committee working on the amendments — its name is on the Sejm process"
            " page"
        ),
        "third_reading": (
            "nothing yet — after the Sejm vote an opinion can go to the Senate committee"
        ),
        "senate": "nothing yet — the Senate committees have been through it, the Senate votes next",
        "senate_amendments": "nothing yet — the Sejm decides on the Senate's amendments",
        "senate_rejection": "nothing yet — the Sejm decides whether to throw out the rejection",
        "president": "nothing yet — the act is with the President",
        "president_after_senate_silence": "nothing yet — the act is with the President",
        "president_after_veto": "nothing yet — the President must sign within 7 days",
        "publication": "nothing yet — waiting for publication in Dziennik Ustaw",
        "in_force": "nothing yet — the act is passed, prepare for its entry into force",
        "in_force_unknown": "nothing yet — the act is passed, the entry-into-force date is unknown",
        "veto": "nothing yet — the Sejm decides",
        "tribunal": "nothing yet — the Constitutional Tribunal decides",
        "tribunal_after_ruling": (
            "nothing yet — the next step depends on the ruling; watching for the President's"
            " signature, a new print or publication in Dz.U."
        ),
        "wykaz": "nothing yet — waiting for the draft on RCL, which opens the consultation",
        "rcl_consultation": "nothing yet — the consultation on this draft has closed",
        "rcl_opinions": "nothing yet — the draft is being agreed inside the government",
        "rcl_committees": "nothing yet — the draft is with the Council of Ministers' committees",
        "rcl_council": "nothing yet — the draft awaits adoption by the Council of Ministers",
        "wykaz_to_rcl": (
            "nothing yet — waiting for the draft on RCL, which opens the consultation"
        ),
        "wykaz_adopted": (
            "nothing yet — the government adopted the draft; waiting for the Sejm and a print"
            " number"
        ),
        "rcl_to_sejm": (
            "nothing yet — waiting for the print number, then first reading and committee"
        ),
    },
    path_steps={
        "wykaz": "plan",
        "rcl": "RCL",
        "sejm": "Sejm",
        "committee": "committees",
        "readings": "2nd and 3rd reading",
        "senate": "Senate",
        "president": "President",
        "journal": "Dz.U.",
        "in_force": "in force",
    },
    stage_labels={
        "Start": "submitted to the Sejm",
        "ReadingReferral": "referred to the first reading",
        "Referral": "referred to committee",
        "Reading": "first reading in committee",
        "CommitteeWork": "committee work",
        "CommitteeReport": "committee report (sprawozdanie)",
        "Voting": "vote in the Sejm",
        "SenatePosition": "Senate position",
        "End": "Sejm process closed",
    },
    rcl_stage_labels={
        "zgłoszenia lobbingowe": "lobbying declarations",
        "uzgodnienia": "inter-ministerial agreement",
        "konsultacje publiczne": "public consultation",
        "opiniowanie": "opinions of ministries and partners",
        "komisja prawnicza": "the government's Legal Commission",
        "stały komitet": "Standing Committee of the Council of Ministers",
        "komitet": "committee of the Council of Ministers",
        "notyfikacja": "notification to the European Commission",
        "rada ministrów": "Council of Ministers",
        "do sejmu": "sent to the Sejm",
    },
    stage_type_labels={
        "ToPresident": "Sent to the President",
        "PresidentSignature": "✍️ Signed by the President",
        "Veto": "⛔ Vetoed by the President",
        "PresidentToTribunal": "⚖️ Referred by the President to the Constitutional Tribunal",
        "ConstitutionalTribunalRuling": "⚖️ Ruling of the Constitutional Tribunal",
        "PublicHearing": "📢 Public hearing (wysłuchanie publiczne)",
        "SenatePositionConsideration": "Sejm considered the Senate position",
        "PresidentMotionConsideration": "Sejm considered the President's veto",
        "GovermentPosition": "the government's position arrived",
        "Opinion": "an organisation's opinion arrived",
    },
    senate_position_labels={
        "nie wniósł poprawek": "Senate passed the bill without amendments",
        "wniósł poprawki": "Senate introduced amendments",
        "wniósł poprawkę": "Senate introduced an amendment",
        "odrzucił ustawę": "Senate rejected the bill",
    },
    category_labels={
        Category.LEGAL_STAY: "legal stay",
        Category.EMPLOYMENT: "employment",
        Category.SOCIAL: "social",
        Category.INDIRECT: "indirect",
        Category.MARGINAL: "marginal",
        Category.NONE: "not related",
    },
    category_tags={
        Category.LEGAL_STAY: "legalstay",
        Category.EMPLOYMENT: "employment",
        Category.SOCIAL: "social",
        Category.INDIRECT: "indirect",
        Category.MARGINAL: "marginal",
        Category.NONE: "other",
    },
    applicant_labels={
        ApplicantType.GOVERNMENT: "government",
        ApplicantType.DEPUTIES: "deputies",
        ApplicantType.SENATE: "Senate",
        ApplicantType.PRESIDENT: "President",
        ApplicantType.PRESIDIUM: "Sejm Presidium",
        ApplicantType.CITIZENS: "citizens",
        ApplicantType.COMMITTEE: "committee",
        ApplicantType.UNKNOWN: "unknown",
    },
)

LABELS: dict[str, Labels] = {"ru": RU, "en": EN}


def labels_for(language: str) -> Labels:
    return LABELS.get(language.lower(), EN)
