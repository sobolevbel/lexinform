"""Runtime configuration. Environment variables with the LEXINFORM_ prefix, or a .env file.

Every field that needs more than its name to be understood carries a `description`, which is
what `.env.example` and the operator's documentation say about it.
"""

from pathlib import Path
from typing import Annotated, Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict

from lexinform.models.batch import BatchKind

Effort = Literal["low", "medium", "high", "xhigh", "max"]
OpenAiEffort = Literal["none", "low", "medium", "high"]
"""GPT-5.1's own `reasoning_effort` values; it has no `xhigh`/`max`."""


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="LEXINFORM_", env_file=".env", env_file_encoding="utf-8", extra="ignore"
    )

    term: int | None = Field(
        default=None,
        description="Pins the Sejm term. Empty takes the one the API flags as current, so the"
        " bot moves to a new kadencja by itself.",
    )
    sejm_api_base_url: str = "https://api.sejm.gov.pl"
    orka_base_url: str = Field(
        default="https://orka.sejm.gov.pl",
        description="Where the Sejm serves the text of a bill that has no print number yet."
        " A host of its own because it is a host of its own: Imperva in front, its own verdict"
        " on our client, and a failure there must not stop what api.sejm.gov.pl is serving.",
    )
    sejm_page_size: int = 100
    sejm_timeout_seconds: float = 30.0
    sejm_concurrency: int = Field(
        default=4, ge=1, description="Parallel PDF downloads and process lookups."
    )

    rcl_enabled: bool = Field(
        default=True, description="Follow government projects on legislacja.rcl.gov.pl."
    )
    rcl_base_url: str = "https://legislacja.rcl.gov.pl"
    rcl_timeout_seconds: float = Field(
        default=60.0, description="A project page takes some ten seconds to render."
    )
    rcl_concurrency: int = Field(
        default=6, ge=1, description="Projects read at once; the pages are slow."
    )
    rcl_proxy_url: str = Field(
        default="",
        description="RCL drops connections from outside the EU, GitHub runners included: an HTTP"
        " forward proxy with an EU address, `http://user:password@host:port`. Empty connects"
        " directly.",
    )

    wykaz_enabled: bool = Field(
        default=True,
        description="Follow the wykaz prac legislacyjnych RM: bills the government has only"
        " announced. One CSV of ~10 MB per run.",
    )
    wykaz_base_url: str = "https://www.gov.pl"
    wykaz_timeout_seconds: float = 60.0
    wykaz_proxy_url: str = Field(
        default="",
        description="gov.pl is a single Polish address, so it may one day need the same EU proxy"
        " as RCL; it answers GitHub runners today.",
    )

    senate_enabled: bool = Field(
        default=True,
        description="Name the Senate committees of an act in the Senate and their e-mail, read from"
        " senat.gov.pl (a few pages per run, only while an act is there).",
    )
    senate_base_url: str = "https://www.senat.gov.pl"
    senate_timeout_seconds: float = 30.0
    senate_proxy_url: str = Field(
        default="", description="An HTTP forward proxy with an EU address; empty connects directly."
    )

    db_path: Path = Path("lexinform.db")
    llm_batch_state_file: Path | None = Field(
        default=None, description="Git state dump checkpoint before and after remote submission."
    )
    llm_batch_state_branch: str = "state"

    anthropic_api_key: str | None = Field(
        default=None,
        validation_alias="ANTHROPIC_API_KEY",
        description="Read under its plain name, without the LEXINFORM_ prefix, so that one"
        " variable serves both this app and the anthropic SDK.",
    )
    llm_effort: Effort = Field(
        default="medium", description="Claude's own thinking effort, whichever call reaches it."
    )
    llm_max_tokens: int = Field(
        default=4000, description="Claude's own output cap, whichever call reaches it."
    )
    llm_concurrency: int = Field(default=2, ge=1, description="Bills analysed at the same time.")
    llm_triage_model: str = Field(
        default="claude-sonnet-5",
        description="Cheap first pass on excerpts before the full analysis of a long print;"
        " empty disables it. Always Claude — the gate stays cheap and fast on purpose.",
    )
    openai_api_key: str | None = Field(
        default=None,
        validation_alias="OPENAI_API_KEY",
        description="Read under its plain name, without the LEXINFORM_ prefix, so that one"
        " variable serves both this app and the openai SDK.",
    )
    llm_openai_effort: OpenAiEffort = Field(
        default="medium", description="GPT-5.1's own reasoning effort, whichever call reaches it."
    )
    llm_openai_max_tokens: int = Field(
        default=8000,
        description="GPT-5.1's own output cap, whichever call reaches it — it bills reasoning"
        " tokens against this too, unlike Claude's adaptive thinking, so it sits above"
        " `llm_max_tokens`.",
    )
    llm_analysis_model: str = Field(
        default="gpt-5.1",
        description="Model for the full per-bill analysis (`analyze()`); GPT-5.1 since"
        " 2026-09-28 (96% agreement with Opus on relevance, zero missed bills, ~10x cheaper on"
        " 26 real prints and one scan). A `claude-` name routes it back to Claude with Claude's"
        " own analysis prompt.",
    )
    llm_analysis_overflow_model: str = Field(
        default="claude-opus-5-5",
        description="Batch analysis model for inputs exceeding the primary model's context.",
    )
    llm_amendments_model: str = Field(
        default="gpt-5.1",
        description="Model that summarises Senate/committee amendments; see `llm_analysis_model`.",
    )
    llm_supplement_model: str = Field(
        default="gpt-5.1",
        description="Model that digests a document filed to a print (government position, OSR,"
        " an opinion); see `llm_analysis_model`.",
    )
    llm_joint_model: str = Field(
        default="gpt-5.1",
        description="Model that compares one print of a jointly considered group with the"
        " others; see `llm_analysis_model`.",
    )
    llm_batch_enabled: bool = Field(
        default=True,
        description="Legacy setting; supported model calls always use batch, except triage.",
    )
    llm_batch_kinds: Annotated[frozenset[BatchKind], NoDecode] = frozenset(
        {"analysis", "reanalysis", "joint", "supplement", "amendments"}
    )
    consultation_reviews_enabled: bool = Field(
        default=False,
        description="Enable analysis and delivery of consultation document reviews; disabled"
        " while corpus quality checks are pending. Existing work and results are retained.",
    )
    llm_batch_max_wait_hours: float = Field(
        default=6, gt=0, description="Legacy setting; waiting never enables synchronous calls."
    )

    @field_validator("llm_batch_kinds", mode="before")
    @classmethod
    def parse_batch_kinds(cls, value: object) -> object:
        return (
            frozenset(part.strip() for part in value.split(",") if part.strip())
            if isinstance(value, str)
            else value
        )

    llm_batch_sync_within_days: int = Field(
        default=3,
        ge=0,
        description="Legacy setting; urgent bills use batch too.",
    )
    llm_batch_provider: Literal["anthropic", "openai"] = Field(
        default="openai",
        description="Legacy setting; each configured model selects its own batch provider.",
    )
    triage_min_chars: int = Field(
        default=20_000, description="Shorter texts go straight to the full analysis."
    )
    triage_min_confidence: float = Field(default=0.8, ge=0.0, le=1.0)
    triage_scan_pages: int = Field(
        default=8,
        ge=1,
        description="How many opening pages of a scanned document the cheap pass is shown."
        " The cost of the call then does not depend on how thick the paper is.",
    )
    change_review_max_ratio: float = Field(
        default=0.15,
        ge=0.0,
        le=1.0,
        description="A new text whose act differs in at most this share of words is asked of the"
        " triage model before a re-analysis; above it the text is read. 0 disables the review.",
    )
    change_review_max_chars: int = Field(
        default=60_000, ge=0, description="The changed passages the review is shown, at most."
    )
    max_analysis_cost_usd: float = Field(
        default=2.0,
        ge=0.0,
        description="A first analysis whose input alone is estimated above this is skipped"
        " (`skipped_cost`, revived with `lexinform reset`). 0 disables the guard.",
    )
    max_run_cost_usd: float = Field(
        default=15.0,
        ge=0.0,
        description="The analysis phase stops for the run once its model spend reaches this."
        " 0 disables the guard.",
    )
    output_language: str = "ru"
    reader_attention: Literal["off", "shadow", "on"] = "shadow"
    attention_urgent_days: int = Field(default=3, ge=0, le=14)
    attention_max_group: int = Field(default=5, ge=1, le=10)
    attention_roundup: Literal["run", "daily"] = "run"
    attention_daily_hour: int = Field(default=18, ge=0, le=23)
    text_budget_chars: int = Field(
        default=1_500_000,
        description="Safety cap only: Polish text is ~2 chars per token, so this is ~750k tokens"
        " and fits the 1M context of the default model. Real prints go in whole.",
    )
    max_part_chars: int = Field(
        default=300_000,
        description="A file inside a package that is longer than this and does not name itself"
        " (no USTAWA / UZASADNIENIE / Nazwa projektu heading) is not taken for a bill text."
        " The longest real one measured is 161,678 characters; the longest appendix filed as a"
        " nameless document, 954,730. 0 disables the guard.",
    )
    max_pdf_download_mb: int = Field(
        default=200,
        description="Safety valve only, not a relevance rule: the body is buffered in memory and"
        " unpacked zip members are capped by the same number. Real prints reach 40 MB (druk 2865:"
        " 346 pages with a text layer), and a 25 MB cap silently skipped them.",
    )

    telegram_bot_token: str = ""
    telegram_channel_id: str = ""
    telegram_log_channel_id: str = ""
    telegram_api_base_url: str = "https://api.telegram.org"

    inbox_dir: Path | None = Field(
        default=None,
        description="Where the operator commands wait: the relay files each as"
        " `{update_id}.json` into the git branch `inbox`, and a run reads the directory that"
        " branch is checked out in. Empty means no commands phase.",
    )

    @field_validator("inbox_dir", mode="before")
    @classmethod
    def _empty_inbox_dir_is_none(cls, value: object) -> object:
        """`LEXINFORM_INBOX_DIR=` (blank) means no inbox, not the current directory."""
        return None if isinstance(value, str) and not value.strip() else value

    github_repo: str = Field(
        default="", description="The relay's side: the inbox repository, as `owner/name`."
    )
    github_token: str = Field(
        default="",
        description="A fine-grained personal access token with Contents read/write on"
        " `github_repo`.",
    )
    inbox_branch: str = "inbox"
    listen_timeout_seconds: int = Field(
        default=50, ge=0, le=300, description="How long one getUpdates call waits for a post."
    )

    min_score: int = Field(default=3, ge=1, le=5)
    max_publish_per_run: int = 10
    max_analyze_per_run: int = 40
    max_analysis_attempts: int = 3
    text_prefilter_enabled: bool = Field(
        default=True, description="Scan the print PDF when the title says nothing."
    )
    text_prefilter_min_distinct: int = Field(
        default=2, description="Accept a text when this many different patterns occur in it."
    )
    text_prefilter_min_occurrences: int = Field(
        default=3, description="...or when the patterns occur this many times in total."
    )
    text_prefilter_max_per_run: int = 20
    pre_print_enabled: bool = Field(
        default=True, description="Also watch /bills for bills without a print number yet."
    )
    voting_club_breakdown: bool = Field(
        default=True, description="Fetch per-MP votes to show how each club voted."
    )
    max_publish_attempts: int = Field(
        default=3, description="Failed posts are retried on later runs up to this many times."
    )
    max_card_edits: int = Field(
        default=30,
        description="Cards re-rendered in place per run when what they say has drifted; bounds"
        " the run.",
    )
    first_run_lookback_days: int = 1
    rerun_overlap_days: int = 1
    runs_retention_days: int = Field(
        default=90, ge=7, description="Run records, with their reports, are kept this long."
    )
    history_payload_retention_days: int = Field(default=90, ge=7)
    analysis_memo_retention_days: int = Field(default=180, ge=7)
    track_closed_grace_days: int = Field(
        default=90,
        description="Publication in Dziennik Ustaw follows the Sejm's closure by 30 to 40 days.",
    )
    track_pending_decision_max_days: int = Field(
        default=1095,
        description="A law the Sejm has passed has an act ahead of it: the Senate, a veto or a"
        " referral to the Tribunal can hold it for years before one appears.",
    )
    track_full_weekday: int = Field(
        default=0, ge=0, le=6, description="Weekday of the full check; 0 is Monday."
    )
    in_force_reminders: bool = Field(
        default=True, description="Post a reminder on the day the act enters into force."
    )
    consultation_reminders: bool = Field(
        default=True,
        description="Remind before a public consultation closes, and before applications to a"
        " public hearing close.",
    )
    consultation_reminder_days: int = Field(default=3, ge=0)
    decision_reminders: bool = Field(
        default=True,
        description="Remind before the Senate's 30 days (art. 121) and the President's 21"
        " (art. 122) run out.",
    )
    decision_reminder_days: int = Field(
        default=7,
        ge=0,
        description="Wider than the consultation's window on purpose: both dates are counted from"
        " the stage before the hand-over, so they fall a few days early, and the Senate's"
        " committee takes the act well before day 30.",
    )
    agenda_watch: bool = Field(
        default=True,
        description="Post when a followed bill appears on a committee or Sejm sitting agenda.",
    )
    observe_unthreaded: bool = Field(
        default=True,
        description="Record the process of analysed bills that have no card, for the website.",
    )

    digest_enabled: bool = Field(
        default=True,
        description="Draft a weekly digest into the technical channel; it reaches readers only"
        " when the operator presses its button. Off without a log channel either way.",
    )
    digest_weekday: int = Field(
        default=6,
        ge=0,
        le=6,
        description="Weekday of the digest in Warsaw time, 0 being Monday; it covers the week"
        " that ends on it.",
    )
    digest_support_url: str = Field(
        default="",
        description="Where the monthly figures ask for support (buymeacoffee); empty says nothing.",
    )
    digest_sponsor_url: str = Field(
        default="", description="The second address of the same ask (GitHub Sponsors)."
    )

    log_level: str = "INFO"
    log_json: bool = False

    def require_telegram(self) -> None:
        missing = [
            name
            for name, value in (
                ("LEXINFORM_TELEGRAM_BOT_TOKEN", self.telegram_bot_token),
                ("LEXINFORM_TELEGRAM_CHANNEL_ID", self.telegram_channel_id),
            )
            if not value
        ]
        if missing:
            raise ValueError(f"Missing required settings: {', '.join(missing)}")
