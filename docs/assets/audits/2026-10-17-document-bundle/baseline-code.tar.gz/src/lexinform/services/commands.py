"""Operator commands from the technical channel, executed by a run.

Every command gets a `commands` row before anything runs, is executed, marked executed, answered
under its own message, marked handled and taken out of the inbox. A re-read file is measured
against the two marks: answered means drop it, executed but unanswered means repeat the answer
and do *not* run it again. An outage ends the phase and leaves the command for the next run.
"""

import datetime as dt
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from zoneinfo import ZoneInfo

from lexinform.errors import OrkaUnreachableError, ServiceUnavailableError
from lexinform.models import (
    DISPATCHED,
    FAILING_CHECK_MIN,
    SILENCED_BY_OPERATOR,
    Bill,
    BillStatus,
    Command,
    CommandName,
    CommandOutcome,
    CommandState,
    DeliveryResolution,
    IncomingCommand,
    Mnemonic,
    OutcomeStatus,
    PrintInfo,
    PriorityOverride,
    PublicationKind,
    PublicationStatus,
    SpendSnapshot,
    StatusSnapshot,
    TokenUsage,
    closure_event,
    is_over,
    merge_usage,
    parse_command,
    valid_mnemonic,
)
from lexinform.models.source_checks import observation_label, operator_observation
from lexinform.ports import BillRepository, Clock, CommandInbox, OperatorReplier, Publisher
from lexinform.pricing import cost_usd
from lexinform.services.amendments import AmendmentsService
from lexinform.services.analysis import AnalysisService, TooExpensiveError, Waiting
from lexinform.services.digest import DigestResult, DigestService
from lexinform.services.joint import primary_of
from lexinform.services.lookup import BillLookup, BillNotFoundError
from lexinform.services.publications import complete_delivery
from lexinform.services.publishing import PublishingService
from lexinform.services.text_prefilter import TextPrefilterService
from lexinform.services.tracking import StatusTrackingService, TrackingResult

log = logging.getLogger(__name__)

SKIPPED = frozenset(
    {
        BillStatus.SKIPPED_PREFILTER,
        BillStatus.SKIPPED_TEXT_PREFILTER,
        BillStatus.SKIPPED_COST,
        BillStatus.SKIPPED_CLOSED,
    }
)
WAITING = (
    BillStatus.ANALYSIS_PENDING,
    BillStatus.TEXT_PREFILTER_PENDING,
    BillStatus.ANALYSIS_FAILED,
    BillStatus.SKIPPED_COST,
    BillStatus.DOCUMENT_UNSUPPORTED,
    BillStatus.DOCUMENT_AMBIGUOUS,
)
FORCE_HINT = "add `force` to analyse anyway"
_CLOSURE_NOTES = {
    "veto_sustained": "the President's veto stood",
    "withdrawn_by_applicant": "withdrawn by the applicant",
    "rejected": "rejected",
    "not_enacted": "closed without a law",
}


def _day(when: dt.datetime | None) -> str:
    return str(when.date()) if when is not None else "an earlier run"


class _SourceDownError(ServiceUnavailableError):
    """A watcher of `/refresh` stopped because its source is down. `TrackingResult.fatal_error`
    already names the system, so the message is passed on as it is."""

    def describe(self) -> str:
        return str(self)


def _tracking_note(result: TrackingResult) -> str:
    """What `/refresh` found, in the counters that mean something to a reader of the channel.

    A source that was down while the rest of the phase ran is named: RCL is unreachable from a
    GitHub-hosted runner altogether, so without this every `/refresh` of an `RCL/…` bill in the
    daily workflow would answer "nothing new" about a page nobody read.
    """
    posts = (
        result.published
        + result.acts_published
        + result.in_force_posted
        + result.agenda_posted
        + result.consultation_results_posted
    )
    parts = [
        f"{posts} post(s)" if posts else "",
        "card refreshed" if result.cards_refreshed else "",
        f"{result.reanalyzed} re-analysis" if result.reanalyzed else "",
        f"{result.held} stage(s) held for the next post" if result.held else "",
        f"{result.failed} failure(s), see the log" if result.failed else "",
    ]
    said = " · ".join(p for p in parts if p)
    if result.partial_errors:
        down = "; ".join(result.partial_errors)
        return f"{said or 'nothing new from the sources that answered'} · not read: {down}"
    return said or "nothing new: the card and the stages are as they were"


@dataclass
class CommandsResult:
    """What the commands phase did; `lines` holds one line per command for the run report."""

    handled: int = 0
    failed: int = 0
    lines: list[str] = field(default_factory=list)
    input_tokens: int = 0
    output_tokens: int = 0
    usage: dict[str, TokenUsage] = field(default_factory=dict)
    fatal_error: str | None = None


def _count_usage(result: CommandsResult, spent: dict[str, TokenUsage]) -> None:
    merge_usage(result.usage, spent)
    for tokens in spent.values():
        result.input_tokens += tokens.input + tokens.cache_read
        result.output_tokens += tokens.output


class CommandService:
    def __init__(
        self,
        repo: BillRepository,
        inbox: CommandInbox,
        replier: OperatorReplier,
        lookup: BillLookup,
        analysis: AnalysisService,
        publishing: PublishingService,
        clock: Clock,
        *,
        text_prefilter: TextPrefilterService | None = None,
        tracking: StatusTrackingService | None = None,
        amendments: AmendmentsService | None = None,
        digest: DigestService | None = None,
        publisher_for: Callable[[str], Publisher] | None = None,
        status_days: int = 7,
        status_bills: int = 10,
        language: str = "ru",
    ) -> None:
        self._repo = repo
        self._inbox = inbox
        self._replier = replier
        self._lookup = lookup
        self._analysis = analysis
        self._publishing = publishing
        self._clock = clock
        self._language = language
        self._text_prefilter = text_prefilter
        self._tracking = tracking
        self._amendments = amendments
        self._digest = digest
        self._publisher_for = publisher_for
        self._status_days = status_days
        self._status_bills = status_bills

    def handle_pending(
        self,
        *,
        min_score: int,
        run_started_at: dt.datetime,
        publish: bool = True,
        dry_run: bool = False,
    ) -> CommandsResult:
        """Answer every waiting command; `run_started_at` is the run's own start, which every
        reply names. `dry_run` is the run's option, not the service's: the inbox is then left
        as it is, because its files belong to a real run (the database is rolled back with
        them)."""
        result = CommandsResult()
        for incoming in self._inbox.pending():
            if not self._handle_one(
                incoming,
                result,
                min_score=min_score,
                run_started_at=run_started_at,
                publish=publish,
                dry_run=dry_run,
            ):
                break
        return result

    def _handle_one(
        self,
        incoming: IncomingCommand,
        result: CommandsResult,
        *,
        min_score: int,
        run_started_at: dt.datetime,
        publish: bool,
        dry_run: bool,
    ) -> bool:
        """Answer one command; False when the phase must stop.

        A command an earlier run already answered is only dropped from the inbox. When the answer
        is the one that cannot be delivered, the command stays in the inbox marked executed, and
        the next run repeats the answer alone.
        """
        earlier = self._earlier_state(incoming)
        if earlier is not None and earlier.handled_at is not None:
            log.info("command %d answered before; inbox file dropped", incoming.update_id)
            self._done(incoming, dry_run=dry_run)
            return True
        started = time.perf_counter()
        spent: dict[str, TokenUsage] = {}
        if earlier is not None:
            outcome = self._answer_of_an_earlier_run(earlier)
        else:
            ran = self._run_now(incoming, spent, result, min_score=min_score, publish=publish)
            if ran is None:
                return False
            outcome = ran
        outcome = outcome.model_copy(
            update={
                "run_started_at": run_started_at,
                "seconds": round(time.perf_counter() - started, 1),
                "usage": spent,
            }
        )
        _count_usage(result, spent)
        try:
            self._answer(incoming, outcome, dry_run=dry_run)
        except ServiceUnavailableError as exc:
            result.fatal_error = exc.describe()
            log.error("aborting commands phase, %d unanswered: %s", incoming.update_id, exc)
            return False
        result.handled += 1
        result.failed += int(not outcome.ok)
        result.lines.append(f"{incoming.text} → {outcome.line()}")
        return True

    def _run_now(
        self,
        incoming: IncomingCommand,
        spent: dict[str, TokenUsage],
        result: CommandsResult,
        *,
        min_score: int,
        publish: bool,
    ) -> CommandOutcome | None:
        """Run the command and record that it ran; None when a source is down and the phase must
        stop. `spent` is filled as the command goes rather than returned: a command that raises
        halfway has still spent what it spent, and the report must say so."""
        try:
            outcome = self._execute(incoming, spent, min_score=min_score, publish=publish)
        except ServiceUnavailableError as exc:
            result.fatal_error = exc.describe()
            log.error("aborting commands phase: %s", result.fatal_error)
            return None
        except Exception as exc:
            log.exception("command %d failed: %s", incoming.update_id, exc)
            outcome = CommandOutcome(
                status=OutcomeStatus.ERROR, note=f"{type(exc).__name__}: {exc}"
            )
        self._repo.mark_command_executed(
            incoming.update_id, outcome=outcome.line(), at=self._clock.now()
        )
        return outcome

    def _earlier_state(self, incoming: IncomingCommand) -> CommandState | None:
        """What earlier runs did with this command, recording it when it is new. None means
        nobody has run it: the inbox file is its only trace."""
        if self._repo.record_command(incoming):
            return None
        return self._repo.command_state(incoming.update_id)

    @staticmethod
    def _answer_of_an_earlier_run(earlier: CommandState) -> CommandOutcome:
        """A command an earlier run took on. Running it again could post a second card, so its
        recorded outcome is repeated instead — and when the run died before recording one, the
        operator is told that and can send the command again, which is the safer way round."""
        if earlier.executed_at is None:
            return CommandOutcome(
                status=OutcomeStatus.EXECUTED_EARLIER,
                note=(
                    f"a run of {_day(earlier.received_at)} started this command and did not"
                    " finish; send it again if it left nothing behind"
                ),
            )
        return CommandOutcome(
            status=OutcomeStatus.EXECUTED_EARLIER,
            note=(
                f"the run of {earlier.executed_at.date()} ran this command but could not"
                f" answer: {earlier.reply or 'no record'}"
            ),
        )

    def _answer(self, incoming: IncomingCommand, outcome: CommandOutcome, *, dry_run: bool) -> None:
        """Reply under the command's own message and drop its inbox file.

        An outage of the channel propagates: the phase ends and the answer is repeated next run.
        A reply that failed for any other reason is noted and the command is marked handled all
        the same — the command itself ran, and running it again could post a second card.
        """
        line = outcome.line()
        try:
            self._replier.reply(incoming, outcome)
        except ServiceUnavailableError:
            raise
        except Exception as exc:
            log.exception("reply to command %d failed: %s", incoming.update_id, exc)
            line += f" (reply failed: {exc})"
        self._repo.mark_command_handled(incoming.update_id, reply=line, at=self._clock.now())
        self._done(incoming, dry_run=dry_run)

    def _done(self, incoming: IncomingCommand, *, dry_run: bool) -> None:
        if not dry_run:
            self._inbox.done(incoming)

    def _execute(
        self,
        incoming: IncomingCommand,
        spent: dict[str, TokenUsage],
        *,
        min_score: int,
        publish: bool,
    ) -> CommandOutcome:
        command = parse_command(incoming.text)
        if command is None:
            return CommandOutcome(status=OutcomeStatus.HELP, note="not a command")
        if command.error or command.name is CommandName.HELP:
            return CommandOutcome(status=OutcomeStatus.HELP, note=command.error or "")
        if command.name is CommandName.STATUS:
            return self._status()
        if command.name is CommandName.DELIVERY:
            return self._delivery(command, incoming, publish=publish)
        if command.name is CommandName.RUNS:
            return self._runs(command.count("days", 30), include_all="all" in command.options)
        if command.name is CommandName.COST:
            return self._cost(command.count("days", 30), command.count("top", 5))
        if command.name is CommandName.FIND:
            assert command.query is not None, "parse_command gives /find a query or an error"
            return self._find(command.query)
        if command.name is CommandName.DIGEST:
            return self._digest_command(command, publish=publish)
        if command.name in DISPATCHED:
            # The relay starts the workflow itself and files nothing, so this can only be an
            # old file or a hand-written one; either way there is nothing here to execute.
            return CommandOutcome(
                status=OutcomeStatus.HELP,
                note=f"/{command.name} is the relay's own command: it starts this workflow with"
                " that phase, and a run cannot ask itself for one",
            )
        assert command.ref is not None, (
            "only a bill command is left, and parse_command gives it a ref"
        )
        try:
            if command.name is CommandName.ANALYZE:
                bill = self._lookup.continuation(self._lookup.load_ref(command.ref))
                done = self._analyze(bill, command, spent, min_score=min_score, publish=publish)
                return done.model_copy(update={"as_json": command.as_json})
            bill_or_none = self._lookup.find_ref(command.ref)
        except BillNotFoundError as exc:
            return CommandOutcome(status=OutcomeStatus.NOT_FOUND, note=str(exc))
        if bill_or_none is None:
            return CommandOutcome(
                status=OutcomeStatus.NOT_FOUND,
                note=f"{command.ref.label} is not in the database; /analyze fetches it",
            )
        if command.name is CommandName.AMENDMENTS:
            if self._amendments is None:
                return CommandOutcome(status=OutcomeStatus.ERROR, note="amendments service is off")
            bill = self._lookup.continuation(bill_or_none)
            return self._amendments.request(
                bill,
                publication_id=command.count("publication", 0) or None,
                force_id=str(incoming.update_id) if command.force else "",
            )
        if command.name in (CommandName.SHOW, CommandName.REFRESH):
            return self._inspect(
                bill_or_none, spent, refresh=command.name is CommandName.REFRESH, publish=publish
            )
        if command.name is CommandName.SKIP:
            return self._skip(bill_or_none)
        if command.name is CommandName.UNSKIP:
            return self._unskip(bill_or_none)
        if command.name is CommandName.RESET:
            wanted = command.options.get("to", BillStatus.ANALYSIS_PENDING.value)
            return self._reset(bill_or_none, BillStatus(wanted))
        if command.name is CommandName.OBSERVE:
            return self._observe(bill_or_none, command.options["mode"], min_score=min_score)
        if command.name in (CommandName.NAME, CommandName.ATTENTION):
            return self._editorial(bill_or_none, command, incoming)
        if command.name is CommandName.PREVIEW:
            try:
                bill = self._lookup.continuation(bill_or_none)
            except BillNotFoundError as exc:
                return CommandOutcome(status=OutcomeStatus.ERROR, note=str(exc))
            return self._preview(bill, command.options.get("to"))
        if command.name is CommandName.FORGET:
            return self._forget(bill_or_none, min_score=min_score)
        return self._republish(bill_or_none, publish=publish)

    def _editorial(self, bill: Bill, command: Command, incoming: IncomingCommand) -> CommandOutcome:
        if bill.status is BillStatus.LINKED and bill.linked_number:
            bill = self._repo.get(bill.term, bill.linked_number) or bill
        editorial = bill.editorial
        if command.name is CommandName.NAME:
            if not command.editorial_name:
                name = editorial.mnemonic
                proposed = editorial.proposed
                return CommandOutcome(
                    status=OutcomeStatus.SHOWN,
                    bill=bill,
                    note=(
                        f"name: {name.name if name else 'fallback'}; "
                        f"proposal: {proposed.name if proposed else 'none'}; "
                        f"previous: {', '.join(item.name for item in editorial.previous) or 'none'}"
                    ),
                )
            if not valid_mnemonic(command.editorial_name):
                return CommandOutcome(
                    status=OutcomeStatus.ERROR,
                    bill=bill,
                    note="Name must contain 1–4 words, normal spaces and no HTML, URL or hashtag.",
                )
            candidate = Mnemonic(
                name=command.editorial_name,
                language=self._language,
                basis=command.editorial_reason,
                selected_at=self._clock.now(),
                origin="operator",
                command_update_id=incoming.update_id,
                actor_id=incoming.actor_id,
                author_signature=incoming.author_signature,
            )
            self._repo.save_editorial(bill.term, bill.number, editorial.rename(candidate))
            return CommandOutcome(
                status=OutcomeStatus.SHOWN,
                bill=self._reload(bill),
                note="Editorial name saved; existing messages keep their saved payload.",
            )
        if command.editorial_priority is None or command.editorial_until is None:
            posts = self._repo.list_attention_publications(bill.term, bill.number, limit=20)
            notes = [
                f"{post.id}: {post.kind} · {post.status}"
                f" · {post.attention.importance}/{post.attention.urgency}"
                f" · {', '.join(post.attention.reasons)}"
                f" · novelty={post.attention.novelty}"
                " · destination="
                f"{post.delivery.destination if post.delivery else 'retained history'}"
                f" · owner={self._repo.digest_owner(post.id) if post.id is not None else None}"
                for post in posts
                if post.attention is not None
            ]
            notes.extend(
                f"document review {work.purpose}: waiting for "
                f"{'batch result' if work.context is not None else 'official documents'}"
                f" · queued since {work.since.isoformat()}"
                f" · {work.limitation}"
                for work in bill.review_work
            )
            notes.extend(
                f"document review {record.review.purpose}: complete={record.review.complete}"
                f" · unresolved={len(record.review.unresolved)}"
                for record in (bill.consultation_review, bill.act_application_review)
                if record is not None
            )
            return CommandOutcome(
                status=OutcomeStatus.SHOWN,
                bill=bill,
                note="\n".join(notes) or "No saved event assessment yet.",
            )
        expires_at = dt.datetime.combine(
            command.editorial_until + dt.timedelta(days=1),
            dt.time(),
            tzinfo=ZoneInfo("Europe/Warsaw"),
        ).astimezone(dt.UTC)
        if expires_at <= self._clock.now():
            return CommandOutcome(
                status=OutcomeStatus.ERROR,
                bill=bill,
                note="Priority expiry must be today or later in Warsaw.",
            )
        override = PriorityOverride(
            reason=command.editorial_reason,
            expires_at=expires_at,
            selected_at=self._clock.now(),
            command_update_id=incoming.update_id,
            urgent=command.editorial_priority == "urgent",
            important=command.editorial_priority == "important",
            actor_id=incoming.actor_id,
            author_signature=incoming.author_signature,
        )
        self._repo.save_editorial(
            bill.term,
            bill.number,
            editorial.model_copy(
                update={
                    "priority": override,
                    "priority_history": editorial.priority_history
                    + ((editorial.priority,) if editorial.priority else ()),
                }
            ),
        )
        return CommandOutcome(
            status=OutcomeStatus.SHOWN,
            bill=self._reload(bill),
            note="Priority raised until the stated Warsaw date; attempted deliveries keep plans.",
        )

    def _analyze(
        self,
        bill: Bill,
        command: Command,
        spent: dict[str, TokenUsage],
        *,
        min_score: int,
        publish: bool,
    ) -> CommandOutcome:
        """`/analyze`: the prefilter, the model and the publishing rule, as the daily run applies
        them; `force` gets past the first two, `publish` past the score threshold."""
        if not command.force:
            bill, skipped = self._skipped_by_prefilter(bill)
            if skipped is not None:
                return skipped
        if command.force or bill.analysis is None or bill.status is not BillStatus.ANALYZED:
            bill, too_expensive = self._analyse_now(bill, spent, force=command.force)
            if too_expensive is not None:
                return too_expensive
        assert bill.analysis is not None, "the bill was analysed before or by _analyse_now above"
        return self._card_verdict(bill, command, min_score=min_score, publish=publish)

    def _skipped_by_prefilter(self, bill: Bill) -> tuple[Bill, CommandOutcome | None]:
        """The prefilter's answer, with the row as it stands after the text stage may have run."""
        if bill.status in SKIPPED:
            reason = bill.last_error or "title prefilter: no keyword hits"
            return bill, CommandOutcome(
                status=OutcomeStatus.SKIPPED, bill=bill, note=f"{reason}; {FORCE_HINT}"
            )
        if bill.status is BillStatus.TEXT_PREFILTER_PENDING and self._text_prefilter:
            accepted = self._text_prefilter.check(bill)
            bill = self._reload(bill)
            if not accepted:
                reason = bill.last_error or "text prefilter: no keyword hits"
                return bill, CommandOutcome(
                    status=OutcomeStatus.SKIPPED, bill=bill, note=f"{reason}; {FORCE_HINT}"
                )
        return bill, None

    def _analyse_now(
        self, bill: Bill, spent: dict[str, TokenUsage], *, force: bool
    ) -> tuple[Bill, CommandOutcome | None]:
        """Ask the model, and count the triage too: the operator pays for both.

        A text over the per-bill limit gets the answer the analysis phase gives it, so that the
        queue looks the same whoever hit the guard, and so does a file the host would not hand
        over: the operator is told to ask again rather than being given a verdict on a text
        nobody read, and `force` is no answer to a WAF.
        """
        try:
            analysed = self._analysis.analyze_bill(bill, ignore_cost_limit=force)
        except OrkaUnreachableError as exc:
            return bill, CommandOutcome(
                status=OutcomeStatus.SKIPPED,
                bill=self._reload(bill),
                note=f"{exc}; the bill stays queued, send the command again later",
            )
        except TooExpensiveError as exc:
            self._repo.set_status(
                bill.term,
                bill.number,
                BillStatus.SKIPPED_COST,
                reason=f"analysis skipped: {exc}",
            )
            return bill, CommandOutcome(
                status=OutcomeStatus.SKIPPED,
                bill=self._reload(bill),
                note=f"{exc}; {FORCE_HINT}",
            )
        spent.update(analysed.usage)
        if isinstance(analysed, Waiting):
            return self._reload(bill), CommandOutcome(
                status=OutcomeStatus.QUEUED,
                bill=self._reload(bill),
                note="queued to the batch; the result is applied when the batch completes",
            )
        return self._reload(bill), None

    def _card_verdict(
        self, bill: Bill, command: Command, *, min_score: int, publish: bool
    ) -> CommandOutcome:
        """Whether the analysis earns a card now, and what to say when it does not."""
        assert bill.analysis is not None, "_analyze asks for a verdict only of an analysed bill"
        verdict = bill.analysis.analysis
        if not verdict.relevant:
            return CommandOutcome(
                status=OutcomeStatus.ANALYSED, bill=bill, note="not relevant: no card"
            )
        card = self._card(bill)
        if card is not None:
            return CommandOutcome(
                status=OutcomeStatus.ANALYSED,
                bill=bill,
                note=f"the card is in the channel already ({card})",
            )
        if (over := self._over_note(bill)) is not None:
            return CommandOutcome(status=OutcomeStatus.ANALYSED, bill=bill, note=over)
        if verdict.score < min_score and not command.publish:
            return CommandOutcome(
                status=OutcomeStatus.ANALYSED,
                bill=bill,
                note=f"importance {verdict.score} is under the threshold {min_score}:"
                " not posted; add `publish` to post anyway",
            )
        if not publish:
            return CommandOutcome(
                status=OutcomeStatus.ANALYSED, bill=bill, note="publishing is off in this run"
            )
        return self._post(bill, OutcomeStatus.ANALYSED)

    def _skip(self, bill: Bill) -> CommandOutcome:
        self._repo.reset_bill(
            bill.term,
            bill.number,
            BillStatus.SKIPPED_PREFILTER,
            reason=SILENCED_BY_OPERATOR,
        )
        card = self._card(bill)
        note = "silenced: it will not be analysed or posted"
        if card is not None:
            note += f"; its card ({card}) stays and is still followed"
        return CommandOutcome(status=OutcomeStatus.SILENCED, bill=self._reload(bill), note=note)

    def _unskip(self, bill: Bill) -> CommandOutcome:
        """Restoring a saved analysis must not schedule a new paid analysis."""
        if bill.status is BillStatus.ANALYZED:
            return CommandOutcome(
                status=OutcomeStatus.QUEUED,
                bill=bill,
                note="already analysed; /analyze BILL force asks the model again",
            )
        if bill.status is BillStatus.LINKED:
            # The row has handed its thread to its druk, which now renders that message id.
            # Queueing it again would pay for the analysis of a row nobody follows and put it
            # back into `CardRefresher`, where the two rows edit one card from two states.
            return CommandOutcome(
                status=OutcomeStatus.QUEUED,
                bill=bill,
                note="linked: its card belongs to"
                f" {bill.linked_number or 'the bill that continues it'}, ask for that one",
            )
        if bill.status is BillStatus.BATCH_PENDING:
            return CommandOutcome(
                status=OutcomeStatus.QUEUED,
                bill=bill,
                note="batch already pending; waiting for its result",
            )
        if bill.status in SKIPPED and bill.analysis is not None:
            self._repo.reset_bill(bill.term, bill.number, BillStatus.ANALYZED)
            return CommandOutcome(
                status=OutcomeStatus.QUEUED,
                bill=self._reload(bill),
                note="saved analysis restored; /analyze BILL force asks the model again",
            )
        self._revive_rcl(bill, BillStatus.ANALYSIS_PENDING)
        self._repo.reset_bill(
            bill.term,
            bill.number,
            BillStatus.ANALYSIS_PENDING,
            reason="queued by the operator (/unskip)",
        )
        return CommandOutcome(
            status=OutcomeStatus.QUEUED,
            bill=self._reload(bill),
            note=f"was {bill.status}; the next run analyses it",
        )

    def _reset(self, bill: Bill, to: BillStatus) -> CommandOutcome:
        """`/reset BILL to=STATUS`: any status with a clean budget of attempts, what `/unskip`
        does for the one status worth a word of its own.

        Analyses and posts are untouched, so a bill reset to `analysis_pending` is read again
        and one reset to `skipped_prefilter` is silenced while its card stays.
        """
        was = bill.status
        read_again = self._revive_rcl(bill, to)
        self._repo.reset_bill(bill.term, bill.number, to, reason="reset by the operator (/reset)")
        note = f"was {was} (attempts {bill.analysis_attempts}), now {to}"
        return CommandOutcome(
            status=OutcomeStatus.RESET,
            bill=self._reload(bill),
            note=f"{note}; project documents re-read from RCL" if read_again else note,
        )

    def _observe(self, bill: Bill, choice: str, *, min_score: int) -> CommandOutcome:
        """`/observe BILL mode=…`: pin how a bill without a card is watched, or hand it back."""
        has_card = self._publishing.has_sent_card(bill)
        analysis = bill.analysis.analysis if bill.analysis else None
        mode, basis = operator_observation(choice, analysis, has_card=has_card, min_score=min_score)
        self._repo.set_observation(bill.term, bill.number, mode, basis)
        note = f"was {observation_label(bill.observation_mode, bill.observation_basis)}, now"
        note += f" {observation_label(mode, basis)}"
        if has_card:
            note += "; the bill has a card, which is followed in full whatever its mode"
        return CommandOutcome(status=OutcomeStatus.OBSERVED, bill=self._reload(bill), note=note)

    def _revive_rcl(self, bill: Bill, to: BillStatus) -> bool:
        """A skipped RCL row keeps only the project's skeleton: read its documents again before
        the status is cleared, or an unreachable RCL leaves the bill queued on its metadata."""
        if to is not BillStatus.ANALYSIS_PENDING or bill.rcl is None or bill.rcl.text_documents():
            return False
        self._repo.save_rcl(bill.term, bill.number, self._lookup.read_rcl_project(bill.number))
        return True

    def _preview(self, bill: Bill, to: str | None = None) -> CommandOutcome:
        """The message as the channel would get it, rendered into the technical channel alone:
        what `/republish` would send, before it is sent.

        `PublishingService.plan` decides and not this method, or the operator would be shown a
        plain card where the channel sends a joint reply, or nothing at all.
        """
        if bill.analysis is None:
            # A print whose group already holds a card is a reply, and a reply is a message a
            # preview can render whether or not this print has been read yet — which is the one
            # thing a preview exists to show.
            if primary_of(self._repo, bill, self._publishing.channel_id) is None:
                return CommandOutcome(
                    status=OutcomeStatus.ERROR, bill=bill, note="not analysed: no card to render"
                )
        elif not bill.analysis.analysis.relevant:
            return CommandOutcome(
                status=OutcomeStatus.ERROR,
                bill=bill,
                note="not relevant: the channel would never get this card",
            )
        card = self._card(bill)
        note = f"the card in the channel is {card}" if card else "not posted to the channel"
        plan = self._publishing.plan(bill)
        if plan.inherited is not None:
            note = (
                f"continues {bill.linked_number}: no message of its own, its card is"
                f" message {plan.inherited.message_id} re-rendered with both tags"
            )
        elif plan.primary is not None:
            note = (
                f"considered jointly with {plan.primary.number}: a reply under its card"
                f" (message {plan.primary_message_id}), not a card of its own"
            )
            if plan.bill.joint is None:
                # A read-only command spends nothing, and the comparison is a model call: it is
                # made when the reply is actually sent, so the preview shows the reply without it.
                note += "; what differs is compared when the reply goes out"
        if to is not None:
            note = self._preview_to(plan.bill, plan.print_info, to)
        return CommandOutcome(
            status=OutcomeStatus.PREVIEWED,
            bill=plan.bill,
            note=note,
            print_info=plan.print_info,
            joint_primary=plan.primary,
        )

    def _preview_to(self, bill: Bill, print_info: PrintInfo | None, chat: str) -> str:
        """`/preview BILL to=CHAT`: the card into a test chat, `lexinform preview --to`'s twin.

        It is a card and not a publication: no `publications` row, so nothing about the channel
        changes and the bill is no more published afterwards than before.
        """
        if self._publisher_for is None:
            return f"cannot send to {chat}: this run publishes nowhere but its own channel"
        result = self._publisher_for(chat).publish_new_bill(bill, print_info)
        return f"sent to {chat} as message {result.message_id}; nothing was recorded"

    def _inspect(
        self, bill: Bill, spent: dict[str, TokenUsage], *, refresh: bool, publish: bool
    ) -> CommandOutcome:
        path = [bill.number]
        try:
            bill = self._lookup.continuation(bill, path)
            outcome = (
                self._refresh(bill, spent, publish=publish)
                if refresh
                else CommandOutcome(status=OutcomeStatus.SHOWN, bill=bill)
            )
            if outcome.bill is not None:
                bill = self._lookup.continuation(outcome.bill, path)
                outcome = outcome.model_copy(update={"bill": bill})
        except BillNotFoundError as exc:
            return CommandOutcome(status=OutcomeStatus.ERROR, note=str(exc))
        if len(path) > 1:
            note = "linked: " + " → ".join(path)
            if outcome.note:
                note += "\n" + outcome.note
            outcome = outcome.model_copy(update={"note": note})
        return outcome

    def _refresh(
        self, bill: Bill, spent: dict[str, TokenUsage], *, publish: bool
    ) -> CommandOutcome:
        """Everything the next run would look at for this bill, now: its stages, its source's
        watcher and its card. The reader waits for the Sejm, not for our schedule.

        A bill with no card is refused: every poster reads that card for the message to reply
        under, so tracking one would drop a status update into the channel on its own.
        """
        if self._tracking is None:
            return CommandOutcome(
                status=OutcomeStatus.ERROR, bill=bill, note="tracking is off in this run"
            )
        if publish and self._card(bill) is None:
            return CommandOutcome(
                status=OutcomeStatus.ERROR,
                bill=bill,
                note="no card in the channel: an update would have nothing to reply under."
                " /analyze BILL publish posts the card first",
            )
        result = self._tracking.check_bill(bill, publish=publish)
        merge_usage(spent, result.usage)
        if result.fatal_error is not None:
            raise _SourceDownError(result.fatal_error)
        return CommandOutcome(
            status=OutcomeStatus.REFRESHED, bill=self._reload(bill), note=_tracking_note(result)
        )

    def _status(self) -> CommandOutcome:
        """The queues, what is stuck and what the recent runs cost — the state between the run
        reports, which each say what one run did and nothing about what has piled up."""
        since = self._clock.now() - dt.timedelta(days=self._status_days)
        batches = tuple(self._repo.list_open_llm_batches())
        queued = self._repo.list_queued_batch_intents()
        uncertain = self._repo.list_submitting_batch_intents()
        held = {
            (i.request.term, i.request.number)
            for i in (*queued, *uncertain)
            if i.request.call_kind in ("analysis", "reanalysis")
        } | {
            (item.term, item.number)
            for batch in batches
            for item in self._repo.list_llm_batch_items(batch.batch_id)
            if item.call_kind in ("analysis", "reanalysis")
        }
        bills = self._repo.count_by_status()
        in_flight = self._repo.list_by_status(
            [BillStatus.BATCH_PENDING], limit=bills.get(BillStatus.BATCH_PENDING, 0)
        )
        snapshot = StatusSnapshot(
            bills=bills,
            publications=self._repo.count_publications(self._publishing.channel_id),
            followed=len(self._tracking.followed()) if self._tracking is not None else 0,
            waiting=tuple(self._repo.list_by_status(list(WAITING), limit=self._status_bills)),
            stuck=tuple(
                self._repo.list_stuck_publications(
                    self._publishing.channel_id, limit=self._status_bills
                )
            ),
            runs=tuple(self._repo.list_runs(since=since)),
            days=self._status_days,
            batches=batches,
            queued_intents=len(queued),
            uncertain_intents=len(uncertain),
            document_work=self._repo.count_document_work(),
            orphaned=tuple(b for b in in_flight if (b.term, b.number) not in held),
            awaiting_batch=tuple(
                b for b in self._tracking.followed() if b.awaiting_batch_since is not None
            )
            if self._tracking is not None
            else (),
            failing=tuple(
                self._repo.list_failing_checks(
                    min_failures=FAILING_CHECK_MIN, limit=self._status_bills
                )
            ),
            observed_at=self._clock.now(),
        )
        return CommandOutcome(
            status=OutcomeStatus.REPORTED,
            snapshot=snapshot,
            note=f"{snapshot.followed} bills followed",
        )

    def _runs(self, days: int, *, include_all: bool = False) -> CommandOutcome:
        """`/runs`: what each recorded run of the window found, posted and cost — `lexinform
        runs` in the channel, for the operator who has no shell open."""
        reports = self._repo.list_runs(since=self._clock.now() - dt.timedelta(days=days))
        if not include_all:
            reports = [report for report in reports if not report.is_empty]
        label = "runs" if include_all else "non-empty runs"
        return CommandOutcome(
            status=OutcomeStatus.LISTED,
            runs=tuple(reports),
            note=f"{len(reports)} run(s) in {days} days"
            if reports
            else f"no {label} recorded in the last {days} days",
        )

    def _cost(self, days: int, top: int) -> CommandOutcome:
        """`/cost`: the window's model spend, per model, its dearest run and its dearest bills."""
        reports = self._repo.list_runs(since=self._clock.now() - dt.timedelta(days=days))
        usage: dict[str, TokenUsage] = {}
        for report in reports:
            merge_usage(usage, report.llm_usage)
        snapshot = SpendSnapshot(
            days=days,
            runs=len(reports),
            usage=usage,
            dearest=max(reports, key=lambda r: cost_usd(r.llm_usage) or 0.0) if reports else None,
            priciest=tuple(self._repo.most_expensive_analyses(limit=top)) if top else (),
        )
        return CommandOutcome(
            status=OutcomeStatus.SPENT,
            spend=snapshot,
            note=f"{len(reports)} run(s) in {days} days",
        )

    def _find(self, query: str) -> CommandOutcome:
        found = self._repo.search(query, limit=self._status_bills)
        if not found:
            return CommandOutcome(
                status=OutcomeStatus.FOUND, note=f"nothing in the database matches {query!r}"
            )
        return CommandOutcome(
            status=OutcomeStatus.FOUND,
            found=tuple(found),
            note=f"{len(found)} match(es) for {query!r}",
        )

    def _digest_command(self, command: Command, *, publish: bool) -> CommandOutcome:
        """`/digest` drafts the week into this channel; `publish` is what the button presses.

        A press that arrives twice costs nothing: the command row is answered rather than run a
        second time, and the digest's own publication row would refuse a second post anyway.
        """
        if self._digest is None:
            return CommandOutcome(
                status=OutcomeStatus.DIGESTED,
                note="the digest is off (LEXINFORM_DIGEST_ENABLED) or has no technical channel",
            )
        ref = command.options.get("ref") or self._digest.current_ref()
        if not command.publish:
            done = self._digest.draft(ref)
            # The draft sits in the technical channel; the reply links an id as the readers'.
            return self._digest_outcome(
                done,
                done.drafted,
                f"draft of {ref} is in this channel; press the button to send it",
                message_id=None,
            )
        if not publish:
            return CommandOutcome(
                status=OutcomeStatus.DIGESTED, note=f"{ref} not posted: this run does not publish"
            )
        done = self._digest.publish(ref)
        return self._digest_outcome(
            done, done.published, f"{ref} posted to the channel", message_id=done.message_id
        )

    @staticmethod
    def _digest_outcome(
        done: DigestResult, sent: bool, said: str, *, message_id: int | None
    ) -> CommandOutcome:
        """A send that failed says so: the note is empty on success, so answering `note or said`
        told the operator the digest was posted when nothing had been."""
        return CommandOutcome(
            status=OutcomeStatus.ERROR if done.failed else OutcomeStatus.DIGESTED,
            note=said if sent else done.note,
            message_id=message_id,
        )

    def _over_note(self, bill: Bill) -> str | None:
        """Why no card may be posted for this bill, when its road has ended. A card is an
        invitation to act, and there is nothing left to act on; a bill the Sejm has only passed
        is not over, because the Senate is next, and neither is one whose act is published but
        does not apply yet."""
        if bill.discontinued_at is not None:
            return "lapsed with the end of its Sejm term: not posted"
        if not is_over(bill, today=self._clock.now().date()):
            return None
        act = bill.act
        if act is not None and act.entry_into_force is not None:
            return f"{act.display_address} in force since {act.entry_into_force}: not posted"
        ended = bill.summary.closure_date
        # A dropped plan's "closure date" is the day the register first published it (the
        # register gives no withdrawal date at all), so it dates nothing a reader asked about.
        when = f" on {ended}" if ended is not None and bill.wykaz is None else ""
        return f"the process ended{when} ({self._outcome(bill)}): not posted"

    @staticmethod
    def _outcome(bill: Bill) -> str:
        """How the road ended, in the words the channel already tells apart: a rejection, a
        withdrawal by the applicant and a veto the Sejm could not override are three different
        answers to "why is there no card", and `closureDate` alone tells none of them apart."""
        if bill.summary.passed:
            return "passed"
        if bill.wykaz is not None:
            return "dropped from the government's plan"
        if bill.rcl is not None:
            return "closed on RCL without reaching the Sejm"
        return _CLOSURE_NOTES[closure_event(bill)]

    def _delivery(
        self, command: Command, incoming: IncomingCommand, *, publish: bool
    ) -> CommandOutcome:
        assert command.delivery_id is not None
        publication = self._repo.publication_by_id(command.delivery_id)
        if publication is None or (
            publication.channel_id != self._publishing.channel_id
            and not (self._digest is not None and self._digest.owns_channel(publication.channel_id))
        ):
            return CommandOutcome(
                status=OutcomeStatus.NOT_FOUND, note="publication not found in this channel"
            )
        owner_id = self._repo.digest_owner(command.delivery_id)
        if owner_id is not None and command.delivery_action != "show":
            return CommandOutcome(
                status=OutcomeStatus.ERROR,
                delivery=publication,
                note=f"resolve physical digest part {owner_id}; this row is an included event",
            )
        action = command.delivery_action
        if action != "show":
            if not publish:
                return CommandOutcome(
                    status=OutcomeStatus.ERROR, note="publishing is off in this run"
                )
            exhausted_digest_retry = (
                action == "retry"
                and publication.kind is PublicationKind.DIGEST
                and publication.status is PublicationStatus.FAILED
                and publication.attempts >= 3
            )
            if publication.status is not PublicationStatus.UNKNOWN and not exhausted_digest_retry:
                return CommandOutcome(
                    status=OutcomeStatus.ERROR,
                    delivery=publication,
                    note=f"only unknown deliveries can be resolved; status: {publication.status}",
                )
            if action == "retry":
                if publication.delivery is None or not publication.delivery.replayable(
                    publication.kind
                ):
                    return CommandOutcome(
                        status=OutcomeStatus.ERROR,
                        delivery=publication,
                        note="no replayable saved payload; retry refused",
                    )
                bill = self._repo.get(publication.term, publication.number)
                if bill is None and publication.kind is not PublicationKind.DIGEST:
                    return CommandOutcome(
                        status=OutcomeStatus.ERROR,
                        delivery=publication,
                        note="bill no longer exists; retry refused",
                    )
                if publication.kind in (PublicationKind.NEW_BILL, PublicationKind.JOINT_BILL) and (
                    bill is not None
                    and (
                        bill.status is BillStatus.LINKED or bill.last_error == SILENCED_BY_OPERATOR
                    )
                ):
                    return CommandOutcome(
                        status=OutcomeStatus.ERROR,
                        delivery=publication,
                        note="card is linked or silenced; resolve that state before retrying",
                    )
            resolution = DeliveryResolution(
                publication_id=command.delivery_id,
                publication_ids=publication.delivery.publication_ids
                if publication.delivery is not None and publication.delivery.publication_ids
                else (command.delivery_id,),
                term=publication.term,
                number=publication.number,
                kind=publication.kind,
                channel_id=publication.channel_id,
                action=action,
                command=incoming,
                resolved_at=self._clock.now(),
                message_id=command.delivery_message_id,
                reason=command.delivery_reason,
            )
            with self._repo.atomic():
                if not self._repo.resolve_delivery(resolution):
                    return CommandOutcome(
                        status=OutcomeStatus.ERROR,
                        note="delivery already resolved; inspect it again",
                    )
                if action == "confirm" and publication.delivery is not None:
                    assert resolution.message_id is not None
                    identities = publication.delivery.publication_ids or (command.delivery_id,)
                    for identity in identities:
                        member = self._repo.publication_by_id(identity)
                        assert member is not None
                        complete_delivery(
                            self._repo,
                            member,
                            message_id=resolution.message_id,
                            sent_at=resolution.resolved_at,
                        )
            publication = self._repo.publication_by_id(command.delivery_id)
        return CommandOutcome(
            status=OutcomeStatus.DELIVERY,
            delivery=publication,
            digest_owner=self._repo.publication_by_id(owner_id) if owner_id is not None else None,
            digest_members=tuple(
                member.id
                for member in self._repo.digest_sources(command.delivery_id)
                if member.id is not None
            ),
            delivery_history=tuple(self._repo.delivery_resolutions(command.delivery_id)),
            note="queued for the next publishing/tracking phase" if action == "retry" else "",
        )

    def _republish(self, bill: Bill, *, publish: bool) -> CommandOutcome:
        if bill.analysis is None or not bill.analysis.analysis.relevant:
            return CommandOutcome(
                status=OutcomeStatus.ERROR, bill=bill, note="no relevant analysis: nothing to post"
            )
        if (over := self._over_note(bill)) is not None:
            return CommandOutcome(status=OutcomeStatus.ERROR, bill=bill, note=over)
        if not publish:
            return CommandOutcome(
                status=OutcomeStatus.ERROR, bill=bill, note="publishing is off in this run"
            )
        self._publishing.forget_card(bill)
        return self._post(bill, OutcomeStatus.REPUBLISHED)

    def _forget(self, bill: Bill, *, min_score: int) -> CommandOutcome:
        """`/forget`: drop what the channel remembers of the card and post nothing in its place.

        The way out of a card deleted by hand: the `sent` row keeps the bill followed and the
        refresher keeps editing a message that is not there. `/republish` clears that too, but by
        sending the card again, which is wrong when it was deleted on purpose. What happens next
        is the publishing rule's decision, and running this twice changes nothing.
        """
        card = self._card(bill)
        if self._publishing.card_of(bill) is None:
            return CommandOutcome(
                status=OutcomeStatus.FORGOTTEN,
                bill=bill,
                note="the channel remembers no card for it; nothing to forget",
            )
        self._publishing.forget_card(bill)
        verdict = bill.analysis.analysis if bill.analysis is not None else None
        candidate = (
            bill.status is BillStatus.ANALYZED
            and bill.discontinued_at is None
            and verdict is not None
            and verdict.relevant
            and verdict.score >= min_score
        )
        forgotten = f"forgotten: {card}" if card is not None else "forgotten"
        next_run = (
            "the next run posts a fresh card"
            if candidate
            else f"it will not be posted again ({bill.status})"
        )
        return CommandOutcome(
            status=OutcomeStatus.FORGOTTEN, bill=bill, note=f"{forgotten}; {next_run}"
        )

    def _post(self, bill: Bill, status: OutcomeStatus) -> CommandOutcome:
        """Send the card through the normal path (pending row first, joint prints share a
        thread) and tell which message it became."""
        ok = self._publishing.publish_bill(bill)
        posted = self._publishing.card_of(bill)
        if not ok or posted is None or posted.message_id is None:
            return CommandOutcome(
                status=OutcomeStatus.ERROR, bill=bill, note="posting the card failed, see the log"
            )
        note = "" if posted.kind is PublicationKind.NEW_BILL else "as a reply under the joint print"
        return CommandOutcome(status=status, bill=bill, message_id=posted.message_id, note=note)

    def _reload(self, bill: Bill) -> Bill:
        fresh = self._repo.get(bill.term, bill.number)
        return fresh if fresh is not None else bill

    def _card(self, bill: Bill) -> str | None:
        """`message 123` when the bill's card (or its reply under a joint print) is sent."""
        pub = self._publishing.card_of(bill)
        if pub is None or pub.status is not PublicationStatus.SENT:
            return None
        return f"message {pub.message_id}"
