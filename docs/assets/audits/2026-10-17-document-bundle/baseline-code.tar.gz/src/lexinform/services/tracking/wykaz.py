"""Bills the government has only announced: what the register says about them next.

Two things can happen to a plan. Its project appears on RCL — then the RCL row takes over the
thread the way a druk takes over an RPW entry's (`WykazLinker`), and the text is analysed at
last. Or the government drops it, which art. 3 ust. 3 of the lobbying act obliges the register
to say (`Status realizacji`, `Informacja o rezygnacji`) and no other source tells at all.

A slipped quarter or a rewritten "istota" is stored and not posted: that is a chronicle.
A row that simply disappears from the register says the same as `Wycofany` and is read so.
"""

import logging
from collections.abc import Sequence

from lexinform.errors import ServiceUnavailableError
from lexinform.models import (
    Bill,
    CheckAspect,
    PublicationStatus,
    SourceOutcome,
    StatusChange,
    WykazEntry,
    process_summary,
    rcl_fingerprint,
    rcl_stages,
    wykaz_entry_number,
    wykaz_evidence,
    wykaz_fingerprint,
    wykaz_summary,
)
from lexinform.ports import BillRepository, Clock, WykazGateway
from lexinform.services.analysis import AnalysisService
from lexinform.services.posting import Poster
from lexinform.services.publications import inherit_card
from lexinform.services.rcl_projects import RclProjectReader
from lexinform.services.sources import RclTextSource
from lexinform.services.tracking_result import TrackingResult

log = logging.getLogger(__name__)

REMOVED_STATUS = "Wycofany"


class WykazLinker:
    """The project of a plan we follow: the RCL row inherits the plan's card."""

    def __init__(
        self,
        reader: RclProjectReader,
        repo: BillRepository,
        clock: Clock,
        poster: Poster,
        *,
        channel_id: str,
        analysis: AnalysisService | None,
    ) -> None:
        self._reader = reader
        self._repo = repo
        self._clock = clock
        self._poster = poster
        self._channel_id = channel_id
        self._analysis = analysis
        self._texts = RclTextSource()

    def link(self, plan: Bill, project_id: int, result: TrackingResult, *, publish: bool) -> None:
        """Continue `plan` as its RCL project, in the same thread.

        The plan was judged on an announcement and the project has the text, so the row is
        re-analysed here: without that, a thin description would decide the fate of the row that
        finally carries the real thing.
        """
        assert plan.wykaz is not None, "list_wykaz_awaiting_link selects only plans with an entry"
        now = self._clock.now()
        project = self._reader.complete(self._reader.timeline(project_id))
        summary = process_summary(project, term=plan.term)
        bill = Bill(
            summary=summary,
            first_seen_at=now,
            last_checked_at=now,
            status=plan.status,
            analysis=plan.analysis,
            prefilter_hits=plan.prefilter_hits,
            rcl=project,
            stages=rcl_stages(project),
            stages_fingerprint=rcl_fingerprint(project),
            linked_number=plan.number,
        )
        fresh, content_changed = self._reanalyse(bill, result)
        card = self._poster.card(plan)
        # A reply waits for a sent card; unsent, the project falls to `_NO_CARD_YET` instead (#16).
        inherits = card is not None and card.status is PublicationStatus.SENT
        change = None
        with self._repo.atomic():
            self._repo.upsert_summary(summary, now=now)
            self._repo.save_rcl(plan.term, summary.number, project)
            self._repo.save_stages(
                plan.term, summary.number, rcl_stages(project), rcl_fingerprint(project)
            )
            self._repo.set_status(
                plan.term, summary.number, plan.status, prefilter_hits=plan.prefilter_hits
            )
            if fresh.analysis is not None:
                self._repo.save_analysis(plan.term, summary.number, fresh.analysis)
            self._repo.link_bills(
                plan.term, plan.number, summary.number, wykaz_number=wykaz_entry_number(plan.number)
            )
            if inherits:
                assert card is not None, "inherits is true only with a sent card"
                inherit_card(
                    self._repo,
                    term=plan.term,
                    number=summary.number,
                    channel_id=self._channel_id,
                    card=card,
                    now=self._clock.now(),
                )
                change = self._poster.record_change(
                    StatusChange(
                        term=plan.term,
                        number=summary.number,
                        old_fingerprint=plan.number,
                        new_fingerprint=rcl_fingerprint(project),
                        new_stages=list(rcl_stages(project)),
                        content_changed=content_changed,
                        detected_at=now,
                    )
                )
                if change is not None:
                    self._poster.prepare(fresh, change)
        result.linked += 1
        log.info("%s is now a project on RCL: %s", plan.number, summary.number)
        linked_plan = self._repo.get(plan.term, plan.number)
        if publish and inherits and linked_plan is not None:
            assert card is not None, "inherits is true only with a sent card"
            self._poster.rerender_card(linked_plan, card)
        if change is None:
            return
        result.changed += 1
        self._poster.tell(fresh, change, result, publish=publish)

    def _reanalyse(self, bill: Bill, result: TrackingResult) -> tuple[Bill, bool]:
        """True when the model read the plan's first text, or named what changed in a new one."""
        if self._analysis is None or bill.analysis is None:
            return bill, False
        document = self._texts.locate(bill).document
        if document is None:
            return bill, False
        first_text = bill.analysis.text_source == "metadata_only"
        fresh, reanalysed = self._analysis.prepare_reanalysis(bill, document)
        if not reanalysed or fresh.analysis is None:
            return fresh, False
        result.count_reanalysis(fresh.analysis)
        return fresh, first_text or fresh.analysis.analysis.names_changes


class WykazWatcher:
    def __init__(
        self,
        wykaz: WykazGateway,
        repo: BillRepository,
        clock: Clock,
        poster: Poster,
        linker: WykazLinker,
    ) -> None:
        self._wykaz = wykaz
        self._repo = repo
        self._clock = clock
        self._poster = poster
        self._linker = linker

    def check(
        self,
        bills: list[Bill],
        result: TrackingResult,
        *,
        publish: bool,
        quiet: Sequence[Bill] = (),
    ) -> bool:
        """Re-read the register for the followed plans and post what the government decided;
        link the ones whose project is out. False when Telegram is down. `quiet` plans have no
        card: stored the same way from the same download, never delivered."""
        self._stamp_projects_already_listed([*bills, *quiet])
        if not self._link_pending(result, publish=publish):
            return False
        followed = [b for b in bills if b.wykaz is not None]
        silent = [b for b in quiet if b.wykaz is not None]
        if not followed and not silent:
            return True
        entries = self._entries(result, [*followed, *silent])
        if entries is None:
            return True
        for bill in silent:
            self._check_one(bill, entries, result, publish=False, deliver=False)
        return all(self._check_one(bill, entries, result, publish=publish) for bill in followed)

    def _entries(self, result: TrackingResult, plans: list[Bill]) -> dict[str, WykazEntry] | None:
        """The whole register, by number; None when it could not be downloaded, which stops this
        watcher and nothing else."""
        try:
            return {e.number: e for e in self._wykaz.entries()}
        except ServiceUnavailableError as exc:
            now = self._clock.now()
            for bill in plans:
                self._repo.record_check(
                    bill.term, bill.number, CheckAspect.PROCESS, at=now, ok=False, outage=True
                )
            result.partial_errors.append(f"wykaz: {exc.describe()}")
            log.error("wykaz tracking stopped: %s", exc.describe())
            return None

    def _check_one(
        self,
        bill: Bill,
        entries: dict[str, WykazEntry],
        result: TrackingResult,
        *,
        publish: bool,
        deliver: bool = True,
    ) -> bool:
        """False when Telegram is down; a failure of this one plan is counted and passed over."""
        assert bill.wykaz is not None, "check() follows only the plans that carry a wykaz entry"
        if deliver:
            result.checked += 1
        else:
            result.observed += 1
        entry = entries.get(bill.wykaz.number) or self._removed(bill, entries)
        if entry is None:
            return True
        now = self._clock.now()
        try:
            with self._repo.atomic():
                change = self._detect(bill, entry, result)
                if change is not None and deliver:
                    fresh = self._repo.get(bill.term, bill.number) or bill
                    self._poster.prepare(fresh, change)
        except Exception as exc:
            self._repo.record_check(bill.term, bill.number, CheckAspect.PROCESS, at=now, ok=False)
            result.failed += 1
            log.exception("tracking %s failed: %s", bill.number, exc)
            return True
        self._repo.record_check(bill.term, bill.number, CheckAspect.PROCESS, at=now, ok=True)
        if change is None or not deliver:
            return True
        fresh = self._repo.get(bill.term, bill.number) or bill
        try:
            self._poster.tell(fresh, change, result, publish=publish)
        except ServiceUnavailableError as exc:
            result.abort(exc, failed=True)
            return False
        return True

    def _stamp_projects_already_listed(self, bills: list[Bill]) -> None:
        """Plans whose project RCL has listed but never shown as changed since we started.

        `RclDiscoveryService._continues_a_plan` stamps a project the listing hands it, and the
        listing only hands it the projects modified since the watermark — so a project published
        before this bot, or one untouched for months, would never reach the plan it continues
        and the card would go on saying there is no text. The numbers RCL has published are
        written down for every row of the listing, and this is where a plan claims its own.
        """
        for bill in bills:
            entry = bill.wykaz
            if entry is None or entry.rcl_project_id is not None:
                continue
            project_id = self._repo.find_rcl_project_of_plan(
                entry.number, entry.published_at.date()
            )
            if project_id is None:
                continue
            self._repo.save_wykaz(
                bill.term, bill.number, entry.model_copy(update={"rcl_project_id": project_id})
            )
            log.info("RCL %d is the project of the planned bill %s", project_id, bill.number)

    def _link_pending(self, result: TrackingResult, *, publish: bool) -> bool:
        """Plans whose project the RCL discovery has seen: the project takes over the thread."""
        for bill in self._repo.list_wykaz_awaiting_link():
            assert bill.wykaz is not None and bill.wykaz.rcl_project_id is not None, (
                "list_wykaz_awaiting_link selects only plans whose entry names a project"
            )
            try:
                self._linker.link(bill, bill.wykaz.rcl_project_id, result, publish=publish)
            except ServiceUnavailableError as exc:
                result.abort(exc)
                return False
            except Exception as exc:
                result.failed += 1
                log.exception("linking %s to its RCL project failed: %s", bill.number, exc)
        return True

    def _removed(self, bill: Bill, entries: dict[str, WykazEntry]) -> WykazEntry | None:
        """A plan whose row is gone from the register: the government dropped it without saying
        so, which is the one thing only this source can tell. An empty register is a download
        that went wrong, not a government that dropped everything."""
        assert bill.wykaz is not None, "check() follows only the plans that carry a wykaz entry"
        if not entries:
            log.warning("the register came back empty: absences are not read as removals")
            return None
        return bill.wykaz.model_copy(update={"status": REMOVED_STATUS})

    def _detect(self, bill: Bill, entry: WykazEntry, result: TrackingResult) -> StatusChange | None:
        """Store what the register says now; a change row only for a decision a reader can act
        on: the government dropping the project, or adopting it. A slipped quarter or a rewritten
        "istota" is stored and not posted."""
        assert bill.wykaz is not None, "check() follows only the plans that carry a wykaz entry"
        entry = entry.model_copy(update={"rcl_project_id": bill.wykaz.rcl_project_id})
        new_fp = wykaz_fingerprint(entry)
        if new_fp == bill.stages_fingerprint:
            return None
        self._repo.upsert_summary(wykaz_summary(entry, term=bill.term), now=self._clock.now())
        self._repo.save_wykaz(bill.term, bill.number, entry)
        self._repo.save_stages(bill.term, bill.number, (), new_fp)
        before = wykaz_evidence(bill.wykaz).source
        after = wykaz_evidence(entry).source
        dropped = after is SourceOutcome.WITHDRAWN and before is not SourceOutcome.WITHDRAWN
        adopted = after is SourceOutcome.ADOPTED and before is not SourceOutcome.ADOPTED
        if not dropped and not adopted:
            return None
        change = self._poster.record_change(
            StatusChange(
                term=bill.term,
                number=bill.number,
                old_fingerprint=bill.stages_fingerprint,
                new_fingerprint=new_fp,
                new_stages=[],
                closure_detected=dropped,
                passed=False,
                detected_at=self._clock.now(),
            )
        )
        if change is None:
            return None
        result.changed += 1
        what = "dropped" if dropped else "adopted"
        log.info("%s: the government %s the project (%s)", bill.number, what, entry.status)
        return change
