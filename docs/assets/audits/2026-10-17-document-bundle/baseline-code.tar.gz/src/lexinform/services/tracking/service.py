"""The tracking phase: which bills to look at, what changed, and the resulting posts.

Every update is a reply to the original card and restates the current summary. When the bill's
text changed (committee report, text after the 3rd reading, updated print) the bill is
re-analysed first and the update also lists what changed.
"""

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from lexinform.concurrency import fan_out
from lexinform.errors import ServiceUnavailableError
from lexinform.models import (
    AmendmentsContext,
    AmendmentsRecord,
    Bill,
    BillPlan,
    BillStatus,
    CheckAspect,
    DocumentWork,
    ObservationMode,
    PrintInfo,
    ProcessDetail,
    Publication,
    PublicationKind,
    PublicationStatus,
    Stage,
    StatusChange,
    TextDocument,
    amendments_stage,
    decision_changes,
    diff_stages,
    new_supplements,
    observation_of,
    observe,
    plan_bill,
    stage_fingerprint,
    supplement_kind,
)
from lexinform.models.source_checks import observation_for
from lexinform.ports import (
    BillRepository,
    Clock,
    EliGateway,
    Publisher,
    SejmGateway,
    SenateGateway,
    WykazGateway,
)
from lexinform.senate_documents import adoption_before_senate
from lexinform.services.analysis import AnalysisService, Waiting
from lexinform.services.delivery import DeliveryService
from lexinform.services.document_reviews import DocumentReviews
from lexinform.services.posting import Poster
from lexinform.services.rcl_projects import RclProjectReader
from lexinform.services.sources import SejmTextSource, fetch_print
from lexinform.services.tracking.acts import ActWatcher
from lexinform.services.tracking.agenda import AgendaWatcher
from lexinform.services.tracking.cards import CardRefresher
from lexinform.services.tracking.consultations import ConsultationReminder
from lexinform.services.tracking.deadlines import DeadlineReminder
from lexinform.services.tracking.hearings import HearingReminder
from lexinform.services.tracking.linking import Linker
from lexinform.services.tracking.pre_print import PrePrintReconciler
from lexinform.services.tracking.rcl import RclWatcher
from lexinform.services.tracking.rollover import TermRollover
from lexinform.services.tracking.senate import SenateWatcher
from lexinform.services.tracking.stages import StageEnricher, change_key
from lexinform.services.tracking.wykaz import WykazLinker, WykazWatcher
from lexinform.services.tracking_result import TrackingResult

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class TrackingOptions:
    """The knobs of a tracking run, as `Settings` sets them.

    A reminder is switched off by giving it no days (`consultation_reminder_days`,
    `decision_reminder_days` = None), the agenda watcher by `agenda_watch`.
    """

    channel_id: str
    closed_grace_days: int = 90
    pending_decision_max_days: int = 1095
    max_publish_attempts: int = 3
    club_breakdown: bool = True
    in_force_reminders: bool = True
    consultation_reminder_days: int | None = 3
    decision_reminder_days: int | None = 7
    agenda_watch: bool = True
    max_card_edits: int = 30
    local_tz: ZoneInfo = ZoneInfo("Europe/Warsaw")
    text_prefilter: bool = True
    workers: int = 1
    observe_unthreaded: bool = True
    min_score: int = 3
    reader_attention: str = "shadow"
    attention_urgent_days: int = 3
    attention_max_group: int = 5
    attention_roundup: str = "run"
    attention_daily_hour: int = 18


def _consultation_reminder(
    repo: BillRepository, clock: Clock, poster: Poster, options: TrackingOptions
) -> ConsultationReminder | None:
    if options.consultation_reminder_days is None:
        return None
    return ConsultationReminder(
        repo,
        clock,
        poster,
        channel_id=options.channel_id,
        local_tz=options.local_tz,
        days_before=options.consultation_reminder_days,
    )


def _hearing_reminder(
    repo: BillRepository, clock: Clock, poster: Poster, options: TrackingOptions
) -> HearingReminder | None:
    if options.consultation_reminder_days is None:
        return None
    return HearingReminder(
        repo,
        clock,
        poster,
        local_tz=options.local_tz,
        days_before=options.consultation_reminder_days,
    )


def _deadline_reminder(
    repo: BillRepository, clock: Clock, poster: Poster, options: TrackingOptions
) -> DeadlineReminder | None:
    if options.decision_reminder_days is None:
        return None
    return DeadlineReminder(
        repo,
        clock,
        poster,
        local_tz=options.local_tz,
        days_before=options.decision_reminder_days,
    )


def _rcl_watcher(
    reader: RclProjectReader | None,
    repo: BillRepository,
    clock: Clock,
    poster: Poster,
    linker: Linker,
    gateway: SejmGateway,
    analysis: AnalysisService | None,
    consultations: ConsultationReminder | None,
    options: TrackingOptions,
) -> RclWatcher | None:
    if reader is None:
        return None
    return RclWatcher(
        reader,
        repo,
        clock,
        poster,
        linker,
        gateway,
        analysis=analysis,
        consultations=consultations,
        local_tz=options.local_tz,
        workers=options.workers,
    )


def _wykaz_watcher(
    wykaz: WykazGateway | None,
    reader: RclProjectReader | None,
    repo: BillRepository,
    clock: Clock,
    poster: Poster,
    analysis: AnalysisService | None,
    options: TrackingOptions,
) -> WykazWatcher | None:
    """A plan is followed only when its project can be read: the hand-over to RCL is the whole
    point of watching the register."""
    if wykaz is None or reader is None:
        return None
    linker = WykazLinker(
        reader, repo, clock, poster, channel_id=options.channel_id, analysis=analysis
    )
    return WykazWatcher(wykaz, repo, clock, poster, linker)


def _agenda_watcher(
    gateway: SejmGateway,
    repo: BillRepository,
    clock: Clock,
    poster: Poster,
    enricher: StageEnricher,
    options: TrackingOptions,
) -> AgendaWatcher | None:
    if not options.agenda_watch:
        return None
    return AgendaWatcher(
        gateway,
        repo,
        clock,
        poster,
        enricher,
        channel_id=options.channel_id,
        local_tz=options.local_tz,
    )


@dataclass(frozen=True)
class _Amendments:
    """An amendments document found among the new stages, with the committee's proposal."""

    document: TextDocument
    proposal: str | None


@dataclass(frozen=True)
class _Supplement:
    """A document filed to the print since the last check and worth telling: its own print
    number and title, and the file to read it from."""

    number: str
    title: str
    document: TextDocument


@dataclass(frozen=True)
class _Found:
    """What one bill's network step brought back, for the detection that follows it."""

    detail: ProcessDetail
    print_info: PrintInfo | None
    amendments: _Amendments | None
    supplements: list[_Supplement]


class StatusTrackingService:
    """Follows published bills: stage changes, new texts, sittings, acts, consultations.

    The work is split by concern into the sibling modules; this class owns the loop and the
    stage/text detection. Network calls for many bills run in parallel, every decision and
    database write happens here, in order.
    """

    def __init__(
        self,
        gateway: SejmGateway,
        repo: BillRepository,
        publisher: Publisher,
        clock: Clock,
        options: TrackingOptions,
        *,
        analysis: AnalysisService | None = None,
        eli: EliGateway | None = None,
        rcl_reader: RclProjectReader | None = None,
        wykaz: WykazGateway | None = None,
        senate: SenateGateway | None = None,
        poster: Poster | None = None,
        deliveries: DeliveryService | None = None,
        document_reviews: DocumentReviews | None = None,
    ) -> None:
        channel_id = options.channel_id
        poster = poster or Poster(
            repo,
            publisher,
            clock,
            gateway=gateway,
            channel_id=channel_id,
            max_attempts=options.max_publish_attempts,
            attention_mode=options.reader_attention,
            urgent_days=options.attention_urgent_days,
            max_group=options.attention_max_group,
            daily_roundup=options.attention_roundup == "daily",
            daily_hour=options.attention_daily_hour,
        )
        enricher = StageEnricher(gateway, club_breakdown=options.club_breakdown)
        consultations = _consultation_reminder(repo, clock, poster, options)
        if consultations is not None:
            consultations.set_reviews(document_reviews)
        # The act watcher is built before the linker, which asks it for the act of a print it
        # adopts: a project handed over long ago becomes a print whose act nothing else fetches.
        acts = ActWatcher(
            eli,
            repo,
            clock,
            poster,
            channel_id=channel_id,
            local_tz=options.local_tz,
            in_force_reminders=options.in_force_reminders,
        )
        linker = Linker(
            gateway,
            repo,
            clock,
            poster,
            enricher,
            acts,
            channel_id=channel_id,
            analysis=analysis,
            text_prefilter=options.text_prefilter,
        )
        self._gateway = gateway
        self._repo = repo
        self._clock = clock
        self._analysis = analysis
        self._document_reviews = document_reviews
        self._options = options
        self._poster = poster
        self._deliveries = deliveries or DeliveryService(
            repo, clock, poster, channel_id=channel_id, max_attempts=options.max_publish_attempts
        )
        self._enricher = enricher
        self._texts = SejmTextSource(gateway)
        self._consultations = consultations
        self._hearings = _hearing_reminder(repo, clock, poster, options)
        self._deadlines = _deadline_reminder(repo, clock, poster, options)
        self._pre_print = PrePrintReconciler(
            gateway,
            repo,
            clock,
            poster,
            linker,
            channel_id=channel_id,
            consultations=consultations,
        )
        self._rcl = _rcl_watcher(
            rcl_reader, repo, clock, poster, linker, gateway, analysis, consultations, options
        )
        self._wykaz = _wykaz_watcher(wykaz, rcl_reader, repo, clock, poster, analysis, options)
        self._agenda = _agenda_watcher(gateway, repo, clock, poster, enricher, options)
        self._acts = acts
        self._senate = (
            SenateWatcher(senate, gateway, repo, clock, local_tz=options.local_tz)
            if senate is not None
            else None
        )
        self._cards = CardRefresher(
            gateway, repo, publisher, clock, channel_id=channel_id, max_edits=options.max_card_edits
        )
        self._rollover = TermRollover(repo, clock, poster, channel_id=channel_id)

    def close_term(self, previous: int, current: int, *, publish: bool = True) -> TrackingResult:
        """The Sejm moved on to `current`: announce the lapsed bills of `previous` and carry its
        RCL projects over (see `TermRollover`). Cheap and idempotent once done."""
        result = TrackingResult()
        self._rollover.close_term(previous, current, result, publish=publish)
        return result

    def check_updates(
        self,
        *,
        publish: bool = True,
        changed_since: datetime | None = None,
        may_wait: bool = True,
        keep_delivery_attempts: bool = False,
    ) -> TrackingResult:
        """Look for news on published bills, whichever term they belong to.

        `changed_since` limits the check to bills the Sejm API reported as modified since then
        (discovery refreshes their `change_date`); None checks every followed bill. The reminders
        of `_remind` and the card refresh see every followed bill either way.
        """
        result = TrackingResult()
        self._poster.start_run(keep_attempts=keep_delivery_attempts)
        if publish and not self._retry_failed(result):
            return self._finish(result)
        if not self._pre_print.reconcile(result, publish=publish):
            return self._finish(result)
        tracked = self._list_tracked(changed_since)
        everyone = tracked if changed_since is None else self._list_tracked()
        quiet: list[Bill] = []
        quiet_everyone: list[Bill] = []
        if self._options.observe_unthreaded:
            self._assign_observation()
            quiet_everyone = self._list_tracked(unthreaded=True)
            quiet = (
                quiet_everyone
                if changed_since is None
                else self._list_tracked(changed_since, unthreaded=True)
            )
        if not self._check_other_sources(
            tracked,
            everyone,
            result,
            publish=publish,
            quiet=quiet,
            quiet_everyone=quiet_everyone,
        ):
            self._flush_updates(result, publish=publish)
            return self._finish(result)
        self._check_processes(tracked, result, publish=publish, may_wait=may_wait)
        if quiet and result.fatal_error is None:
            quiet = [self._repo.get(b.term, b.number) or b for b in quiet]
            self._check_processes(quiet, result, publish=False, may_wait=may_wait, deliver=False)
        self._retry_documents(result, publish=publish, may_wait=may_wait)
        self._flush_updates(result, publish=publish)
        self._remind_and_refresh(everyone, result, publish=publish)
        self._log_outcome(result, changed_since)
        return self._finish(result)

    def _assign_observation(self) -> None:
        """Give every analysed or carded bill the mode its card and its analysis call for."""
        for bill, has_card in self._repo.list_observation_candidates(self._options.channel_id):
            wanted = observation_for(
                bill.analysis.analysis if bill.analysis else None,
                has_card=has_card,
                current=bill.observation_basis,
                min_score=self._options.min_score,
            )
            if wanted is not None and wanted != (bill.observation_mode, bill.observation_basis):
                self._repo.set_observation(bill.term, bill.number, *wanted)

    def check_bill(self, bill: Bill, *, publish: bool = True) -> TrackingResult:
        """Everything a run would look at for one bill, now: its source's watcher, its process
        and its card. The reminders are left out — they are due-date queries over the whole
        channel, and the operator asked about this bill.

        `bill` must have a `sent` card when `publish`: the posters reply under it and post at the
        top level without one. A scheduled run gets that from `_list_tracked`; the caller here
        (`CommandService._refresh`) checks it before asking.
        """
        result = TrackingResult()
        self._poster.start_run()
        one = [bill]
        if not self._check_other_sources(one, one, result, publish=publish):
            self._flush_updates(result, publish=publish)
            return self._finish(result)
        self._check_processes(one, result, publish=publish, may_wait=False)
        self._retry_documents(result, publish=publish, may_wait=False)
        self._flush_updates(result, publish=publish)
        if result.fatal_error is None:
            self._cards.refresh(one, result, publish=publish)
        return self._finish(result)

    def _finish(self, result: TrackingResult) -> TrackingResult:
        metrics = self._poster.attention_metrics()
        for key, count in result.attention.items():
            metrics[key] = metrics.get(key, 0) + count
        result.attention = metrics
        result.partial_errors.extend(self._poster.delivery_errors())
        return result

    def _flush_updates(self, result: TrackingResult, *, publish: bool) -> None:
        if not publish or result.fatal_error is not None:
            return
        try:
            self._poster.flush_updates(result)
        except ServiceUnavailableError as exc:
            result.abort(exc, failed=True)

    def followed(self) -> list[Bill]:
        """The bills a run would check: a card in the channel and a road that has not ended."""
        return self._list_tracked()

    def _check_other_sources(
        self,
        tracked: list[Bill],
        everyone: list[Bill],
        result: TrackingResult,
        *,
        publish: bool,
        quiet: list[Bill] | None = None,
        quiet_everyone: list[Bill] | None = None,
    ) -> bool:
        """The watchers that do not read a Sejm process; False when one of them had to stop.

        Agendas change without the process being touched, so every followed bill is checked, and
        before the stage loop, so that an update posted there already carries the sitting dates.
        The wykaz comes before RCL: a plan whose project is out hands its card over, and the
        project is then among the rows the RCL watcher refreshes in the same run.
        """
        silent = quiet or []
        if self._agenda is not None and not self._agenda.check(
            everyone, result, publish=publish, quiet=quiet_everyone or []
        ):
            return False
        if publish:
            try:
                self._poster.flush_sittings(result)
            except ServiceUnavailableError as exc:
                result.abort(exc, failed=True)
                return False
        if self._senate is not None:
            full = [b for b in quiet_everyone or [] if b.observation_mode is ObservationMode.FULL]
            self._senate.check([*everyone, *full], result)
        if self._wykaz is not None and not self._wykaz.check(
            tracked, result, publish=publish, quiet=silent
        ):
            return False
        return self._rcl is None or self._rcl.check(tracked, result, publish=publish, quiet=silent)

    def _check_processes(
        self,
        tracked: list[Bill],
        result: TrackingResult,
        *,
        publish: bool,
        may_wait: bool,
        deliver: bool = True,
    ) -> None:
        """Read the process of every followed Sejm bill and tell what is new about it.

        With `deliver` off the bill has no thread: its facts and changes are stored, nothing is
        queued for Telegram, and a metadata-only bill asks the model nothing.
        """
        followed = [bill for bill in tracked if bill.has_process]
        for outcome in fan_out(followed, self._fetch, workers=self._options.workers):
            bill = outcome.item
            if deliver:
                result.checked += 1
            else:
                result.observed += 1
            try:
                found = outcome.result()
                detail = found.detail
                change = self._detect(bill, found, result, may_wait=may_wait, deliver=deliver)
            except ServiceUnavailableError as exc:
                self._check_done(bill, ok=False, outage=True)
                result.abort(exc)
                return
            except Exception as exc:
                self._check_done(bill, ok=False)
                result.failed += 1
                log.exception("tracking druk %s failed: %s", bill.number, exc)
                continue
            self._check_done(bill, ok=True)
            if change is not None:
                result.changed += 1
            try:
                if not deliver:
                    self._acts.check(bill, detail, result, publish=False)
                    continue
                self._post_news(bill, detail, change, result, publish=publish)
            except ServiceUnavailableError as exc:
                result.abort(exc, failed=True)
                return
            except Exception as exc:
                result.failed += 1
                log.exception("posting for druk %s failed: %s", bill.number, exc)

    def _check_done(self, bill: Bill, *, ok: bool, outage: bool = False) -> None:
        self._repo.record_check(
            bill.term, bill.number, CheckAspect.PROCESS, at=self._clock.now(), ok=ok, outage=outage
        )

    def _post_news(
        self,
        bill: Bill,
        detail: ProcessDetail,
        change: StatusChange | None,
        result: TrackingResult,
        *,
        publish: bool,
    ) -> None:
        """Tell what the run found about one bill.

        A change worth telling and an act not yet told go out as one update carrying the act.
        Otherwise the act notice goes first, so that the closure is suppressed only when the notice
        that would have told it really went out; ELI can be a day behind the process, and the change
        row is unique, so a suppressed closure is never detected again. A change with no news is
        held rather than dropped for the same reason: with publishing off the row already exists,
        so nothing would ever detect those stages again, and so is one that only fills in the road
        behind what the channel has shown (`fills_in_the_past`). `bill.stages` is still the tree
        the previous run left, `_detect` having saved the new one without touching this object.
        """
        self._acts.fetch(bill, detail)
        if change is None:
            if publish:
                self._acts.announce(bill, detail, result)
            return
        if publish and self._acts.due(bill, detail):
            told = plan_bill(bill, detail, analysis_document=None, closure_announced=True)
            if told.should_publish(change, act_published=True):
                # One message for the bill: the update carries the act as well.
                self._poster.tell(bill, change, result, publish=publish, with_act=True)
                return
            self._acts.announce(bill, detail, result)
        announced = self._poster.sent(bill, PublicationKind.ACT_PUBLISHED)
        plan = plan_bill(bill, detail, analysis_document=None, closure_announced=announced)
        news = plan.should_publish(change, act_published=announced)
        if not news:
            self._poster.hold(bill, change)
            result.held += 1
        else:
            self._poster.tell(bill, change, result, publish=publish)

    def _remind_and_refresh(
        self, everyone: list[Bill], result: TrackingResult, *, publish: bool
    ) -> None:
        if publish:
            self._remind(everyone, result)
        if result.fatal_error is None and self._document_reviews is not None:
            self._document_reviews.advance(result, publish=publish)
        if result.fatal_error is None:
            self._cards.refresh(everyone, result, publish=publish)

    def _remind(self, everyone: list[Bill], result: TrackingResult) -> None:
        """The posts with a deadline behind them — three days for a consultation, the day itself
        for an act entering into force — and the next run is twelve hours away, twenty-four at a
        weekend. They come before the card refresh, and the refresh cannot stop them: re-rendering
        a card is worth none of that."""
        if result.fatal_error is None:
            self._acts.remind_in_force(result)
        if result.fatal_error is None and self._consultations is not None:
            self._consultations.remind(result)
        if result.fatal_error is None and self._hearings is not None:
            self._hearings.remind(everyone, result)
        if result.fatal_error is None and self._deadlines is not None:
            self._deadlines.remind(everyone, result)

    def _log_outcome(self, result: TrackingResult, changed_since: datetime | None) -> None:
        scope = "all" if changed_since is None else f"changed since {changed_since:%F %R}"
        log.info(
            "tracking (%s): checked=%d observed=%d changed=%d reanalyzed=%d published=%d"
            " agenda=%d failed=%d",
            scope,
            result.checked,
            result.observed,
            result.changed,
            result.reanalyzed,
            result.published,
            result.agenda_posted,
            result.failed,
        )

    def _list_tracked(
        self, changed_since: datetime | None = None, *, unthreaded: bool = False
    ) -> list[Bill]:
        options = self._options
        return self._repo.list_tracked(
            options.channel_id,
            closed_grace_days=options.closed_grace_days,
            pending_decision_max_days=options.pending_decision_max_days,
            now=self._clock.now(),
            changed_since=changed_since,
            unthreaded=unthreaded,
        )

    def _retry_failed(self, result: TrackingResult) -> bool:
        for bill in self._deliveries.retry(result):
            card = self._poster.card(bill)
            if card is not None:
                try:
                    self._poster.rerender_card(bill, card)
                except ServiceUnavailableError as exc:
                    result.abort(exc, failed=True)
                    break
        return result.fatal_error is None

    def _fetch(self, bill: Bill) -> _Found:
        """What detection needs from the API for one bill (no database access): the process,
        the print, whatever document a new stage brings amendments in, and the documents filed
        to the print since the last check."""
        detail = self._enricher.decision_votes(
            self._gateway.get_process(bill.term, bill.number), bill.stages
        )
        print_info = fetch_print(self._gateway, bill)
        return _Found(
            detail,
            print_info,
            self._amendments_document(bill, detail),
            self._supplements(bill, print_info),
        )

    def _supplements(self, bill: Bill, print_info: PrintInfo | None) -> list[_Supplement]:
        """The documents filed to the print that this run should tell (no network: the print
        carries them). None of them until the bill's own list has been recorded once — the first
        sight seeds it silently, the way the stage fingerprint is seeded."""
        if self._analysis is None or bill.analysis is None or bill.seen_supplements is None:
            return []
        found = []
        for filed in new_supplements(print_info, bill.seen_supplements):
            kind = supplement_kind(filed.title)
            pdf = filed.main_pdf
            if kind is None or pdf is None:
                continue
            found.append(
                _Supplement(filed.number, filed.title, TextDocument(url=pdf.url, kind=kind))
            )
        return found

    def _amendments_document(self, bill: Bill, detail: ProcessDetail) -> _Amendments | None:
        """The Senate's resolution print or the committee's report on amendments, if one of
        the stages new since the stored tree carries amendments (network: the Senate print)."""
        if self._analysis is None or bill.analysis is None or bill.stages_fingerprint is None:
            return None
        previous = observation_of(bill)
        known = previous.stages if previous else ()
        changed = diff_stages(known, detail.stages)
        changed.extend(
            stage for stage in decision_changes(known, detail.stages) if stage not in changed
        )
        stage = amendments_stage(changed)
        if stage is None:
            return None
        return self._document_for_stage(stage, detail)

    def _document_for_stage(self, stage: Stage, detail: ProcessDetail) -> _Amendments | None:
        assert self._analysis is not None
        if stage.stage_type == "SenatePosition":
            assert stage.print_number is not None, (
                "amendments_stage takes a Senate position only with its print"
            )
            try:
                senate_print = self._gateway.get_print(detail.term, stage.print_number)
            except ServiceUnavailableError:
                raise
            except Exception as exc:
                log.warning("Senate print %s unavailable: %s", stage.print_number, exc)
                return None
            document = self._analysis.senate_amendments_document(
                senate_print,
                stage,
                titles=(detail.title_final or "", detail.title),
                passed_on=adoption_before_senate(
                    detail.stages, senate_print.document_date or stage.date
                ),
            )
            if document is None:
                return None
            return _Amendments(document, None)
        assert stage.report_file is not None, (
            "amendments_stage takes a committee report only with its file"
        )
        document = TextDocument(url=stage.report_file, kind="committee_amendments")
        return _Amendments(document, stage.proposal)

    def _retry_documents(self, result: TrackingResult, *, publish: bool, may_wait: bool) -> None:
        if self._analysis is None or result.fatal_error is not None:
            return
        for work in self._repo.list_document_work(due=self._clock.now()):
            try:
                self._retry_document(work, result, publish=publish, may_wait=may_wait)
            except ServiceUnavailableError as exc:
                result.abort(exc)
                return
            except Exception as exc:
                self._defer_document(work, f"{type(exc).__name__}: {exc}")

    def _defer_document(self, work: DocumentWork, problem: str) -> None:
        attempts = work.attempts + 1
        self._repo.save_document_work(
            work.model_copy(
                update={
                    "attempts": attempts,
                    "problem": problem,
                    "state": "unsupported" if attempts >= 7 else "waiting",
                    "next_at": self._clock.now() + timedelta(days=min(7, 2**attempts)),
                }
            )
        )

    def _retry_document(
        self, work: DocumentWork, result: TrackingResult, *, publish: bool, may_wait: bool
    ) -> None:
        change = self._repo.get_status_change(work.change_id)
        if change is None:
            self._defer_document(work, "historical event unavailable")
            return
        original = self._repo.get_update_publication(work.change_id, self._options.channel_id)
        if not publish or original is None or original.status is not PublicationStatus.SENT:
            return
        if any(
            revision.status
            in (
                PublicationStatus.QUEUED,
                PublicationStatus.FAILED,
                PublicationStatus.PENDING,
                PublicationStatus.UNKNOWN,
            )
            for revision in self._repo.list_amendment_revisions(original.id or 0)
        ):
            return
        saved = original.delivery
        if (
            saved is None
            or not saved.bill_json
            or not saved.change_json
            or saved.update_group
            or saved.sitting_group
            or saved.continuation_ids
            or self._repo.digest_owner(original.id or 0) is not None
        ):
            self._defer_document(work, "historical delivery cannot be revised independently")
            return
        historical = Bill.model_validate_json(work.bill_json)
        detail = ProcessDetail.model_validate_json(work.detail_json)
        stage = Stage.model_validate_json(work.stage_json)
        if work.document_json is None or work.context_json is None:
            found = self._document_for_stage(stage, detail)
            if found is None:
                self._defer_document(work, "amendments document not confirmed")
                return
            assert self._analysis is not None
            context = self._analysis.amendments_context(
                historical, found.document, proposal=found.proposal
            )
            if context is None:
                self._defer_document(work, "amendments document unreadable")
                return
            work = work.model_copy(
                update={
                    "document_json": found.document.model_dump_json(),
                    "context_json": context.model_dump_json(),
                }
            )
            self._repo.save_document_work(work)
        assert work.document_json is not None and work.context_json is not None
        document = TextDocument.model_validate_json(work.document_json)
        context = AmendmentsContext.model_validate_json(work.context_json)
        assert self._analysis is not None
        record = self._analysis.summarize_amendments(
            historical,
            document,
            proposal=context.proposal,
            may_wait=may_wait,
            context=context,
        )
        if isinstance(record, Waiting):
            return
        if record is None:
            self._defer_document(work, "amendments document unreadable")
            return
        revised = StatusChange.model_validate_json(saved.change_json)
        revised.amendments = record
        delivery = saved.model_copy(
            update={
                "change_json": revised.model_dump_json(),
                "edit_message_id": original.message_id,
                "revision_of": original.id,
                "today": saved.today
                or original.created_at.astimezone(self._options.local_tz).date(),
            }
        )
        with self._repo.atomic():
            self._repo.save_status_change_amendments(work.change_id, record)
            self._repo.create_publication(
                Publication(
                    term=work.term,
                    number=work.number,
                    kind=PublicationKind.AMENDMENTS_REVISION,
                    status=PublicationStatus.QUEUED,
                    channel_id=self._options.channel_id,
                    ref=work.key,
                    created_at=self._clock.now(),
                    delivery=delivery,
                )
            )
            self._repo.save_document_work(
                work.model_copy(update={"state": "complete", "problem": ""})
            )

    def _summarize_amendments(
        self, bill: Bill, found: _Amendments, result: TrackingResult, *, may_wait: bool
    ) -> AmendmentsRecord | Waiting | None:
        """Best effort: a failure degrades the update to the bare event; outages propagate."""
        assert self._analysis is not None, (
            "_amendments_document finds nothing without an analysis service"
        )
        try:
            record = self._analysis.summarize_amendments(
                bill, found.document, proposal=found.proposal, may_wait=may_wait
            )
        except ServiceUnavailableError:
            raise
        except Exception as exc:
            log.warning("druk %s: amendments not summarised: %s", bill.number, exc)
            return None
        if isinstance(record, Waiting):
            if bill.awaiting_batch_since is None:
                self._repo.set_awaiting_batch(bill.term, bill.number, self._clock.now())
            return record
        if record is not None:
            result.count_usage(record)
            log.info("druk %s: amendments summarised from %s", bill.number, found.document.url)
        return record

    def _detect(
        self,
        bill: Bill,
        found: _Found,
        result: TrackingResult,
        *,
        may_wait: bool,
        deliver: bool = True,
    ) -> StatusChange | None:
        """The processed snapshot and its delivery work commit together, after network work."""
        detail = found.detail
        new_fp = stage_fingerprint(detail.stages)
        plan = plan_bill(
            bill,
            detail,
            analysis_document=self._texts.newer(bill, detail, found.print_info),
            closure_announced=self._repo.closure_announced(bill.term, bill.number),
        )
        may_wait = (
            may_wait
            and self._analysis is not None
            and self._analysis.may_wait_for_batch(bill.model_copy(update={"stages": detail.stages}))
        )
        paid = deliver or bill.observation_mode is not ObservationMode.METADATA
        change = self._detect_change(bill, found, plan, result, may_wait=may_wait, paid=paid)
        if isinstance(change, Waiting):
            if bill.awaiting_batch_since is None:
                self._repo.set_awaiting_batch(bill.term, bill.number, self._clock.now())
            result.waiting += 1
            return None
        # Stored with the committees named, so the card can address them by name: the name is
        # not part of `_stage_key`, so writing it moves no fingerprint and announces nothing.
        named = self._enricher.name_committees(bill.term, detail.stages)
        with self._repo.atomic():
            self._repo.set_awaiting_batch(bill.term, bill.number, None)
            self._repo.upsert_summary(detail, now=self._clock.now())
            self._repo.save_stages(bill.term, bill.number, named, new_fp)
            self._repo.save_observed_closure(bill.term, bill.number, detail.closure_date)
            self._remember_supplements(bill, found.print_info)
            fresh = self._repo.get(bill.term, bill.number)
            assert fresh is not None, "a tracked bill's row exists and was updated just above"
            self._repo.save_observed_process(
                bill.term, bill.number, observe(fresh, closure_date=detail.closure_date)
            )
            if change is not None:
                change = self._poster.record_change(change)
                stage = amendments_stage(change.new_stages) if change is not None else None
                if (
                    change is not None
                    and change.id is not None
                    and stage is not None
                    and change.amendments is None
                ):
                    now = self._clock.now()
                    self._repo.save_document_work(
                        DocumentWork(
                            key=f"amendments/{change.id}",
                            term=bill.term,
                            number=bill.number,
                            change_id=change.id,
                            bill_json=bill.model_dump_json(),
                            detail_json=detail.model_dump_json(),
                            stage_json=stage.model_dump_json(),
                            created_at=now,
                            next_at=now + timedelta(days=1),
                        )
                    )
                if change is not None and deliver:
                    if plan.should_publish(change):
                        self._poster.prepare(fresh, change)
                    else:
                        self._poster.hold(fresh, change)
        return change

    def _remember_supplements(self, bill: Bill, print_info: PrintInfo | None) -> None:
        """Written last, and only when the print was actually read: a run that could not fetch
        it must not forget the documents it knew about, and a run that told them must not tell
        them twice."""
        if print_info is None:
            return
        filed = tuple(p.number for p in print_info.additional_prints)
        if filed != bill.seen_supplements:
            self._repo.save_seen_supplements(bill.term, bill.number, filed)

    def _detect_change(
        self,
        bill: Bill,
        found: _Found,
        plan: BillPlan,
        result: TrackingResult,
        *,
        may_wait: bool,
        paid: bool = True,
    ) -> StatusChange | Waiting | None:
        """The one change worth a post, or None when there is nothing to tell.

        A first sight of the stages seeds them silently: there is no "before" to compare with.
        Closure is compared with the tracking baseline, which discovery must never overwrite.
        Stages that are gone again (edited or removed upstream) leave nothing to tell either,
        and neither does a change an earlier run already recorded.
        """
        detail = found.detail
        now = self._clock.now()
        content_changed = paid and self._reanalyze_new_text(
            bill, detail, plan.analysis_document, result
        )
        content_changed = content_changed or plan.content_changed
        old_fp = bill.stages_fingerprint
        if plan.previous is None:
            return None
        closure_detected = plan.closure_detected
        new_stages = plan.new_stages
        filed = found.supplements
        if not (
            new_stages or content_changed or closure_detected or plan.decision_changed or filed
        ):
            return None

        fresh = self._repo.get(bill.term, bill.number) or bill
        change = StatusChange(
            term=bill.term,
            number=bill.number,
            old_fingerprint=old_fp,
            new_fingerprint=change_key(
                plan.observed.fingerprint,
                fresh,
                closed=closure_detected,
                supplements=[s.number for s in filed],
            ),
            new_stages=[self._enricher.enrich(bill.term, st) for st in new_stages],
            closure_detected=closure_detected,
            decision_changed=plan.decision_changed,
            passed=detail.passed,
            content_changed=content_changed,
            detected_at=now,
        )
        waiting = None
        if not paid:
            change.supplements.extend(
                self._analysis.bare_supplement(s.document, number=s.number, title=s.title)
                for s in filed
                if self._analysis is not None
            )
            _log_change(bill, change)
            return change
        if found.amendments is not None:
            waiting = self._attach_amendments(
                change, bill, found.amendments, result, may_wait=may_wait
            )
        if filed:
            supplement_wait = self._attach_supplements(
                change, bill, filed, result, may_wait=may_wait
            )
            waiting = waiting or supplement_wait
        if waiting is not None:
            return waiting
        _log_change(bill, change)
        return change

    def _reanalyze_new_text(
        self,
        bill: Bill,
        detail: ProcessDetail,
        document: TextDocument | None,
        result: TrackingResult,
    ) -> bool:
        """True when the model read a text we had not read and named what changed in it."""
        if self._analysis is None:
            return False
        if bill.status is BillStatus.REANALYSIS_READY and bill.ready_analysis is not None:
            document = bill.ready_analysis.located.document or document
        if document is None:
            return False
        log.info("druk %s: new text (%s), re-analysing", bill.number, document.kind)
        record = self._analysis.reanalyze_bill(bill, document, summary=detail)
        if record is None:
            return False
        result.count_reanalysis(record)
        return record.analysis.names_changes

    def _attach_supplements(
        self,
        change: StatusChange,
        bill: Bill,
        filed: list[_Supplement],
        result: TrackingResult,
        *,
        may_wait: bool,
    ) -> Waiting | None:
        """Memoized digests survive a failure before the observation checkpoint commits."""
        assert self._analysis is not None, "_supplements files nothing without an analysis service"
        waiting = None
        for supplement in filed:
            try:
                record = self._analysis.digest_supplement(
                    bill,
                    supplement.document,
                    number=supplement.number,
                    title=supplement.title,
                    may_wait=may_wait,
                )
            except ServiceUnavailableError:
                raise
            except Exception as exc:
                log.warning("druk %s: %s not digested: %s", bill.number, supplement.number, exc)
                record = self._analysis.bare_supplement(
                    supplement.document, number=supplement.number, title=supplement.title
                )
            if isinstance(record, Waiting):
                if bill.awaiting_batch_since is None and waiting is None:
                    self._repo.set_awaiting_batch(bill.term, bill.number, self._clock.now())
                waiting = record
                continue
            if record.digest is not None:
                result.count_usage(record)
            change.supplements.append(record)
        return waiting

    def _attach_amendments(
        self,
        change: StatusChange,
        bill: Bill,
        found: _Amendments,
        result: TrackingResult,
        *,
        may_wait: bool,
    ) -> Waiting | None:
        """Memoization keeps a checkpoint retry from paying for the same amendment summary."""
        record = self._summarize_amendments(bill, found, result, may_wait=may_wait)
        if isinstance(record, Waiting):
            return record
        change.amendments = record
        return None


def _log_change(bill: Bill, change: StatusChange) -> None:
    log.info(
        "druk %s: %d new stage(s)%s%s%s: %s",
        bill.number,
        len(change.new_stages),
        " + new text" if change.content_changed else "",
        " + amendments" if change.amendments is not None else "",
        f" + {len(change.supplements)} filed document(s)" if change.supplements else "",
        "; ".join(st.stage_name for st in change.new_stages) or "-",
    )
