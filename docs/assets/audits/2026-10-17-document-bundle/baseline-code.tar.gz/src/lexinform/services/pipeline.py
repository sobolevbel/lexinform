"""The daily run: discover -> prefilter -> analyse -> publish -> track -> report.

Discovery works in the current Sejm term (see `TermResolver`); the queues and the tracking are
not scoped to a term (every row carries its own), so that the bills of the previous kadencja that
still matter (acts on their way to Dziennik Ustaw, reminders, failed posts) are not forgotten when
the Sejm moves on.
"""

import logging
import time
from collections.abc import Callable, Sequence
from datetime import datetime, timedelta
from typing import Literal

from pydantic import BaseModel

from lexinform.errors import ServiceUnavailableError
from lexinform.logging_setup import MemoryLogHandler
from lexinform.models import PrefilterRejection, RunMode, RunReport, merge_usage
from lexinform.ports import BillRepository, Clock, RunNotifier
from lexinform.services.analysis import AnalysisService
from lexinform.services.commands import CommandService
from lexinform.services.digest import DigestService
from lexinform.services.discovery import BillDiscoveryService
from lexinform.services.publishing import PublishingService
from lexinform.services.rcl_discovery import RclDiscoveryService
from lexinform.services.terms import TermResolver
from lexinform.services.text_prefilter import TextPrefilterService
from lexinform.services.tracking import StatusTrackingService
from lexinform.services.tracking_result import TrackingResult, merge_tracking
from lexinform.services.wykaz_discovery import WykazDiscoveryService

log = logging.getLogger(__name__)


class RunOptions(BaseModel):
    """What one run should do; built by the CLI from settings and flags.

    `term` is the current one as the Sejm API reports it unless it is pinned here. `rcl` and
    `wykaz` add the two government sources (when the pipeline was given those services),
    `full_track` checks every followed bill rather than only those the API lists as changed, and
    `commands` answers the operator commands waiting in the inbox (when one is configured).
    """

    term: int | None = None
    since: datetime | None = None
    dry_run: bool = False
    discover: bool = True
    rcl: bool = True
    wykaz: bool = True
    publish: bool = True
    track: bool = True
    max_publish: int = 10
    max_analyze: int = 40
    max_text_prefilter: int = 20
    min_score: int = 3
    full_track: bool = False
    commands: bool = True
    digest: bool = True
    mode: RunMode = RunMode.RUN


class DailyPipeline:
    """Runs the phases in order, isolates their failures and produces the run report.

    `commands` is None when no inbox is configured, and `full_track_weekday` is the weekday on
    which every followed bill is checked (Monday by default; None never does).
    """

    def __init__(
        self,
        repo: BillRepository,
        discovery: BillDiscoveryService,
        analysis: AnalysisService,
        publishing: PublishingService,
        tracking: StatusTrackingService,
        clock: Clock,
        *,
        terms: TermResolver,
        notifier: RunNotifier | None = None,
        text_prefilter: TextPrefilterService | None = None,
        rcl_discovery: RclDiscoveryService | None = None,
        wykaz_discovery: WykazDiscoveryService | None = None,
        commands: CommandService | None = None,
        digest: DigestService | None = None,
        first_run_lookback_days: int = 1,
        rerun_overlap_days: int = 1,
        runs_retention_days: int | None = 90,
        history_payload_retention_days: int = 90,
        analysis_memo_retention_days: int = 180,
        pre_print: bool = True,
        full_track_weekday: int | None = 0,
    ) -> None:
        self._repo = repo
        self._discovery = discovery
        self._analysis = analysis
        self._publishing = publishing
        self._tracking = tracking
        self._clock = clock
        self._terms = terms
        self._notifier = notifier
        self._text_prefilter = text_prefilter
        self._rcl_discovery = rcl_discovery
        self._wykaz_discovery = wykaz_discovery
        self._commands = commands
        self._digest = digest
        self._first_run_lookback = timedelta(days=first_run_lookback_days)
        self._overlap = timedelta(days=rerun_overlap_days)
        self._runs_retention = (
            timedelta(days=runs_retention_days) if runs_retention_days is not None else None
        )
        self._pre_print = pre_print
        self._history_retention = timedelta(days=history_payload_retention_days)
        self._memo_retention = timedelta(days=analysis_memo_retention_days)
        self._full_track_weekday = full_track_weekday

    def resolve_since(self, requested: datetime | None) -> datetime:
        """Discovery watermark: the start of the last run that completed discovery, minus overlap.

        Publishing or analysis errors do not hold the watermark back: bills are stored on discovery
        and retried from the database, so only a failed discovery must be re-scanned.
        """
        if requested is not None:
            return requested
        last = self._repo.last_discovery_started_at()
        if last is not None:
            return last - self._overlap
        return self._clock.now() - self._first_run_lookback

    def run(self, opts: RunOptions) -> RunReport:
        """One whole run: every failure is caught, because the report is how the run is heard
        from and a process that crashes says nothing at all."""
        started = self._clock.now()
        report = RunReport(
            started_at=started,
            since=started,
            mode=RunMode.DRY_RUN if opts.dry_run else opts.mode,
            prefilter_rejected=[],
        )
        captured = MemoryLogHandler()
        captured.install()
        run_id: int | None = None
        self._analysis.start_run(dry_run=opts.dry_run)
        try:
            self._repo.migrate()
            report.since = self.resolve_since(opts.since)
            if opts.dry_run:
                self._repo.begin()
            run_id = self._repo.start_run(report)
            report.term = self._resolve_term(opts, report)
            if report.term is not None:
                log.info(
                    "run started (mode=%s, since=%s, term=%d)",
                    report.mode,
                    report.since.isoformat(),
                    report.term,
                )
                self._execute(opts, report.term, report.since, report)
        except Exception as exc:
            log.exception("run failed unexpectedly: %s", exc)
            report.errors.append(f"unexpected failure: {type(exc).__name__}: {exc}")
        finally:
            report.finished_at = self._clock.now()
            self._phase(report, "batch status", lambda: self._batch_status(report))
            # Every phase that asks the model goes through one `AnalysisService`, so this is the
            # whole run's spend, however it was reached, and it is recorded before the report is
            # stored — a run that fell over still says what it had spent by then.
            report.llm_calls = self._analysis.calls
            report.llm_input_tokens = sum(call.input_tokens for call in report.llm_calls)
            report.llm_output_tokens = sum(call.output_tokens for call in report.llm_calls)
            report.llm_usage = {}
            for call in report.llm_calls:
                merge_usage(report.llm_usage, call.usage)
            if run_id is not None:
                try:
                    with self._repo.atomic():
                        self._repo.finish_run(run_id, report)
                        self._analysis.acknowledge_batch_costs()
                except Exception as exc:
                    log.exception("could not record the run: %s", exc)
                    report.errors.append(f"could not record the run: {type(exc).__name__}: {exc}")
            if opts.dry_run:
                try:
                    self._repo.rollback()
                    log.info("dry run: database changes rolled back")
                except Exception as exc:
                    log.exception("dry run: could not roll back: %s", exc)
                    report.errors.append(f"could not roll back: {type(exc).__name__}: {exc}")
            captured.uninstall()
            self._notify(report, captured)
        log.info(
            "run finished ok=%s discovered=%d hits=%d analyzed=%d failures=%d "
            "published=%d updates=%d reanalyzed=%d",
            report.ok,
            report.discovered,
            report.prefilter_hits,
            report.analyzed,
            report.analysis_failures,
            report.published,
            report.updates,
            report.reanalyzed,
        )
        return report

    def _resolve_term(self, opts: RunOptions, report: RunReport) -> int | None:
        """The term to discover in; None (with the reason in the report) when nothing is known."""
        if opts.term is not None:
            return opts.term
        try:
            return self._terms.current()
        except ServiceUnavailableError as exc:
            message = f"term: {exc.describe()}"
        except Exception as exc:
            message = f"term: {type(exc).__name__}: {exc}"
        log.error(message, extra={"in_report": True})
        report.errors.append(message)
        return None

    def _execute(self, opts: RunOptions, current: int, since: datetime, report: RunReport) -> None:
        """The phases of a run, in the order they depend on each other."""
        self._report_stale_publications(report)
        self._prune_runs()
        pruned = self._repo.prune_history(
            before=self._clock.now() - self._history_retention,
            memo_before=self._clock.now() - self._memo_retention,
        )
        if any(pruned.values()):
            log.info("history payload cleanup: %s", pruned)
        self._run_phases(opts, current, since, report)

    def _report_stale_publications(self, report: RunReport) -> None:
        """Ambiguous attempts need an operator's /delivery decision before another send."""
        stale = self._repo.mark_stale_pending_as_unknown(now=self._clock.now())
        if not stale:
            return
        msg = (
            f"{len(stale)} publication(s) were left pending by a previous run and are never"
            f" re-sent; marked unknown: {', '.join(stale[:10])}"
        )
        log.error(msg, extra={"in_report": True})
        report.errors.append(msg)

    def _prune_runs(self) -> None:
        if self._runs_retention is None:
            return
        pruned = self._repo.prune_runs(before=self._clock.now() - self._runs_retention)
        if pruned:
            log.info("%d run record(s) older than %s removed", pruned, self._runs_retention)

    def _run_phases(
        self, opts: RunOptions, current: int, since: datetime, report: RunReport
    ) -> None:
        """New bills come from the current Sejm; the queues and the tracking are not scoped to a
        term, because every row carries its own.

        The order is what the phases need of each other: the end of a term before discovery sees
        the old rows, the commands before discovery so a card one posts is tracked by this run,
        the wykaz before RCL so a project joins its own plan's thread, and RCL a phase of its own
        so an outage there costs the Sejm discovery nothing.
        """
        # First, so a batch an earlier run filed is written down before publishing/tracking act.
        self._phase(report, "collect batches", self._analysis.collect_batches)
        uncertain = self._analysis.uncertain_batch_intent_ids()
        if uncertain:
            report.errors.append(
                f"{len(uncertain)} batch submission(s) uncertain: "
                f"{', '.join(uncertain[:10])}; use lexinform batch-intents"
            )
        previous = [term for term in self._repo.known_terms() if term < current]
        if previous:
            self._phase(
                report, "end of term", lambda: self._close_terms(previous, current, opts, report)
            )
        if opts.commands and self._commands is not None:
            self._phase(report, "commands", lambda: self._handle_commands(opts, report))
        if opts.discover:
            self._phase(report, "discovery", lambda: self._discover(current, since, report))
        # The register names projects the RCL listing does not show as changed; the RCL phase
        # takes them, so that a gov.pl outage costs RCL nothing and an RCL outage costs the
        # register nothing.
        named_by_register: list[int] = []
        if opts.discover and opts.wykaz and self._wykaz_discovery is not None:
            self._phase(
                report,
                "wykaz discovery",
                lambda: named_by_register.extend(self._discover_wykaz(current, since, report)),
            )
        if opts.discover and opts.rcl and self._rcl_discovery is not None:
            self._phase(
                report,
                "rcl discovery",
                lambda: self._discover_rcl(current, since, report, named_by_register),
            )
        if self._text_prefilter is not None:
            self._phase(report, "text prefilter", lambda: self._prefilter_text(opts, report))
        # After the text prefilter, because what it promotes is exactly what is still missing a
        # consultation letter, and before the analysis, because the card is written from both.
        if opts.rcl and self._rcl_discovery is not None:
            self._phase(report, "rcl consultations", self._read_rcl_consultations)
        self._phase(report, "analysis", lambda: self._analyse(opts, report))
        self._phase(report, "publishing", lambda: self._publish(opts, report))
        if opts.track:
            self._phase(report, "tracking", lambda: self._track(opts, report))
        # Skipped on a dry run: a real batch submission has no rollback.
        if not opts.dry_run:
            self._phase(report, "submit batches", lambda: self._submit_batches(report))
        # After tracking, so that the week's own posts are in it; the service decides whether
        # today is the day, and it asks the Warsaw calendar and not the runner's.
        if opts.digest and opts.publish and self._digest is not None:
            self._phase(report, "digest", lambda: self._draft_digest(report))

    def _submit_batches(self, report: RunReport) -> None:
        before = {batch.batch_id for batch in self._repo.list_open_llm_batches()}
        try:
            self._analysis.submit_queued_batches()
        finally:
            report.batch_requests_submitted += sum(
                batch.request_count
                for batch in self._repo.list_open_llm_batches()
                if batch.batch_id not in before
            )

    def _batch_status(self, report: RunReport) -> None:
        report.batch_requests_pending = sum(
            item.consumed_at is None
            for batch in self._repo.list_open_llm_batches()
            for item in self._repo.list_llm_batch_items(batch.batch_id)
        )
        report.batch_requests_queued = len(self._repo.list_queued_batch_intents())
        report.batch_requests_uncertain = len(self._repo.list_submitting_batch_intents())

    @staticmethod
    def _phase(report: RunReport, name: str, action: Callable[[], None]) -> None:
        """Run one phase; an outage or a bug ends the phase, not the run.

        `in_report` keeps these log lines out of the captured warnings: they are errors already.
        """
        started = time.perf_counter()
        try:
            action()
        except ServiceUnavailableError as exc:
            message = f"{name}: {exc.describe()}"
            log.error(message, extra={"in_report": True})
            report.errors.append(message)
        except Exception as exc:
            message = f"{name} failed: {type(exc).__name__}: {exc}"
            log.exception(message, extra={"in_report": True})
            report.errors.append(message)
        finally:
            elapsed = time.perf_counter() - started
            report.phase_seconds[name] = round(elapsed, 1)
            log.info("%s took %.1fs", name, elapsed)

    def _handle_commands(self, opts: RunOptions, report: RunReport) -> None:
        assert self._commands is not None, "run() starts this phase only with a command service"
        handled = self._commands.handle_pending(
            min_score=opts.min_score,
            run_started_at=report.started_at,
            publish=opts.publish,
            dry_run=opts.dry_run,
        )
        report.commands_handled = handled.handled
        report.commands_failed = handled.failed
        report.commands = handled.lines
        report.llm_input_tokens += handled.input_tokens
        report.llm_output_tokens += handled.output_tokens
        merge_usage(report.llm_usage, handled.usage)
        if handled.fatal_error:
            report.errors.append(f"commands: {handled.fatal_error}")

    def _discover(self, term: int, since: datetime, report: RunReport) -> None:
        discovered = self._discovery.discover(term, since, pre_print=self._pre_print)
        report.discovery_ok = True
        report.discovered = discovered.new
        report.pre_print_discovered = discovered.pre_print_new
        report.prefilter_hits = discovered.prefilter_hits
        report.prefilter_rejected = [*(report.prefilter_rejected or []), *discovered.rejected]
        self._prefilter_details(report, discovered.rejected, "title")
        report.over_on_arrival += discovered.over

    def _discover_rcl(
        self, term: int, since: datetime, report: RunReport, from_register: Sequence[int] = ()
    ) -> None:
        assert self._rcl_discovery is not None, (
            "run() starts the RCL phases only with RCL discovery"
        )
        discovered = self._rcl_discovery.discover(term, since, from_register=from_register)
        report.rcl_discovered = discovered.new
        report.rcl_prefilter_hits = discovered.prefilter_hits
        report.prefilter_rejected = [*(report.prefilter_rejected or []), *discovered.rejected]
        self._prefilter_details(report, discovered.rejected, "title")
        report.over_on_arrival += discovered.over
        if discovered.failed:
            report.errors.append(f"{discovered.failed} RCL project(s) could not be read")

    def _discover_wykaz(self, term: int, since: datetime, report: RunReport) -> list[int]:
        assert self._wykaz_discovery is not None, (
            "run() starts this phase only with wykaz discovery"
        )
        discovered = self._wykaz_discovery.discover(term, since)
        report.wykaz_discovered = discovered.new
        report.over_on_arrival += discovered.over
        return discovered.on_rcl

    def _read_rcl_consultations(self) -> None:
        assert self._rcl_discovery is not None, (
            "run() starts the RCL phases only with RCL discovery"
        )
        self._rcl_discovery.read_consultations()

    def _prefilter_text(self, opts: RunOptions, report: RunReport) -> None:
        assert self._text_prefilter is not None, (
            "run() starts this phase only with a text prefilter"
        )
        checked = self._text_prefilter.run(limit=opts.max_text_prefilter)
        report.text_prefilter_checked = checked.checked
        report.prefilter_rejected = [*(report.prefilter_rejected or []), *checked.rejected]
        self._prefilter_details(report, checked.rejected, "text")
        self._prefilter_details(report, checked.unreadable_bills, "unreadable")
        report.text_prefilter_hits = checked.hits
        report.text_prefilter_scans = checked.scans
        report.text_prefilter_unreadable = checked.unreadable
        report.text_prefilter_unanswered = checked.unanswered
        if checked.fatal_error:
            report.errors.append(f"text prefilter: {checked.fatal_error}")

    def _prefilter_details(
        self,
        report: RunReport,
        keys: Sequence[str],
        stage: Literal["title", "text", "unreadable"],
    ) -> None:
        for key in keys:
            term, number = key.split("/", 1)
            bill = self._repo.get(int(term), number)
            if bill is None:
                continue
            reason = bill.last_error or "title prefilter: no strong keyword hits"
            report.prefilter_details.append(
                PrefilterRejection(
                    term=bill.term,
                    number=bill.number,
                    title=bill.summary.title,
                    stage=stage,
                    reason=reason,
                )
            )
            log.info("prefilter %s: %s | %s | %s", stage, key, bill.summary.title, reason)

    def _analyse(self, opts: RunOptions, report: RunReport) -> None:
        analysed = self._analysis.analyze_pending(limit=opts.max_analyze)
        report.analyzed = analysed.analyzed
        report.triaged_out = analysed.triaged_out
        report.analysis_failures = analysed.failed
        report.analysis_skipped_cost = analysed.skipped_cost
        report.analysis_unanswered = analysed.unanswered
        report.joint_revived = analysed.revived_joint
        if analysed.stopped:
            report.notes.append(f"analysis: {analysed.stopped}")
        report.rejected = [
            v for v in analysed.verdicts if not v.relevant or v.score < opts.min_score
        ]
        report.llm_input_tokens += analysed.input_tokens
        report.llm_output_tokens += analysed.output_tokens
        merge_usage(report.llm_usage, analysed.usage)
        if analysed.fatal_error:
            report.errors.append(f"analysis: {analysed.fatal_error}")

    def _publish(self, opts: RunOptions, report: RunReport) -> None:
        published = self._publishing.publish_new(
            min_score=opts.min_score, limit=opts.max_publish, publish=opts.publish, may_wait=True
        )
        report.errors.extend(f"publishing: {error}" for error in published.partial_errors)
        report.published = published.published
        report.message_parts_sent += published.message_parts_sent
        report.joint_published = published.joined
        for key, count in published.attention.items():
            report.attention[key] = report.attention.get(key, 0) + count
        report.batch_waiting += published.waiting
        if published.fatal_error:
            report.errors.append(f"publishing: {published.fatal_error}")
        elif published.failed:
            report.errors.append(f"{published.failed} publication(s) failed")

    def _close_terms(
        self, previous: Sequence[int], current: int, opts: RunOptions, report: RunReport
    ) -> None:
        failed = 0
        for term in previous:
            closed = self._tracking.close_term(term, current, publish=opts.publish)
            failed += self._merge_tracking(report, closed, opts)
            if closed.fatal_error is not None:
                report.errors.append(f"end of term: {closed.fatal_error}")
                return
        if failed:
            report.errors.append(f"{failed} end-of-term update(s) failed")

    def _track(self, opts: RunOptions, report: RunReport) -> None:
        """Daily, only the bills the API listed as modified; once a week, or whenever discovery
        did not run, every followed bill, in case something moved without a visible change."""
        full = opts.full_track or not opts.discover or not report.discovery_ok or self._full_day()
        tracked = self._tracking.check_updates(
            keep_delivery_attempts=True,
            publish=opts.publish,
            changed_since=None if full else report.since,
        )
        failed = self._merge_tracking(report, tracked, opts)
        if self._analysis.stopped:
            report.notes.append(f"tracking: {self._analysis.stopped}")
        if tracked.fatal_error is not None:
            report.errors.append(f"tracking: {tracked.fatal_error}")
        elif failed:
            report.errors.append(f"{failed} status update(s) failed")

    def _draft_digest(self, report: RunReport) -> None:
        assert self._digest is not None, "run() starts this phase only with a digest service"
        result = self._digest.run(current_report=report)
        report.digest_drafted = result.drafted
        report.digest_reader_parts += result.reader_parts
        report.digest_events_covered += result.covered_events
        if result.drafted:
            report.notes.append(f"digest {result.ref} drafted, waiting for the button")
        elif result.failed:
            report.errors.append(f"digest: {result.note}")

    def _full_day(self) -> bool:
        return (
            self._full_track_weekday is not None
            and self._clock.now().weekday() == self._full_track_weekday
        )

    @staticmethod
    def _merge_tracking(report: RunReport, tracked: TrackingResult, opts: RunOptions) -> int:
        return merge_tracking(report, tracked, publish=opts.publish)

    def _notify(self, report: RunReport, captured: MemoryLogHandler) -> None:
        """Send the run report to the log channel; a failure there must never break the run.

        A commands run that went well says nothing: the replies under the commands themselves
        have told the operator everything, and a report for a kick is noise.
        """
        if self._notifier is None:
            return
        if report.mode is RunMode.COMMANDS and report.ok:
            return
        lines = list(captured.lines)
        if captured.dropped:
            lines.append(f"... and {captured.dropped} more")
        try:
            self._notifier.notify(report, lines)
        except Exception as exc:
            log.exception("run notification failed: %s", exc)
