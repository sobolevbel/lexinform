"""Public consultations after the card: the reminder a few days before they close (the moment
readers can still send an opinion, which is the point of the whole channel) and the notice that
the Sejm published the opinions received."""

import logging
from zoneinfo import ZoneInfo

from lexinform.errors import ServiceUnavailableError
from lexinform.models import Bill, Publication, PublicationKind, PublicationStatus
from lexinform.ports import BillRepository, Clock
from lexinform.services.document_reviews import DocumentReviews
from lexinform.services.posting import Poster
from lexinform.services.tracking_result import TrackingResult

log = logging.getLogger(__name__)


class ConsultationReminder:
    """The two consultation replies: the deadline reminder and the "opinions published" notice."""

    def __init__(
        self,
        repo: BillRepository,
        clock: Clock,
        poster: Poster,
        *,
        channel_id: str,
        local_tz: ZoneInfo,
        days_before: int,
    ) -> None:
        self._repo = repo
        self._clock = clock
        self._poster = poster
        self._channel_id = channel_id
        self._local_tz = local_tz
        self._days_before = days_before
        self._reviews: DocumentReviews | None = None

    def set_reviews(self, reviews: DocumentReviews | None) -> None:
        self._reviews = reviews

    def review_documents(self, bill: Bill, result: TrackingResult) -> None:
        if self._reviews is not None and self._poster.card(bill) is not None:
            self._reviews.request(bill, "consultation_review", result)

    def prepare_results(self, bill: Bill) -> Publication | None:
        card = self._poster.card(bill)
        if card is None or card.status is not PublicationStatus.SENT:
            return None
        if self._poster.posted(bill, PublicationKind.CONSULTATION_RESULTS):
            return None
        return self._poster.prepare_message(bill, PublicationKind.CONSULTATION_RESULTS)

    def results_published(self, bill: Bill, result: TrackingResult, *, publish: bool) -> bool:
        self.review_documents(bill, result)
        publication = self.prepare_results(bill)
        if publication is None or not publish:
            return True
        if publication.delivery is not None and publication.delivery.destination == "digest_only":
            return True
        sent = self._poster.deliver(publication)
        result.count_post(sent, "consultation_results_posted")
        return sent

    def remind(self, result: TrackingResult) -> None:
        """One reply `days_before` days before a consultation closes (Warsaw time)."""
        today = self._clock.now().astimezone(self._local_tz).date()
        due = self._repo.list_due_consultations(
            self._channel_id, today=today, days_before=self._days_before
        )
        for bill in due:
            if self._poster.posted(bill, PublicationKind.CONSULTATION_DEADLINE):
                continue
            try:
                sent = self._poster.consultation_deadline(bill, today=today)
                result.count_post(sent, "consultation_reminders")
            except ServiceUnavailableError as exc:
                result.abort(exc, failed=True)
                return
