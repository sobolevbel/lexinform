"""Exceptions shared by adapters and services.

`ServiceUnavailableError` means an external system (Sejm API, LLM, Telegram) is down or
rejecting us as a whole. Services treat it as phase-fatal: stop the current phase, do not
burn per-bill retry attempts, report a clear message. Anything else is a per-bill problem.
"""


class ServiceUnavailableError(RuntimeError):
    system: str = "external service"

    def describe(self) -> str:
        return f"{self.system} unavailable: {self}"


class SejmApiUnavailableError(ServiceUnavailableError):
    system = "Sejm API"


class RclUnavailableError(ServiceUnavailableError):
    """legislacja.rcl.gov.pl is down, or its WAF answered "Request Rejected" to our request."""

    system = "RCL"


class WykazUnavailableError(ServiceUnavailableError):
    """gov.pl does not answer, so the wykaz prac legislacyjnych RM cannot be read."""

    system = "wykaz prac RM"


class SenateUnavailableError(ServiceUnavailableError):
    """senat.gov.pl does not answer, so the Senate's committees of an act cannot be named."""

    system = "senat.gov.pl"


class OrkaUnreachableError(RuntimeError):
    """orka.sejm.gov.pl did not hand over the file — deliberately a per-bill problem.

    Imperva judges a client by its address as well as its identity and can start refusing us with
    nothing changed on our side; everything else the analysis reads is api.sejm.gov.pl, so as a
    `ServiceUnavailableError` one WAF decision would stop the whole phase every run.

    `status_code` tells a file that is not there (404 — the address is built by convention) from
    the host refusing us, which is every other answer: a caller that would write the bill off for
    good has to know the difference.
    """

    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code

    @property
    def file_is_missing(self) -> bool:
        return self.status_code == 404


class AttachmentTooLargeError(RuntimeError):
    """A download was stopped because the body exceeded the caller's limit (per-item problem)."""

    def __init__(self, url: str, limit: int) -> None:
        super().__init__(f"{url} exceeds {limit} bytes")
        self.url = url
        self.limit = limit


class DocumentSelectionError(RuntimeError):
    def __init__(self, state: str, reason: str) -> None:
        super().__init__(f"{state}: {reason}")
        self.state = state


class LlmUnavailableError(ServiceUnavailableError):
    system = "LLM API"


class LlmContextExceededError(RuntimeError):
    """The provider rejected this input because it exceeds the model's context."""


class BatchNotSubmittedError(LlmUnavailableError):
    """The provider definitively rejected a batch before accepting any work."""


class TelegramUnavailableError(ServiceUnavailableError):
    system = "Telegram API"


class DeliveryUncertainError(ServiceUnavailableError):
    """A message may have been accepted; retry requires an audited operator decision."""

    system = "message delivery"
