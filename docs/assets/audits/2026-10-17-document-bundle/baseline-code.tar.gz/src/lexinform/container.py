"""Manual wiring of adapters and services; the CLI and the tests build a `Container` and ask it
for the pipeline or for single services. Every collaborator is typed on its port, so the test
harness builds the same container from fakes and the wiring the daily run uses is what the
tests exercise."""

import os
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import timedelta
from typing import cast
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

import anthropic
import openai

from lexinform.adapters.batch_checkpoint import GitBatchCheckpoint
from lexinform.adapters.console import ConsolePublisher, ConsoleReplier, ConsoleRunNotifier
from lexinform.adapters.consultation_documents import SejmConsultationDocuments
from lexinform.adapters.doc_text import DocTextExtractor
from lexinform.adapters.document_text import DocumentTextExtractor, DocxTextExtractor
from lexinform.adapters.github_inbox import GitHubInboxWriter
from lexinform.adapters.inbox_files import FileInbox
from lexinform.adapters.llm_anthropic import AnthropicAnalyzer
from lexinform.adapters.llm_hybrid import HybridAnalyzer
from lexinform.adapters.llm_openai import OpenAiAnalyzer
from lexinform.adapters.llm_prompts import PROMPT_VERSION
from lexinform.adapters.orka import OrkaClient
from lexinform.adapters.pdf_text import PypdfTextExtractor
from lexinform.adapters.rcl_html import RclClient
from lexinform.adapters.sejm_api import SejmApiClient
from lexinform.adapters.senat_html import SenateClient
from lexinform.adapters.sqlite_repo import SqliteBillRepository
from lexinform.adapters.telegram import (
    TelegramAcknowledger,
    TelegramBotClient,
    TelegramOperatorReplier,
    TelegramPublisher,
    TelegramRunNotifier,
)
from lexinform.adapters.telegram_format import APPROVE_DIGEST, MessageFormatter
from lexinform.adapters.wykaz_csv import WykazClient
from lexinform.clock import SystemClock
from lexinform.keywords import KeywordPrefilter
from lexinform.models import BatchProvider, provider_of
from lexinform.ports import (
    BatchBackend,
    BillRepository,
    Clock,
    CommandInbox,
    Downloader,
    LlmAnalyzer,
    OperatorReplier,
    Publisher,
    RclGateway,
    RunNotifier,
    SejmApi,
    SenateGateway,
    TextExtractor,
    WykazGateway,
)
from lexinform.pricing import input_limit_of, price_of
from lexinform.sections import TextBudget
from lexinform.services.amendments import AmendmentsService
from lexinform.services.analysis import AnalysisOptions, AnalysisService
from lexinform.services.commands import CommandService
from lexinform.services.delivery import DeliveryService
from lexinform.services.delivery_notifier import DeliveryNotifier
from lexinform.services.digest import DigestService
from lexinform.services.discovery import BillDiscoveryService
from lexinform.services.document_reviews import DocumentReviews
from lexinform.services.documents import TextLoader
from lexinform.services.listener import CommandListener
from lexinform.services.lookup import BillLookup
from lexinform.services.pipeline import DailyPipeline
from lexinform.services.posting import Poster
from lexinform.services.publishing import PublishingService
from lexinform.services.rcl_discovery import RclDiscoveryService
from lexinform.services.rcl_projects import RclProjectReader
from lexinform.services.signatories import SejmAuthorsResolver
from lexinform.services.sources import (
    RclTextSource,
    SejmTextIdentity,
    SejmTextSource,
    SubmissionTextSource,
    TextSources,
)
from lexinform.services.terms import TermResolver
from lexinform.services.text_prefilter import TextPrefilterService
from lexinform.services.tracking import StatusTrackingService, TrackingOptions
from lexinform.services.wykaz_discovery import WykazDiscoveryService
from lexinform.settings import Settings

LOCAL_TZ = ZoneInfo("Europe/Warsaw")


@dataclass
class Container:
    """The wiring. Services are built once and shared (`discovery_service()` and the pipeline's
    discovery are the same object), so a test can hold a service and run the pipeline.

    `LOCAL_TZ` is the readers' and the Sejm's day, whatever zone the runner is in. `rcl`,
    `wykaz` and `senate` are None when their source is switched off in the settings, and the four
    `*_override` fields, `llm` and `extractor` are what a test or a dry run supplies instead of
    the real adapters.
    """

    settings: Settings
    clock: Clock
    repo: BillRepository
    gateway: SejmApi
    formatter: MessageFormatter
    prefilter: KeywordPrefilter
    terms: TermResolver
    rcl: RclGateway | None = None
    wykaz: WykazGateway | None = None
    senate: SenateGateway | None = None
    orka: Downloader | None = None
    llm: LlmAnalyzer | None = None
    batch_override: BatchBackend | None = None
    overflow_batch_override: BatchBackend | None = None
    analysis_options_override: AnalysisOptions | None = None
    extractor: TextExtractor | None = None
    publisher_override: Publisher | None = None
    notifier_override: RunNotifier | None = None
    inbox_override: CommandInbox | None = None
    replier_override: OperatorReplier | None = None
    _telegram: TelegramBotClient | None = field(default=None, init=False, repr=False)
    _loader: TextLoader | None = field(default=None, init=False, repr=False)
    _services: dict[str, object] = field(default_factory=dict, init=False, repr=False)

    def term(self) -> int:
        """The Sejm term operator commands work in: `LEXINFORM_TERM` when set, else the current
        one as the API reports it (the newest one in the database when the API is down)."""
        return self.terms.current()

    def bill_lookup(self) -> BillLookup:
        """One bill by number or reference, fetched and prefiltered on first sight."""
        return self._once(
            "lookup",
            lambda: BillLookup(
                self.gateway,
                self.repo,
                self.prefilter,
                self.clock,
                self.terms,
                rcl_reader=self.rcl_reader() if self.rcl is not None else None,
                projects=self.rcl,
                wykaz=self.wykaz,
                text_prefilter=self.settings.text_prefilter_enabled,
            ),
        )

    def _once[T](self, key: str, factory: Callable[[], T]) -> T:
        """One instance per service (and per dry-run flag where it matters)."""
        if key not in self._services:
            self._services[key] = factory()
        return cast(T, self._services[key])

    def text_loader(self) -> TextLoader:
        """One loader (and text cache) per process, shared by the text prefilter and analysis.
        Downloads are routed by host to the client of that system."""
        if self._loader is None:
            downloaders: dict[str, Downloader] = {
                _host(self.settings.sejm_api_base_url): self.gateway.download,
                "www.sejm.gov.pl": self.gateway.download,
                "sejm.gov.pl": self.gateway.download,
            }
            orka = _host(self.settings.orka_base_url)
            if orka not in downloaders:
                downloaders[orka] = self.orka_downloader()
            if self.rcl is not None:
                downloaders[_host(self.settings.rcl_base_url)] = self.rcl.download
            max_bytes = self.settings.max_pdf_download_mb * 1024 * 1024
            extractor = self.extractor or DocumentTextExtractor(
                PypdfTextExtractor(),
                DocxTextExtractor(),
                DocTextExtractor(),
                max_member_bytes=max_bytes,
                max_part_chars=self.settings.max_part_chars,
            )
            self._loader = TextLoader(downloaders, extractor, max_bytes=max_bytes)
        return self._loader

    def orka_downloader(self) -> Downloader:
        """Files of bills that have no print number: a client of its own, with a browser's
        identity and a cookie jar, because the host is a WAF-guarded site and not an API."""
        if self.orka is not None:
            return self.orka
        return self._once("orka", OrkaClient).download

    def text_sources(self) -> TextSources:
        return self._once("text_sources", self._build_text_sources)

    def _build_text_sources(self) -> TextSources:
        reports = SejmConsultationDocuments(self.gateway.download)
        return TextSources(
            SejmTextSource(self.gateway, consultation_documents=reports),
            rcl=RclTextSource() if self.rcl is not None else None,
            submissions=SubmissionTextSource(
                self.settings.orka_base_url, consultation_documents=reports
            ),
        )

    def document_reviews(self, *, dry_run: bool) -> DocumentReviews:
        return self._once(
            f"document_reviews:{dry_run}",
            lambda: DocumentReviews(
                self.repo,
                self.text_sources(),
                self.analysis_service(),
                self.poster(dry_run=dry_run),
                self.clock,
                channel_id=self.channel_id(),
                max_attempts=self.settings.max_publish_attempts,
            ),
        )

    def rcl_reader(self) -> RclProjectReader:
        if self.rcl is None:
            raise RuntimeError("RCL is disabled (LEXINFORM_RCL_ENABLED=false)")
        return RclProjectReader(self.rcl, self.text_loader())

    def rcl_discovery_service(self) -> RclDiscoveryService | None:
        if self.rcl is None:
            return None
        rcl = self.rcl
        return self._once(
            "rcl_discovery",
            lambda: RclDiscoveryService(
                rcl,
                self.repo,
                self.rcl_reader(),
                self.prefilter,
                self.clock,
                text_prefilter=self.settings.text_prefilter_enabled,
                workers=self.settings.rcl_concurrency,
                terms=self.terms,
            ),
        )

    def wykaz_discovery_service(self) -> WykazDiscoveryService | None:
        if self.wykaz is None:
            return None
        wykaz = self.wykaz
        return self._once(
            "wykaz_discovery",
            lambda: WykazDiscoveryService(wykaz, self.repo, self.prefilter, self.clock),
        )

    def _llm_backend(self, model: str) -> AnthropicAnalyzer | OpenAiAnalyzer:
        """One of the four non-triage capabilities, built for whichever model its own setting
        names. A `claude-` name is the one-setting way back to Claude for that capability alone —
        every other capability keeps whatever it was already routed to."""
        if provider_of(model) == "anthropic":
            return AnthropicAnalyzer(
                anthropic.Anthropic(api_key=self.settings.anthropic_api_key),
                model=model,
                output_language=self.settings.output_language,
                effort=self.settings.llm_effort,
                max_tokens=self.settings.llm_max_tokens,
                clock=self.clock.now,
            )
        return OpenAiAnalyzer(
            lambda: openai.OpenAI(api_key=self.settings.openai_api_key),
            model=model,
            output_language=self.settings.output_language,
            effort=self.settings.llm_openai_effort,
            max_output_tokens=self.settings.llm_openai_max_tokens,
            clock=self.clock.now,
        )

    def analyzer(self) -> LlmAnalyzer:
        if self.llm is not None:
            return self.llm
        triage = AnthropicAnalyzer(
            anthropic.Anthropic(api_key=self.settings.anthropic_api_key),
            triage_model=self.settings.llm_triage_model or None,
            output_language=self.settings.output_language,
            clock=self.clock.now,
        )
        return HybridAnalyzer(
            analysis=self._llm_backend(self.settings.llm_analysis_model),
            amendments=self._llm_backend(self.settings.llm_amendments_model),
            supplement=self._llm_backend(self.settings.llm_supplement_model),
            joint=self._llm_backend(self.settings.llm_joint_model),
            triage=triage,
        )

    def batch_backend(self) -> BatchBackend:
        """The primary model selects its provider; collected requests retain their own provider."""
        backend = self.batch_backend_for(self.analysis_options().batch_provider or "openai")
        assert backend is not None, "batch_backend_for builds a backend for the configured provider"
        return backend

    def batch_backend_for(self, provider: BatchProvider) -> BatchBackend | None:
        overflow_provider = provider_of(self.settings.llm_analysis_overflow_model)
        if self.overflow_batch_override is not None and provider == overflow_provider:
            return self.overflow_batch_override
        if self.batch_override is not None:
            return self.batch_override if provider == self.settings.llm_batch_provider else None
        return self._once(
            f"batch_backend:{provider}", lambda: self._llm_backend(self._batch_model(provider))
        )

    def _batch_model(self, provider: BatchProvider) -> str:
        analysis_model = self.settings.llm_analysis_model
        if provider_of(analysis_model) == provider:
            return analysis_model
        return "claude-opus-5-5" if provider == "anthropic" else "gpt-5.1"

    def analysis_service(self) -> AnalysisService:
        return self._once("analysis", self._build_analysis_service)

    def analysis_options(self) -> AnalysisOptions:
        if self.analysis_options_override is not None:
            return self.analysis_options_override
        # The per-bill guard is about the analyze() call specifically, so its price is that
        # model's, not the secondary one's (`llm_model`).
        price = price_of(self.settings.llm_analysis_model)  # None: unknown model, no estimates
        supplement_price = price_of(self.settings.llm_supplement_model)
        batch_price = price
        overflow_price = price_of(self.settings.llm_analysis_overflow_model)
        return AnalysisOptions(
            require_batch=True,
            max_attempts=self.settings.max_analysis_attempts,
            workers=self.settings.llm_concurrency,
            input_price_usd_per_mtok=price[0] if price is not None else None,
            batch_input_price_usd_per_mtok=batch_price[0] if batch_price is not None else None,
            supplement_input_price_usd_per_mtok=(
                supplement_price[0] if supplement_price is not None else None
            ),
            max_input_tokens=input_limit_of(self.settings.llm_analysis_model),
            overflow_input_price_usd_per_mtok=overflow_price[0] if overflow_price else None,
            overflow_max_input_tokens=input_limit_of(self.settings.llm_analysis_overflow_model),
            overflow_model=self.settings.llm_analysis_overflow_model,
            overflow_provider=provider_of(self.settings.llm_analysis_overflow_model),
            batch_max_input_tokens=input_limit_of(self.settings.llm_analysis_model),
            prompt_version=PROMPT_VERSION,
            max_bill_cost_usd=self.settings.max_analysis_cost_usd,
            max_run_cost_usd=self.settings.max_run_cost_usd,
            triage_min_chars=self.settings.triage_min_chars,
            triage_scan_pages=self.settings.triage_scan_pages,
            triage_min_confidence=self.settings.triage_min_confidence,
            channel_id=self.channel_id(),
            change_review_max_ratio=self.settings.change_review_max_ratio,
            change_review_max_chars=self.settings.change_review_max_chars,
            batch_provider=provider_of(self.settings.llm_analysis_model),
            submit_batches=self.settings.llm_batch_enabled,
            batch_sync_within_days=self.settings.llm_batch_sync_within_days,
            batch_kinds=self.settings.llm_batch_kinds,
            consultation_reviews_enabled=self.settings.consultation_reviews_enabled,
            batch_models={
                "amendments": self.settings.llm_amendments_model,
                "supplement": self.settings.llm_supplement_model,
                "joint": self.settings.llm_joint_model,
                "consultation_review": self.settings.llm_analysis_model,
                "act_application": self.settings.llm_analysis_model,
            },
            batch_max_wait=timedelta(hours=self.settings.llm_batch_max_wait_hours),
        )

    def _build_analysis_service(self) -> AnalysisService:
        return AnalysisService(
            self.repo,
            self.text_sources(),
            self.text_loader(),
            self.analyzer(),
            self.clock,
            self.analysis_options(),
            overflow_batch=self.overflow_batch_override
            or self.batch_override
            or self._llm_backend(self.settings.llm_analysis_overflow_model),
            text_budget=TextBudget(self.settings.text_budget_chars),
            text_identity=SejmTextIdentity(self.settings.orka_base_url),
            authors=SejmAuthorsResolver(self.gateway),
            keywords=self.prefilter,
            triage=self.prefilter if self.settings.llm_triage_model else None,
            batch=self.batch_backend(),
            batch_resolver=self.batch_backend_for,
            batch_checkpoint=(
                GitBatchCheckpoint(
                    self.repo.dump,
                    self.settings.llm_batch_state_file,
                    self.settings.llm_batch_state_branch,
                    self.repo.list_open_llm_batches,
                )
                if self.settings.llm_batch_state_file is not None
                else None
            ),
        )

    def discovery_service(self) -> BillDiscoveryService:
        return self._once(
            "discovery",
            lambda: BillDiscoveryService(
                self.gateway,
                self.repo,
                self.prefilter,
                self.clock,
                text_prefilter=self.settings.text_prefilter_enabled,
                local_tz=LOCAL_TZ,
                projects=self.rcl,
                eli=self.gateway,
            ),
        )

    def text_prefilter_service(self) -> TextPrefilterService | None:
        if not self.settings.text_prefilter_enabled:
            return None
        return self._once(
            "text_prefilter",
            lambda: TextPrefilterService(
                self.repo,
                self.text_sources(),
                self.text_loader(),
                self.prefilter,
                min_distinct=self.settings.text_prefilter_min_distinct,
                min_occurrences=self.settings.text_prefilter_min_occurrences,
                workers=self.settings.sejm_concurrency,
            ),
        )

    def telegram_client(self, *, for_channel: bool = True) -> TelegramBotClient:
        """The bot; `for_channel` also demands the reader channel id (posting), which the relay
        does not need (it lives in the log channel)."""
        if self._telegram is None:
            if for_channel:
                self.settings.require_telegram()
            elif not self.settings.telegram_bot_token:
                raise ValueError("Missing required settings: LEXINFORM_TELEGRAM_BOT_TOKEN")
            self._telegram = TelegramBotClient(
                self.settings.telegram_bot_token, base_url=self.settings.telegram_api_base_url
            )
        return self._telegram

    def telegram_publisher(self, *, channel_id: str | None = None) -> TelegramPublisher:
        return TelegramPublisher(
            self.telegram_client(),
            self.formatter,
            channel_id=channel_id or self.settings.telegram_channel_id,
        )

    def publisher(self, *, dry_run: bool) -> Publisher:
        if self.publisher_override is not None:
            return self.publisher_override
        if dry_run:
            return self._once("console_publisher", lambda: ConsolePublisher(self.formatter))
        return self._once("telegram_publisher", self.telegram_publisher)

    def run_notifier(self, *, dry_run: bool) -> RunNotifier | None:
        return self._once(f"notifier:{dry_run}", lambda: self._run_notifier(dry_run=dry_run))

    def _run_notifier(self, *, dry_run: bool) -> RunNotifier | None:
        notifier = self._raw_notifier(dry_run=dry_run)
        return (
            DeliveryNotifier(
                notifier,
                self.repo,
                self.clock,
                channel_id=self.channel_id(),
                dry_run=dry_run,
            )
            if notifier is not None
            else None
        )

    def _raw_notifier(self, *, dry_run: bool) -> RunNotifier | None:
        if self.notifier_override is not None:
            return self.notifier_override
        if dry_run and not os.environ.get("LEXINFORM_RUN_MESSAGE_ID"):
            return ConsoleRunNotifier(self.formatter)
        if not self.settings.telegram_log_channel_id:
            return None
        server = os.environ.get("GITHUB_SERVER_URL")
        repository = os.environ.get("GITHUB_REPOSITORY")
        run_id = os.environ.get("GITHUB_RUN_ID")
        run_url = (
            f"{server.rstrip('/')}/{repository}/actions/runs/{run_id}"
            if server and repository and run_id
            else None
        )
        return TelegramRunNotifier(
            self.telegram_client(),
            self.formatter,
            channel_id=self.settings.telegram_log_channel_id,
            run_url=run_url,
            message_id=int(os.environ["LEXINFORM_RUN_MESSAGE_ID"])
            if os.environ.get("LEXINFORM_RUN_MESSAGE_ID")
            else None,
        )

    def channel_id(self) -> str:
        return self.settings.telegram_channel_id or "console"

    def command_inbox(self) -> CommandInbox | None:
        if self.inbox_override is not None:
            return self.inbox_override
        if self.settings.inbox_dir is None:
            return None
        return FileInbox(self.settings.inbox_dir)

    def operator_replier(self, *, dry_run: bool) -> OperatorReplier:
        if self.replier_override is not None:
            return self.replier_override
        if dry_run or not self.settings.telegram_log_channel_id:
            return ConsoleReplier(self.formatter)
        return TelegramOperatorReplier(
            self.telegram_client(), self.formatter, channel_id=self.settings.telegram_log_channel_id
        )

    def command_listener(self, *, dry_run: bool) -> CommandListener:
        """The relay: Telegram in, the inbox branch out. A dry run reads and reports only."""
        s = self.settings
        if not s.telegram_log_channel_id:
            raise ValueError("Missing required settings: LEXINFORM_TELEGRAM_LOG_CHANNEL_ID")
        client = self.telegram_client(for_channel=False)
        writer = None
        acknowledger = None
        if not dry_run:
            writer = self._once(
                "inbox_writer",
                lambda: GitHubInboxWriter(s.github_repo, s.github_token, branch=s.inbox_branch),
            )
            acknowledger = TelegramAcknowledger(client, channel_id=s.telegram_log_channel_id)
        return CommandListener(
            client,
            writer,
            acknowledger,
            starter=writer,  # the same GitHub client: filing and starting differ only in scope
            channel_id=s.telegram_log_channel_id,
            poll_timeout=s.listen_timeout_seconds,
        )

    def command_service(self, *, dry_run: bool) -> CommandService | None:
        inbox = self.command_inbox()
        if inbox is None:
            return None
        return self._once(
            f"commands:{dry_run}",
            lambda: CommandService(
                self.repo,
                inbox,
                self.operator_replier(dry_run=dry_run),
                self.bill_lookup(),
                self.analysis_service(),
                self.publishing_service(dry_run=dry_run),
                self.clock,
                text_prefilter=self.text_prefilter_service(),
                tracking=self.tracking_service(dry_run=dry_run),
                amendments=self.amendments_service(),
                digest=self.digest_service(dry_run=dry_run),
                publisher_for=lambda chat: self.publisher_for(chat, dry_run=dry_run),
                language=self.settings.output_language,
            ),
        )

    def publisher_for(self, channel_id: str, *, dry_run: bool) -> Publisher:
        """Where `/preview BILL to=…` sends the card: that chat, or wherever this run's publisher
        goes when there is no real one (a dry run, a test's override)."""
        if dry_run or self.publisher_override is not None:
            return self.publisher(dry_run=dry_run)
        return self.telegram_publisher(channel_id=channel_id)

    def amendments_service(self) -> AmendmentsService:
        return self._once(
            "amendments",
            lambda: AmendmentsService(
                self.repo,
                self.gateway,
                self.analysis_service(),
                channel_id=self.channel_id(),
            ),
        )

    def publishing_service(self, *, dry_run: bool) -> PublishingService:
        return self._once(
            f"publishing:{dry_run}",
            lambda: PublishingService(
                self.gateway,
                self.repo,
                self.publisher(dry_run=dry_run),
                self.clock,
                channel_id=self.channel_id(),
                max_attempts=self.settings.max_publish_attempts,
                analysis=self.analysis_service(),
                attention_enabled=self.settings.reader_attention == "on",
                attention_assess=self.settings.reader_attention != "off",
                delivery_attempts=self._delivery_attempts(dry_run),
            ),
        )

    def digest_service(self, *, dry_run: bool) -> DigestService | None:
        """None when the digest is switched off, or when there is no technical channel to draft
        into: nothing reaches readers unread, so without a drafter there is no digest at all."""
        s = self.settings
        if not s.digest_enabled or not self._has_drafts_channel(dry_run=dry_run):
            return None
        return self._once(
            f"digest:{dry_run}",
            lambda: DigestService(
                self.repo,
                self.publisher(dry_run=dry_run),
                self.drafts_publisher(dry_run=dry_run),
                self.clock,
                channel_id=self.channel_id(),
                draft_channel_id=self.drafts_channel_id(),
                approve_label=APPROVE_DIGEST,
                attention_enabled=s.reader_attention == "on",
                weekday=s.digest_weekday,
                local_tz=LOCAL_TZ,
                closed_grace_days=s.track_closed_grace_days,
                pending_decision_max_days=s.track_pending_decision_max_days,
            ),
        )

    def _has_drafts_channel(self, *, dry_run: bool) -> bool:
        """Whether a draft has anywhere of its own to go; asked of the raw setting, because
        `drafts_channel_id` falls back to a placeholder and would answer yes to everything —
        and `telegram_publisher("")` then aims at the readers' channel, which is the one place
        a draft must never land."""
        return (
            dry_run
            or self.publisher_override is not None
            or bool(self.settings.telegram_log_channel_id)
        )

    def drafts_channel_id(self) -> str:
        return self.settings.telegram_log_channel_id or "console"

    def drafts_publisher(self, *, dry_run: bool) -> Publisher:
        """Where a digest is drafted: the technical channel, or this run's publisher when there
        is no real one (a dry run, a test's override)."""
        if dry_run or self.publisher_override is not None:
            return self.publisher(dry_run=dry_run)
        return self._once(
            "drafts_publisher",
            lambda: self.telegram_publisher(channel_id=self.settings.telegram_log_channel_id),
        )

    def tracking_service(self, *, dry_run: bool) -> StatusTrackingService:
        return self._once(
            f"tracking:{dry_run}",
            lambda: StatusTrackingService(
                self.gateway,
                self.repo,
                self.publisher(dry_run=dry_run),
                self.clock,
                self.tracking_options(),
                analysis=self.analysis_service(),
                eli=self.gateway,
                rcl_reader=self.rcl_reader() if self.rcl is not None else None,
                wykaz=self.wykaz,
                senate=self.senate,
                poster=self.poster(dry_run=dry_run),
                deliveries=self.delivery_service(dry_run=dry_run),
                document_reviews=self.document_reviews(dry_run=dry_run),
            ),
        )

    def poster(self, *, dry_run: bool) -> Poster:
        return self._once(
            f"poster:{dry_run}",
            lambda: Poster(
                self.repo,
                self.publisher(dry_run=dry_run),
                self.clock,
                gateway=self.gateway,
                channel_id=self.channel_id(),
                max_attempts=self.settings.max_publish_attempts,
                attention_mode=self.settings.reader_attention,
                urgent_days=self.settings.attention_urgent_days,
                max_group=self.settings.attention_max_group,
                daily_roundup=self.settings.attention_roundup == "daily",
                daily_hour=self.settings.attention_daily_hour,
                delivery_attempts=self._delivery_attempts(dry_run),
                consultation_reviews_enabled=self.settings.consultation_reviews_enabled,
            ),
        )

    def _delivery_attempts(self, dry_run: bool) -> set[int]:
        return self._once(f"delivery_attempts:{dry_run}", lambda: set[int]())

    def delivery_service(self, *, dry_run: bool) -> DeliveryService:
        return self._once(
            f"deliveries:{dry_run}",
            lambda: DeliveryService(
                self.repo,
                self.clock,
                self.poster(dry_run=dry_run),
                channel_id=self.channel_id(),
                max_attempts=self.settings.max_publish_attempts,
                notifier=self.run_notifier(dry_run=dry_run),
                runs_retention_days=self.settings.runs_retention_days,
            ),
        )

    def tracking_options(self) -> TrackingOptions:
        settings = self.settings
        return TrackingOptions(
            channel_id=self.channel_id(),
            closed_grace_days=settings.track_closed_grace_days,
            pending_decision_max_days=settings.track_pending_decision_max_days,
            max_publish_attempts=settings.max_publish_attempts,
            club_breakdown=settings.voting_club_breakdown,
            in_force_reminders=settings.in_force_reminders,
            consultation_reminder_days=(
                settings.consultation_reminder_days if settings.consultation_reminders else None
            ),
            decision_reminder_days=(
                settings.decision_reminder_days if settings.decision_reminders else None
            ),
            agenda_watch=settings.agenda_watch,
            max_card_edits=settings.max_card_edits,
            local_tz=LOCAL_TZ,
            text_prefilter=settings.text_prefilter_enabled,
            workers=settings.sejm_concurrency,
            observe_unthreaded=settings.observe_unthreaded,
            min_score=settings.min_score,
            reader_attention=settings.reader_attention,
            attention_urgent_days=settings.attention_urgent_days,
            attention_max_group=settings.attention_max_group,
            attention_roundup=settings.attention_roundup,
            attention_daily_hour=settings.attention_daily_hour,
        )

    def pipeline(self, *, dry_run: bool) -> DailyPipeline:
        return self._once(
            f"pipeline:{dry_run}",
            lambda: DailyPipeline(
                self.repo,
                self.discovery_service(),
                self.analysis_service(),
                self.publishing_service(dry_run=dry_run),
                self.tracking_service(dry_run=dry_run),
                self.clock,
                terms=self.terms,
                notifier=self.run_notifier(dry_run=dry_run),
                text_prefilter=self.text_prefilter_service(),
                rcl_discovery=self.rcl_discovery_service(),
                wykaz_discovery=self.wykaz_discovery_service(),
                commands=self.command_service(dry_run=dry_run),
                digest=self.digest_service(dry_run=dry_run),
                first_run_lookback_days=self.settings.first_run_lookback_days,
                rerun_overlap_days=self.settings.rerun_overlap_days,
                runs_retention_days=self.settings.runs_retention_days,
                history_payload_retention_days=self.settings.history_payload_retention_days,
                analysis_memo_retention_days=self.settings.analysis_memo_retention_days,
                pre_print=self.settings.pre_print_enabled,
                full_track_weekday=self.settings.track_full_weekday,
            ),
        )

    def close(self) -> None:
        self.gateway.close()
        orka = self._services.get("orka")
        if isinstance(orka, OrkaClient):
            orka.close()
        writer = self._services.get("inbox_writer")
        if isinstance(writer, GitHubInboxWriter):
            writer.close()
        if self.rcl is not None:
            self.rcl.close()
        if self.wykaz is not None:
            self.wykaz.close()
        if self.senate is not None:
            self.senate.close()
        self.repo.close()
        if self._telegram is not None:
            self._telegram.close()


def _host(url: str) -> str:
    return urlparse(url).hostname or ""


def build_container(settings: Settings) -> Container:
    repo = SqliteBillRepository(settings.db_path)
    repo.migrate()
    gateway = SejmApiClient(
        settings.sejm_api_base_url,
        page_size=settings.sejm_page_size,
        timeout=settings.sejm_timeout_seconds,
    )
    rcl = (
        RclClient(
            settings.rcl_base_url,
            timeout=settings.rcl_timeout_seconds,
            proxy=settings.rcl_proxy_url or None,
        )
        if settings.rcl_enabled
        else None
    )
    wykaz = (
        WykazClient(
            settings.wykaz_base_url,
            timeout=settings.wykaz_timeout_seconds,
            proxy=settings.wykaz_proxy_url or None,
        )
        if settings.wykaz_enabled
        else None
    )
    senate = (
        SenateClient(
            settings.senate_base_url,
            timeout=settings.senate_timeout_seconds,
            proxy=settings.senate_proxy_url or None,
        )
        if settings.senate_enabled
        else None
    )
    clock = SystemClock()
    return Container(
        settings=settings,
        clock=clock,
        repo=repo,
        gateway=gateway,
        formatter=MessageFormatter(
            settings.output_language,
            today=lambda: clock.now().astimezone(LOCAL_TZ).date(),
            channel=settings.telegram_channel_id,
            support_url=settings.digest_support_url,
            sponsor_url=settings.digest_sponsor_url,
            attention_enabled=settings.reader_attention == "on",
        ),
        prefilter=KeywordPrefilter(),
        terms=TermResolver(gateway, repo, pinned=settings.term),
        rcl=rcl,
        wykaz=wykaz,
        senate=senate,
    )
